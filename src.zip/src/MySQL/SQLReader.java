package MySQL;

import java.io.BufferedReader;    
import java.io.File;    
import java.io.FileReader;   
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;  
import java.util.List;
 
public class SQLReader  
{   
    private static final List<String> queries = new ArrayList<String>(); 
    private static final List<String> tableNames = new ArrayList<String>();
    private static final List<String> create = new ArrayList<String>(); 
    private static final List<String> insert = new ArrayList<String>(); 
    private String path="";
    
    public SQLReader(String sqlFilePath) {
        try {
            URL url = this.getClass().getProtectionDomain().getCodeSource().getLocation();
            this.path = URLDecoder.decode(url.getFile(),"UTF-8")+ sqlFilePath;//"Project/project.sql";
        } catch (UnsupportedEncodingException e) {}

        String queryLine;  
        StringBuilder sBuffer =  new StringBuilder();  
          
        try    
        {    
            FileReader fr =     new FileReader(new File(path));
            BufferedReader br = new BufferedReader(fr);
            if(br.ready()) {
                //read the SQL file line by line
                while((queryLine = br.readLine()) != null)
                {
                    // ignore comments beginning with #
                    int indexOfCommentSign = queryLine.indexOf('#');
                    if(indexOfCommentSign != -1)
                    {
                        if(queryLine.startsWith("#"))
                        {
                            queryLine = "";
                        }
                        else
                            queryLine = new String(queryLine.substring(0, indexOfCommentSign-1));
                    }
                    // ignore comments beginning with --
                    indexOfCommentSign = queryLine.indexOf("--");
                    if(indexOfCommentSign != -1)
                    {
                        if(queryLine.startsWith("--"))
                        {
                            queryLine = "";
                        }
                        else
                            queryLine = new String(queryLine.substring(0, indexOfCommentSign-1));
                    }
                    // ignore comments surrounded by /* */
                    indexOfCommentSign = queryLine.indexOf("/*");
                    if(indexOfCommentSign != -1)
                    {
                        if(queryLine.startsWith("#"))
                        {
                            queryLine = "";
                        }
                        else
                            queryLine = new String(queryLine.substring(0, indexOfCommentSign-1));
                        
                        sBuffer.append(queryLine).append(" ");
                        // ignore all characters within the comment
                        do
                        {
                            queryLine = br.readLine();
                        }
                        while(queryLine != null && !queryLine.contains("*/"));
                        
                        indexOfCommentSign = (queryLine != null)?queryLine.indexOf("*/"):-1;
                        if(indexOfCommentSign != -1)
                        {
                            if(queryLine.endsWith("*/"))
                            {
                                queryLine = "";
                            }
                            else
                                queryLine = new String(queryLine.substring(indexOfCommentSign+2, queryLine.length()-1));
                        }
                    }

                    if(queryLine != null)
                        sBuffer.append(queryLine).append(" ");
                }
            }  
            //how to identify
            String[] splittedQueries = sBuffer.toString().split(";");  
            String tableName = null;
            for (String splittedQuerie : splittedQueries) {
                if (!splittedQuerie.trim().equals("") && !splittedQuerie.trim().equals("\t")) {

                    if(splittedQuerie.contains("`")) {
                        tableName = splittedQuerie.substring(splittedQuerie.indexOf('`'),splittedQuerie.indexOf(' ',splittedQuerie.indexOf("`")));
                        tableNames.add(tableName);
                    }
                    if(splittedQuerie.contains("create table") || splittedQuerie.contains("CREATE TABLE")) {
                        create.add(splittedQuerie+"; - create");
                        System.out.println(splittedQuerie+";");
                    } else if(splittedQuerie.contains("insert") || splittedQuerie.contains("INSERT")) {
                        insert.add(splittedQuerie+"; - insert");
                        System.out.println(splittedQuerie+";");
                    } else {
                        queries.add(splittedQuerie+";");
                        System.out.println(splittedQuerie+"; - other");
                    }
                    
                }
            }  
        }    
        catch(IOException e) {}  
    }
    
    public List<String> getQueries() {
        return queries;
    }
    
    public List<String> getTableNames() {
        return tableNames;
    }
    
    public List<String> getCreateQueries() {
        return create;
    }
        
    public List<String> getInsertQueries() {
        return insert;
    }
}  