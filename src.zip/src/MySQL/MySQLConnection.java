/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package MySQL;

import Property.Properties;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Design
 */
public class MySQLConnection {
    private static final Properties properties = new Properties("MySQL/database.properties");   
    private static String url;
    private static String user;
    private static String password;
    public static boolean check = true;

    public static java.sql.Connection getConnection(){
        try{
            url=properties.getProperty("url").replace("\\","");
            user=properties.getProperty("user").replace("\\","");
            password=properties.getProperty("password").replace("\\","");
        } catch (Exception e){}
    
        java.sql.Connection connection = null;  
        
	try {
            Class.forName("com.mysql.jdbc.Driver");
	} catch (ClassNotFoundException e) {}
	try {
            connection = DriverManager.getConnection(url,user,password);
	} catch (SQLException e) {}
        return connection;
    }
    
    public static boolean connectedToMySQLServer(String url,String user,String password){
        boolean success = false;
        java.sql.Connection connection = null;  
        
	try {
            Class.forName("com.mysql.jdbc.Driver");
	} catch (ClassNotFoundException e) {}
	try {
            connection = DriverManager.getConnection(url,user,password);
            success = true;
	} catch (SQLException e) {}
        return success;
    }
}
