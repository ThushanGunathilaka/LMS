/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Translate;

import MySQL.SQLReader;
import MySQL.MySQLMethods;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.swing.AbstractButton;
import javax.swing.JToggleButton;

/**
 *
 * @author Design
 */
public class LanguageTranslator {
    public static SupportedLanguage currentLanguage = SupportedLanguage.ENGLISH;
    private HashMap<String, LanguageText> translator;
    
    private static JToggleButton translatorButton;

    public LanguageTranslator (final MultiLanguage jframe) { 
        LanguageTranslator.translatorButton = Thushan.Front.changeLanguage;
        translatorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                AbstractButton abstractButton = (AbstractButton) actionEvent.getSource();
                boolean selected = abstractButton.getModel().isSelected();
                LanguageTranslator.currentLanguage=(selected)?LanguageTranslator.SupportedLanguage.SINHALA:LanguageTranslator.SupportedLanguage.ENGLISH;
                translatorButton.setSelected(selected);
                if(selected) {
                    jframe.languageIsSinhala();
                } else {
                    jframe.languageIsEnglish();
                }
            }
        });
        
        translator = new HashMap<String, LanguageText>();
    }
    
    public  LanguageTranslator (final MultiLanguage jframe,final JToggleButton translatorButton){
        LanguageTranslator.translatorButton = translatorButton;
                translatorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                AbstractButton abstractButton = (AbstractButton) actionEvent.getSource();
                boolean selected = abstractButton.getModel().isSelected();
                LanguageTranslator.currentLanguage=(selected)?LanguageTranslator.SupportedLanguage.SINHALA:LanguageTranslator.SupportedLanguage.ENGLISH;
                translatorButton.setSelected(selected);
                if(selected) {
                    jframe.languageIsSinhala();
                } else {
                    jframe.languageIsEnglish();
                }
            }
        });
        translator = new HashMap<String, LanguageText>();
    }
    
   // String beginEnglish = "<html><font face=\"Sakkal Majalla\">";
   // String beginSinhala = "<html><font face=\"Iskoola pota\">";
   // String end = "</font></html>";
    
    public String getSinhala(String variableName) {
        return (translator.containsKey(variableName)? translator.get(variableName).getSinhalaText():"");
    }
    
    public String getEnglish(String variableName) {
        return (translator.containsKey(variableName)? translator.get(variableName).getEnglishText():"");
    }
    
    public void addTranslation(String variableName, String englishText, String sinhalaText){
        if(translator.containsKey(variableName)){
            translator.remove(variableName);
        }
        if(variableName != null && !variableName.trim().isEmpty() ) {
            translator.put(variableName, new Text(englishText,sinhalaText));
        }
    }
    
    public void addTranslation(String variableName, String englishText, String sinhalaText,String englishTooltipText,
                String sinhalaTooltipText, String englishValidationEmpty,
                String sinhalaValidationEmpty, String englishValidationWrong,
                String sinhalaValidationWrong,String englishValidationOther,
                String sinhalaValidationOther){
        if(translator.containsKey(variableName)){
            translator.remove(variableName);
        }
        if(variableName != null && !variableName.trim().isEmpty() ) {
            translator.put(variableName, new Text(englishText,sinhalaText,englishTooltipText,
                sinhalaTooltipText, englishValidationEmpty,
                sinhalaValidationEmpty, englishValidationWrong,
                sinhalaValidationWrong,englishValidationOther,
                sinhalaValidationOther));
        }
    }
    
    public void addTranslation(String variableName, String englishText, String sinhalaText,
            String englishValidationEmpty,
                String sinhalaValidationEmpty, String englishValidationWrong,
                String sinhalaValidationWrong,String englishValidationOther,
                String sinhalaValidationOther){
        if(translator.containsKey(variableName)){
            translator.remove(variableName);
        }
        if(variableName != null && !variableName.trim().isEmpty() ) {
            translator.put(variableName, new Text(englishText,sinhalaText, englishValidationEmpty,
                sinhalaValidationEmpty, englishValidationWrong,
                sinhalaValidationWrong,englishValidationOther,
                sinhalaValidationOther));
        }
    }
    
    public void addTranslation(String variableName, String englishText, String sinhalaText,
            String englishValidationEmpty,
                String sinhalaValidationEmpty, String englishValidationWrong,
                String sinhalaValidationWrong){
        if(translator.containsKey(variableName)){
            translator.remove(variableName);
        }
        if(variableName != null && !variableName.trim().isEmpty() ) {
            translator.put(variableName, new Text(englishText,sinhalaText, englishValidationEmpty,
                sinhalaValidationEmpty, englishValidationWrong,
                sinhalaValidationWrong));
        }
    }
    
    public void addTranslation(String variableName, String englishText, String sinhalaText,String englishTooltipText,
                String sinhalaTooltipText){
        if(translator.containsKey(variableName)){
            translator.remove(variableName);
        }
        if(variableName != null && !variableName.trim().isEmpty() ) {
            translator.put(variableName, new Text(englishText,sinhalaText,englishTooltipText,
                sinhalaTooltipText));
        }
    }
    

    public void setLanguage(SupportedLanguage language) {
        LanguageTranslator.currentLanguage = language;
    }

    public enum SupportedLanguage {
        ENGLISH, SINHALA; 
    }
    
    public static enum SupportedFonts {
        SakkalMajalla, IskoolaPota; 
    }
    
    public void retrive(String frameTitle) {
        translator = new HashMap<String, LanguageText>();
        List<List<String>> data = MySQLMethods.getResultTable("SELECT * FROM `translations`.`translator` where `frameName` = \""+frameTitle+"\";");
        int y = data.size()-1;
        int x = data.get(0).size()-1;
        for(int i=1;i<=y;i++) {
            translator.put(data.get(i).get(2), new Text(data.get(i).get(3),data.get(i).get(4),data.get(i).get(5),data.get(i).get(6),data.get(i).get(7),data.get(i).get(8),data.get(i).get(9),data.get(i).get(10)));
        }
    }
   
    public void save(String frameTitle) {
        SQLReader sqlReader= new SQLReader("/Translate/Translator.sql");
        
        MySQLMethods.curd(sqlReader.getQueries());
        MySQLMethods.curd(sqlReader.getCreateQueries());
        MySQLMethods.curd(sqlReader.getInsertQueries());    // after all translations are added take all insert queries from translations table and put at the end of /Translate/Translator.sql
        
        List<String> newObjectsSavedForFrame = new ArrayList<String>();
        
        for(String key : translator.keySet()) {
            newObjectsSavedForFrame.add(key);
        }
   
        for(String key : newObjectsSavedForFrame) {
            String invalidPrimaryKey = MySQLMethods.getResultCell("SELECT `translator`.`translatorId` FROM `translations`.`translator` where `objectName` = \""+key+"\";");
            //MySQLMethods.delete|(...) method has if condtion to return null for errors and curd wont execute null or empty
            MySQLMethods.curd(MySQLMethods.delete("translations","translator","translator.translatorId",invalidPrimaryKey));
        }

        String [] columnArray = {"frameName","objectName","englishText","sinhalaText",
            "`translator`.`englishTooltipText`","`translator`.`sinhalaTooltipText`",
       "`translator`.`englishValidationEmpty`","`translator`.`sinhalaValidationEmpty`",
       "`translator`.`englishValidationWrong`",       "`translator`.`sinhalaValidationWrong`",
       "`translator`.`englishValidationOther`","`translator`.`sinhalaValidationOther`"};
        
        for(String key : newObjectsSavedForFrame) {
                    String [] valuesArray = new String[12];
                    valuesArray[0] = frameTitle;
                    valuesArray[1] = key;
                    valuesArray[2] = translator.get(key).getEnglishText();
                    valuesArray[2] = (valuesArray[2] == null)? "" : valuesArray[2];
                    valuesArray[3] = translator.get(key).getSinhalaText();
                    valuesArray[3] = (valuesArray[3] == null)? "" : valuesArray[3];
                    valuesArray[4] = translator.get(key).getEnglishTooltipText();
                    valuesArray[4] = (valuesArray[4] == null)? "" : valuesArray[4];
                    valuesArray[5] = translator.get(key).getSinhalaTooltipText();
                    valuesArray[5] = (valuesArray[5] == null)? "" : valuesArray[5];
                    valuesArray[6] = translator.get(key).getEnglishValidationEmpty();
                    valuesArray[6] = (valuesArray[6] == null)? "" : valuesArray[6];
                    valuesArray[7] = translator.get(key).getSinhalaValidationEmpty();
                    valuesArray[7] = (valuesArray[7] == null)? "" : valuesArray[7];
                    valuesArray[8] = translator.get(key).getEnglishValidationWrong();
                    valuesArray[8] = (valuesArray[8] == null)? "" : valuesArray[8];
                    valuesArray[9] = translator.get(key).getSinhalaValidationWrong();
                    valuesArray[9] = (valuesArray[9] == null)? "" : valuesArray[9];
                    valuesArray[10] = translator.get(key).getEnglishValidationOther();
                    valuesArray[10] = (valuesArray[10] == null)? "" : valuesArray[10];
                    valuesArray[11] = translator.get(key).getSinhalaValidationOther();
                    valuesArray[11] = (valuesArray[11] == null)? "" : valuesArray[11];

            MySQLMethods.curd(MySQLMethods.insert("translations","translator",columnArray,valuesArray));
        }
        
    }

    private class Text implements LanguageText{
        private String english;
        private String sinhala;
        private String englishTooltipText;
        private String sinhalaTooltipText;
        private String englishValidationEmpty;
        private String sinhalaValidationEmpty;
        private String englishValidationWrong;
        private String sinhalaValidationWrong;
        private String englishValidationOther;
        private String sinhalaValidationOther;

        Text(String englishText,String sinhalaText,String englishTooltipText,
                String sinhalaTooltipText, String englishValidationEmpty,
                String sinhalaValidationEmpty, String englishValidationWrong,
                String sinhalaValidationWrong,String englishValidationOther,
                String sinhalaValidationOther) {
 
            this.english = englishText;
            this.sinhala = sinhalaText;
            this.englishTooltipText =englishTooltipText;
            this.sinhalaTooltipText=sinhalaTooltipText;
            this.englishValidationEmpty =englishValidationEmpty;
            this.sinhalaValidationEmpty =sinhalaValidationEmpty;
            this.englishValidationWrong =englishValidationWrong;
            this.sinhalaValidationWrong =sinhalaValidationWrong;
            this.englishValidationOther =englishValidationOther;
            this.sinhalaValidationOther =sinhalaValidationOther;
        }
        
        Text(String englishText,String sinhalaText, String englishValidationEmpty,
                String sinhalaValidationEmpty, String englishValidationWrong,
                String sinhalaValidationWrong) {
            this.english = englishText;
            this.sinhala = sinhalaText;
            this.englishValidationEmpty =englishValidationEmpty;
            this.sinhalaValidationEmpty =sinhalaValidationEmpty;
            this.englishValidationWrong =englishValidationWrong;
            this.sinhalaValidationWrong =sinhalaValidationWrong;
        }
        
        Text(String englishText,String sinhalaText,String englishTooltipText,
                String sinhalaTooltipText) {
            this.english = englishText;
            this.sinhala = sinhalaText;
            this.englishTooltipText =englishTooltipText;
            this.sinhalaTooltipText=sinhalaTooltipText;
        }
        
        Text(String englishText,String sinhalaText,String englishValidationEmpty,
                String sinhalaValidationEmpty, String englishValidationWrong,
                String sinhalaValidationWrong,String englishValidationOther,
                String sinhalaValidationOther) {
            this.english = englishText;
            this.sinhala = sinhalaText;
            this.englishValidationEmpty =englishValidationEmpty;
            this.sinhalaValidationEmpty =sinhalaValidationEmpty;
            this.englishValidationWrong =englishValidationWrong;
            this.sinhalaValidationWrong =sinhalaValidationWrong;
            this.englishValidationOther =englishValidationOther;
            this.sinhalaValidationOther =sinhalaValidationOther;
        }
        
        Text(String englishText,String sinhalaText) {
            this.english = englishText;
            this.sinhala = sinhalaText;
        }
        
    @Override
        public String getSinhalaText() {
            return this.sinhala;
        }
        
    @Override
        public String getEnglishText() {
            return this.english;
        }
        
    @Override
        public void setSinhalaText(String sinhala) {
            this.sinhala = sinhala;
        }
        
    @Override
        public void setEnglishText(String english) {
            this.english = english;
        }
        
    @Override
        public void setText(String english, String sinhala) {
            this.english = english;
            this.sinhala = sinhala;
        }

        @Override
        public String getEnglishTooltipText() {
            return this.englishTooltipText;
        }

        @Override
        public String getSinhalaTooltipText() {
            return this.sinhalaTooltipText;
        }

        @Override
        public String getEnglishValidationEmpty() {
            return this.englishValidationEmpty;
        }

        @Override
        public String getSinhalaValidationEmpty() {
            return this.sinhalaValidationEmpty;
        }

        @Override
        public String getEnglishValidationWrong() {
            return this.englishValidationWrong;
        }

        @Override
        public String getSinhalaValidationWrong() {
            return this.sinhalaValidationWrong;
        }

        @Override
        public String getEnglishValidationOther() {
            return this.englishValidationOther;
        }

        @Override
        public String getSinhalaValidationOther() {
            return this.sinhalaValidationOther;
        }

        @Override
        public void setEnglishTooltipText(String pickYourWord) {
            this.englishTooltipText = pickYourWord;
        }

        @Override
        public void setSinhalaTooltipText(String pickYourWord) {
            this.sinhalaTooltipText = pickYourWord;
        }

        @Override
        public void setEnglishValidationEmpty(String pickYourWord) {
            this.englishValidationEmpty = pickYourWord;
        }

        @Override
        public void setSinhalaValidationEmpty(String pickYourWord) {
            this.sinhalaValidationEmpty = pickYourWord;
        }

        @Override
        public void setEnglishValidationWrong(String pickYourWord) {
            this.englishValidationWrong = pickYourWord;
        }

        @Override
        public void setSinhalaValidationWrong(String pickYourWord) {
            this.sinhalaValidationWrong = pickYourWord;
        }

        @Override
        public void setEnglishValidationOther(String pickYourWord) {
            this.englishValidationOther = pickYourWord;
        }

        @Override
        public void setSinhalaValidationOther(String pickYourWord) {
            this.sinhalaValidationOther = pickYourWord;
        }
    }
    
    private interface LanguageText {
        public String getSinhalaText();
        public String getEnglishText();
        public void setSinhalaText(String sinhala);
        public void setEnglishText(String english);
        public void setText(String english, String sinhala);
        
        public String getEnglishTooltipText();
        public String getSinhalaTooltipText();
        public String getEnglishValidationEmpty();
        public String getSinhalaValidationEmpty();
        public String getEnglishValidationWrong();
        public String getSinhalaValidationWrong();
        public String getEnglishValidationOther();
        public String getSinhalaValidationOther();
        
        public void setEnglishTooltipText(String pickYourWord);
        public void setSinhalaTooltipText(String pickYourWord);
        public void setEnglishValidationEmpty(String pickYourWord);
        public void setSinhalaValidationEmpty(String pickYourWord);
        public void setEnglishValidationWrong(String pickYourWord);
        public void setSinhalaValidationWrong(String pickYourWord);
        public void setEnglishValidationOther(String pickYourWord);
        public void setSinhalaValidationOther(String pickYourWord);
    }
}
