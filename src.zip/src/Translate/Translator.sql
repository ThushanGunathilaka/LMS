CREATE database IF NOT EXISTS translations;
USE translations;

 CREATE TABLE IF NOT EXISTS `translations`.`translator` (
  `translatorId` INT(5) ZEROFILL UNSIGNED UNIQUE KEY PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `frameName` VARCHAR(255) NOT NULL,
  `objectName` VARCHAR(255) NOT NULL,	#	Default format (frameName_objectName) ex:- (camelCaseFrameName_camelCaseObjectName) # firstLetterSimple
  `englishText` VARCHAR(255) NOT NULL,
  `sinhalaText` VARCHAR(255) COLLATE utf8_sinhala_ci NOT NULL,
  `englishTooltipText` VARCHAR(255) DEFAULT NULL,
  `sinhalaTooltipText` VARCHAR(255) COLLATE utf8_sinhala_ci DEFAULT NULL,
  `englishValidationEmpty` VARCHAR(255) DEFAULT NULL,
  `sinhalaValidationEmpty` VARCHAR(255) COLLATE utf8_sinhala_ci DEFAULT NULL,
  `englishValidationWrong` VARCHAR(255) DEFAULT NULL,
  `sinhalaValidationWrong` VARCHAR(255) COLLATE utf8_sinhala_ci DEFAULT NULL,
  `englishValidationOther` VARCHAR(255) DEFAULT NULL,
  `sinhalaValidationOther` VARCHAR(255) COLLATE utf8_sinhala_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_sinhala_ci AUTO_INCREMENT=0;