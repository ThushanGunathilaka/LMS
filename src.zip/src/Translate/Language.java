/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Translate;

import java.awt.Component;
import java.awt.Container;
import java.awt.TextField;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.text.JTextComponent;

/**
 *
 * @author Design
 */
public class Language {
    //Handle.TypingLanguage.loadConfig(<<FrameName>>.this);
    //int [] columnArray = {0,1,6,4,5};
    //Handle.TypingLanguage.tableCellEditorUpdate(tableName,columnArray);
    
    public static void loadConfig(Container frame,LanguageTranslator.SupportedFonts language) {
        String lang;
        if(language.equals(LanguageTranslator.SupportedFonts.SakkalMajalla)){
            lang = "Sakkal Majalla";
        } else {
            lang = "Iskoola Pota";
        }
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
        } catch (InstantiationException ex) {
        } catch (IllegalAccessException ex) {
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {}
                 

        java.util.List<java.awt.Component>  compList = getAllComponents(frame);
        for (Component cmpList : compList) {
          //  if(compList instanceof javax.swing.JTextField || compList instanceof javax.swing.JTextArea || compList instanceof javax.swing.JTextPane || compList instanceof javax.swing.JPasswordField || compList instanceof javax.swing.JFormattedTextField || compList instanceof javax.swing.JComboBox || compList instanceof javax.swing.JEditorPane || compList instanceof javax.swing.JToggleButton || compList instanceof javax.swing.JTable){
           // } else {
                cmpList.setFont(new javax.swing.plaf.FontUIResource(lang, cmpList.getFont().getStyle(), cmpList.getFont().getSize()));
           // }
        }
    }
    
    private static java.util.List<java.awt.Component> getAllComponents(final java.awt.Container c) {
        java.awt.Component[] comps = c.getComponents();
        java.util.List<java.awt.Component> compList = new java.util.ArrayList<java.awt.Component>();
        for (java.awt.Component comp : comps) {
            compList.add(comp);
            if (comp instanceof java.awt.Container) {
                compList.addAll(getAllComponents((java.awt.Container) comp));
            }
        }
        return compList;
    }
    
                    
    public static void tableCellEditorUpdate(javax.swing.JTable table, int[] columnList,LanguageTranslator.SupportedFonts language) {
        String lang = "";
        if(language.equals(LanguageTranslator.SupportedFonts.SakkalMajalla)){
            lang = "Sakkal Majalla";
        } else {
            lang = "Iskoola Pota";
        }
        
        javax.swing.JTextField textField = new javax.swing.JTextField();
        textField.setFont(new java.awt.Font("Iskoola Pota", java.awt.Font.PLAIN, 12));
        textField.setBorder(new javax.swing.border.LineBorder(java.awt.Color.BLACK));
        javax.swing.DefaultCellEditor dce = new javax.swing.DefaultCellEditor( textField );
        try {
        for(int i : columnList) {
            table.getColumnModel().getColumn(i).setCellEditor(dce);
        }
        } catch (Exception e) {}
    }
    
    
    
}
