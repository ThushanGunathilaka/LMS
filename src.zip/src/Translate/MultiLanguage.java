/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Translate;

/**
 *
 * @author Design
 */
public interface MultiLanguage {
    public void languageIsEnglish();
    public void languageIsSinhala();
    public void changeUI();
}
