/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package purchase;

import com.sun.corba.se.impl.protocol.giopmsgheaders.Message;
import com.sun.org.apache.xml.internal.dtm.DTM;
import com.toedter.calendar.JCalendar;
import java.awt.event.ItemEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Vector;
import javax.print.DocFlavor;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;
//import org.hibernate.jdbc.ColumnNameCache;

/**
 *
 * @author DELL
 */
public class purchasedetails extends javax.swing.JFrame {

    /**
     * Creates new form purchasedetails
     */
    int itemId = 0;

    public purchasedetails() {
        initComponents();

        //Purchasedetails data
        txthideid.setVisible(false); // hidetext feild set start inviisible
        try {
            Connection c = DBconnect.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT name,idnumber,catogory,choose,purchasedon,quantity,priceperunit,totalcost,receiptno,approvedby,note,misplace FROM purchasedetails");

            DefaultTableModel dtm = (DefaultTableModel) jTable4.getModel();

            while (rs.next()) {

                Vector v = new Vector();

                v.add(rs.getString("name"));
                v.add(rs.getString("idnumber"));
                v.add(rs.getString("catogory"));
                v.add(rs.getString("choose"));
                v.add(rs.getString("purchasedon"));
                v.add(rs.getString("quantity"));
                v.add(rs.getString("priceperunit"));
                v.add(rs.getString("totalcost"));
                v.add(rs.getString("receiptno"));
                v.add(rs.getString("approvedby"));
                v.add(rs.getString("note"));
                v.add(rs.getBoolean("misplace"));

                dtm.addRow(v);

            }
        } catch (Exception e) {

            e.printStackTrace();
        }

        //archive table data
        try {
            Connection c = DBconnect.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT name,idnumber,catogory,choose,purchasedon,quantity,priceperunit,totalcost,receiptno,approvedby,note FROM archives");

            DefaultTableModel dtm = (DefaultTableModel) jTable2.getModel();

            while (rs.next()) {

                Vector v = new Vector();

                v.add(rs.getString("name"));
                v.add(rs.getString("idnumber"));
                v.add(rs.getString("catogory"));
                v.add(rs.getString("choose"));
                v.add(rs.getString("purchasedon"));
                v.add(rs.getString("quantity"));
                v.add(rs.getString("priceperunit"));
                v.add(rs.getString("totalcost"));
                v.add(rs.getString("receiptno"));
                v.add(rs.getString("approvedby"));
                v.add(rs.getString("note"));

                dtm.addRow(v);

            }
        } catch (Exception e) {

            e.printStackTrace();
        }

        //assestdetails data
        try {
            Connection c = DBconnect.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT nameofitem,itemid,quantity,date FROM assestdetails");

            DefaultTableModel dtm = (DefaultTableModel) jTable1.getModel();

            while (rs.next()) {

                Vector v = new Vector();

                v.add(rs.getString("nameofitem"));
                v.add(rs.getString("itemid"));
                v.add(rs.getString("quantity"));
                v.add(rs.getString("date"));
                dtm.addRow(v);

            }
        } catch (Exception e) {

            e.printStackTrace();
        }

        //invoice
        try {
            Connection c = DBconnect.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT itemname,itemid,receiptno,date,paymenttype,quantity,priceperunit,totalcost,supplier FROM invoice");

            DefaultTableModel dtm = (DefaultTableModel) jTable5.getModel();

            while (rs.next()) {

                Vector v = new Vector();

                v.add(rs.getString("itemname"));
                v.add(rs.getString("itemid"));
                v.add(rs.getString("receiptno"));
                v.add(rs.getString("date"));
                v.add(rs.getString("paymenttype"));
                v.add(rs.getString("quantity"));
                v.add(rs.getString("priceperunit"));
                v.add(rs.getString("totalcost"));
                v.add(rs.getString("supplier"));

                dtm.addRow(v);

            }
        } catch (Exception e) {

            e.printStackTrace();
        }

        //supplier details
        try {
            Connection c = DBconnect.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT name,address,telephoneno,city,storelocation FROM supplierdetails");

            DefaultTableModel dtm = (DefaultTableModel) jTable3.getModel();

            while (rs.next()) {

                Vector v = new Vector();

                v.add(rs.getString("name"));
                v.add(rs.getString("address"));
                v.add(rs.getString("telephoneno"));
                v.add(rs.getString("city"));
                v.add(rs.getString("storelocation"));
                dtm.addRow(v);

            }
        } catch (Exception e) {

            e.printStackTrace();
        }

        //current status
        try {
            Connection c = DBconnect.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT itemno,name,date FROM currentstatus");

            DefaultTableModel dtm = (DefaultTableModel) jTable6.getModel();

            while (rs.next()) {

                Vector v = new Vector();

                v.add(rs.getString("itemno"));
                v.add(rs.getString("name"));
                v.add(rs.getString("date"));
                dtm.addRow(v);

            }
        } catch (Exception e) {

            e.printStackTrace();
        }

        try {
            Connection c = DBconnect.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT name FROM supplierdetails");// Get values to combo Box to invoice
            Vector v = new Vector();

            while (rs.next()) {
                v.add(rs.getString("name"));

            }
            combosupplier.setModel(new DefaultComboBoxModel(v));

        } catch (Exception e) {

            e.printStackTrace();
        }

        try {
            Connection c = DBconnect.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT receiptno FROM invoice");// Get values to combo Box to purchasedetails
            Vector v = new Vector();

            while (rs.next()) {
                v.add(rs.getString("receiptno"));

            }
            comboreceiptnopurchase.setModel(new DefaultComboBoxModel(v));
            //  txtpatronid.grabFocus();

        } catch (Exception e) {

            e.printStackTrace();
        }

        try {
            Connection c = DBconnect.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT itemname FROM invoice");// Get values to combo Box to purchasedetails
            Vector v = new Vector();

            while (rs.next()) {
                v.add(rs.getString("itemname"));

            }

        } catch (Exception e) {

            e.printStackTrace();
        }
        autoIncrement();
    }

    private void autoIncrement() {
        try {
            Connection c = DBconnect.mycon();
            Statement s = c.createStatement();
            ResultSet rs2 = s.executeQuery("SELECT idnumber from purchasedetails ORDER BY idnumber DESC LIMIT 1 ");
            rs2.next();
            itemId = rs2.getInt(1) + 1;
            txtidnumber.setText(String.valueOf(itemId));
        } catch (Exception e) {
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        lblcategory = new javax.swing.JLabel();
        lbltotalcost = new javax.swing.JLabel();
        lblselect = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtnote = new javax.swing.JTextArea();
        btnsave = new javax.swing.JButton();
        lblpriceperunit = new javax.swing.JLabel();
        combocategory = new javax.swing.JComboBox();
        txttotalcost = new javax.swing.JTextField();
        lblreceiptno = new javax.swing.JLabel();
        txtpriceperunit = new javax.swing.JTextField();
        btnclear = new javax.swing.JButton();
        jSpinner1 = new javax.swing.JSpinner();
        lblapprovedby = new javax.swing.JLabel();
        lblitemid = new javax.swing.JLabel();
        txtidnumber = new javax.swing.JTextField();
        lblquantity = new javax.swing.JLabel();
        lblpurchasedon = new javax.swing.JLabel();
        txtapprovedby = new javax.swing.JTextField();
        lblname = new javax.swing.JLabel();
        lblnote = new javax.swing.JLabel();
        comboselect = new javax.swing.JComboBox();
        btnsearch = new javax.swing.JButton();
        btnupdate = new javax.swing.JButton();
        btndeletepur = new javax.swing.JButton();
        jDateChooser2 = new com.toedter.calendar.JDateChooser();
        comboreceiptnopurchase = new javax.swing.JComboBox();
        btnarchive = new javax.swing.JButton();
        txtname = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        viewpurto = new javax.swing.JLabel();
        viewpurfrom = new javax.swing.JLabel();
        viewpurchsdamount = new javax.swing.JButton();
        jDateChooser5 = new com.toedter.calendar.JDateChooser();
        jDateChooser4 = new com.toedter.calendar.JDateChooser();
        txthideid = new javax.swing.JTextField();
        lblamount = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        lblnameofitem = new javax.swing.JLabel();
        lblassitemid = new javax.swing.JLabel();
        lblassquantity = new javax.swing.JLabel();
        lbldate = new javax.swing.JLabel();
        txtnameofitem = new javax.swing.JTextField();
        txtitemid = new javax.swing.JTextField();
        jSpinner2 = new javax.swing.JSpinner();
        btnasssave = new javax.swing.JButton();
        btnassdelete = new javax.swing.JButton();
        btnassclear = new javax.swing.JButton();
        btnasssearch = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jLabel5 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        lblinvodate = new javax.swing.JLabel();
        lblinvoreceiptno = new javax.swing.JLabel();
        lblinvopaymenttype = new javax.swing.JLabel();
        lblitemname = new javax.swing.JLabel();
        lblinvoquantity = new javax.swing.JLabel();
        lblinvopriceperunit = new javax.swing.JLabel();
        lblinvototalcost = new javax.swing.JLabel();
        lblinvosupplier = new javax.swing.JLabel();
        lblinvoitemid = new javax.swing.JLabel();
        txtitemidinvo = new javax.swing.JTextField();
        txtitemnameinvo = new javax.swing.JTextField();
        txtreceiptnoinvo = new javax.swing.JTextField();
        combopaymenttype = new javax.swing.JComboBox();
        txtpriceperunitinvo = new javax.swing.JTextField();
        jSpinner3 = new javax.swing.JSpinner();
        txttotalcostinvo = new javax.swing.JTextField();
        combosupplier = new javax.swing.JComboBox();
        btnsaveinvo = new javax.swing.JButton();
        btnviewinvo = new javax.swing.JButton();
        jDateChooser3 = new com.toedter.calendar.JDateChooser();
        btnclearinvo = new javax.swing.JButton();
        btnsearchinvo = new javax.swing.JButton();
        btnupdateinvo = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable5 = new javax.swing.JTable();
        jLabel10 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        lblsupname = new javax.swing.JLabel();
        lblsupaddress = new javax.swing.JLabel();
        lblsuptelephoneno = new javax.swing.JLabel();
        lblsupcity = new javax.swing.JLabel();
        lblsupstorelocation = new javax.swing.JLabel();
        txtnamesupplier = new javax.swing.JTextField();
        txttelephoneno = new javax.swing.JTextField();
        txtcity = new javax.swing.JTextField();
        txtstorelocation = new javax.swing.JTextField();
        btnsavesupplier = new javax.swing.JButton();
        btndeletesup = new javax.swing.JButton();
        btnupdatesup = new javax.swing.JButton();
        btnsearchsup = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jSeparator1 = new javax.swing.JSeparator();
        jScrollPane7 = new javax.swing.JScrollPane();
        txtareaaddress = new javax.swing.JTextArea();
        jLabel8 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        txtitemnocurrent = new javax.swing.JTextField();
        lblcurrentname = new javax.swing.JLabel();
        lblcurriemid = new javax.swing.JLabel();
        btnaddcurrent = new javax.swing.JButton();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTable6 = new javax.swing.JTable();
        jLabel12 = new javax.swing.JLabel();
        jDateChooser6 = new com.toedter.calendar.JDateChooser();
        jButton1 = new javax.swing.JButton();
        txtnamecur = new javax.swing.JTextField();
        btncuradd = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        btngeneratereportselect = new javax.swing.JButton();
        lblselectreport = new javax.swing.JLabel();
        comboselectreport = new javax.swing.JComboBox();
        jPanel11 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        btngenetarereportcatogory = new javax.swing.JButton();
        datereports = new com.toedter.calendar.JDateChooser();
        btnreport1 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(22, 160, 133));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Iskoola Pota", 0, 36)); // NOI18N
        jLabel4.setText("ACQUISITION");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 10, -1, -1));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lakshiimage/logoooo.png"))); // NOI18N
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 80, 70));

        jTabbedPane1.setBackground(new java.awt.Color(255, 255, 255));
        jTabbedPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jTabbedPane1.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jTabbedPane1.setPreferredSize(new java.awt.Dimension(1024, 768));

        jPanel1.setBackground(new java.awt.Color(0, 231, 166));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblcategory.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblcategory.setText("Category           :");
        jPanel1.add(lblcategory, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 120, 100, 25));

        lbltotalcost.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lbltotalcost.setText("Total Cost        :");
        jPanel1.add(lbltotalcost, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 330, 100, 25));

        lblselect.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblselect.setText("Select              :");
        jPanel1.add(lblselect, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 160, 100, 25));

        txtnote.setColumns(20);
        txtnote.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        txtnote.setRows(5);
        jScrollPane1.setViewportView(txtnote);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 460, 463, 120));

        btnsave.setBackground(new java.awt.Color(0, 0, 0));
        btnsave.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btnsave.setForeground(new java.awt.Color(255, 255, 255));
        btnsave.setText("SAVE");
        btnsave.setContentAreaFilled(false);
        btnsave.setOpaque(true);
        btnsave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsaveActionPerformed(evt);
            }
        });
        jPanel1.add(btnsave, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 100, 100, 30));

        lblpriceperunit.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblpriceperunit.setText("Price Per Unit     :");
        jPanel1.add(lblpriceperunit, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 290, 110, 25));

        combocategory.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        combocategory.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Cheque", "Cash" }));
        combocategory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combocategoryActionPerformed(evt);
            }
        });
        jPanel1.add(combocategory, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 120, 310, 25));

        txttotalcost.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        txttotalcost.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txttotalcostActionPerformed(evt);
            }
        });
        txttotalcost.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txttotalcostKeyTyped(evt);
            }
        });
        jPanel1.add(txttotalcost, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 330, 241, 25));

        lblreceiptno.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblreceiptno.setText("Receipt No      :");
        jPanel1.add(lblreceiptno, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 380, 100, 25));

        txtpriceperunit.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        txtpriceperunit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtpriceperunitActionPerformed(evt);
            }
        });
        txtpriceperunit.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtpriceperunitKeyTyped(evt);
            }
        });
        jPanel1.add(txtpriceperunit, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 290, 241, 25));

        btnclear.setBackground(new java.awt.Color(0, 0, 0));
        btnclear.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btnclear.setForeground(new java.awt.Color(255, 255, 255));
        btnclear.setText("CLEAR");
        btnclear.setContentAreaFilled(false);
        btnclear.setOpaque(true);
        btnclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnclearActionPerformed(evt);
            }
        });
        jPanel1.add(btnclear, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 170, 100, -1));

        jSpinner1.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        jSpinner1.setModel(new javax.swing.SpinnerNumberModel(Integer.valueOf(0), Integer.valueOf(0), null, Integer.valueOf(1)));
        jSpinner1.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSpinner1StateChanged(evt);
            }
        });
        jPanel1.add(jSpinner1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 250, 77, 25));

        lblapprovedby.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblapprovedby.setText("Approved by      :");
        jPanel1.add(lblapprovedby, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 420, 100, 25));

        lblitemid.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblitemid.setText("Item ID            :");
        jPanel1.add(lblitemid, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 80, 100, 25));

        txtidnumber.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        txtidnumber.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtidnumberActionPerformed(evt);
            }
        });
        txtidnumber.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtidnumberKeyTyped(evt);
            }
        });
        jPanel1.add(txtidnumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 310, 25));

        lblquantity.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblquantity.setText("Quantity             :");
        jPanel1.add(lblquantity, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 250, 110, 25));

        lblpurchasedon.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblpurchasedon.setText("Purchased On     :");
        jPanel1.add(lblpurchasedon, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 210, 110, 25));

        txtapprovedby.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        txtapprovedby.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtapprovedbyActionPerformed(evt);
            }
        });
        jPanel1.add(txtapprovedby, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 420, 310, 25));

        lblname.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblname.setText("Name               : ");
        lblname.setAlignmentY(0.0F);
        jPanel1.add(lblname, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 30, 120, 25));

        lblnote.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblnote.setText("Note                 :");
        jPanel1.add(lblnote, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 470, 100, 25));

        comboselect.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "News Paper", "Magazine", "Book" }));
        comboselect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboselectActionPerformed(evt);
            }
        });
        jPanel1.add(comboselect, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 160, 310, 30));

        btnsearch.setBackground(new java.awt.Color(0, 0, 0));
        btnsearch.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btnsearch.setForeground(new java.awt.Color(255, 255, 255));
        btnsearch.setText("SEARCH");
        btnsearch.setContentAreaFilled(false);
        btnsearch.setOpaque(true);
        btnsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsearchActionPerformed(evt);
            }
        });
        jPanel1.add(btnsearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 230, -1, -1));

        btnupdate.setBackground(new java.awt.Color(0, 0, 0));
        btnupdate.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btnupdate.setForeground(new java.awt.Color(255, 255, 255));
        btnupdate.setText("UPDATE");
        btnupdate.setContentAreaFilled(false);
        btnupdate.setOpaque(true);
        btnupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupdateActionPerformed(evt);
            }
        });
        jPanel1.add(btnupdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 290, -1, -1));

        btndeletepur.setBackground(new java.awt.Color(0, 0, 0));
        btndeletepur.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btndeletepur.setForeground(new java.awt.Color(255, 255, 255));
        btndeletepur.setText("DELETE");
        btndeletepur.setContentAreaFilled(false);
        btndeletepur.setOpaque(true);
        btndeletepur.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndeletepurActionPerformed(evt);
            }
        });
        jPanel1.add(btndeletepur, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 340, 100, -1));

        jDateChooser2.setDateFormatString("yyyy-MM-d");
        jPanel1.add(jDateChooser2, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 200, 160, 30));

        jPanel1.add(comboreceiptnopurchase, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 370, 160, 30));

        btnarchive.setBackground(new java.awt.Color(0, 0, 0));
        btnarchive.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btnarchive.setForeground(new java.awt.Color(255, 255, 255));
        btnarchive.setText("ARCHIVE");
        btnarchive.setContentAreaFilled(false);
        btnarchive.setOpaque(true);
        btnarchive.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnarchiveActionPerformed(evt);
            }
        });
        jPanel1.add(btnarchive, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 400, 110, -1));

        txtname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnameActionPerformed(evt);
            }
        });
        txtname.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtnameKeyTyped(evt);
            }
        });
        jPanel1.add(txtname, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 30, 310, 20));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lakshiimage/4Swiral.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 950, 630));

        jTabbedPane1.addTab(" Parchased Details", jPanel1);

        jPanel6.setBackground(new java.awt.Color(0, 231, 166));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable4.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "ID Number", "Category", "Select", "Purchased On", "Quantity", "Price Per Unit", "Total Cost", "Receipt No", "Approved By", "Note", "Misplace Materials"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Boolean.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTable4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable4MouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(jTable4);

        jPanel6.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 940, 420));

        viewpurto.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        viewpurto.setText("To");
        jPanel6.add(viewpurto, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 500, 30, -1));

        viewpurfrom.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        viewpurfrom.setText("From");
        jPanel6.add(viewpurfrom, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 540, -1, -1));

        viewpurchsdamount.setBackground(new java.awt.Color(0, 0, 0));
        viewpurchsdamount.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        viewpurchsdamount.setForeground(new java.awt.Color(255, 255, 255));
        viewpurchsdamount.setText("AMOUNT");
        viewpurchsdamount.setContentAreaFilled(false);
        viewpurchsdamount.setOpaque(true);
        viewpurchsdamount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewpurchsdamountActionPerformed(evt);
            }
        });
        jPanel6.add(viewpurchsdamount, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 510, -1, -1));

        jDateChooser5.setDateFormatString("yyyy-MM-d");
        jPanel6.add(jDateChooser5, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 540, 150, 30));

        jDateChooser4.setDateFormatString("yyyy-MM-d");
        jPanel6.add(jDateChooser4, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 490, 150, 30));

        txthideid.setText("jTextField1");
        jPanel6.add(txthideid, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 10, 120, -1));

        lblamount.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel6.add(lblamount, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 510, 110, 30));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lakshiimage/4Swiral.png"))); // NOI18N
        jPanel6.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 950, 630));

        jTabbedPane1.addTab("      View Purchase Details ", jPanel6);

        jPanel2.setBackground(new java.awt.Color(0, 231, 166));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblnameofitem.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblnameofitem.setText("Name Of Item     :");
        jPanel2.add(lblnameofitem, new org.netbeans.lib.awtextra.AbsoluteConstraints(45, 100, -1, 35));

        lblassitemid.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblassitemid.setText("Item ID              :");
        jPanel2.add(lblassitemid, new org.netbeans.lib.awtextra.AbsoluteConstraints(45, 180, 110, 35));

        lblassquantity.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblassquantity.setText("Quantity            :");
        jPanel2.add(lblassquantity, new org.netbeans.lib.awtextra.AbsoluteConstraints(45, 260, 110, 35));

        lbldate.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lbldate.setText("Date                 :");
        jPanel2.add(lbldate, new org.netbeans.lib.awtextra.AbsoluteConstraints(45, 340, -1, 35));

        txtnameofitem.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        txtnameofitem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnameofitemActionPerformed(evt);
            }
        });
        jPanel2.add(txtnameofitem, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 100, 235, 35));

        txtitemid.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        txtitemid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtitemidActionPerformed(evt);
            }
        });
        jPanel2.add(txtitemid, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 180, 235, 35));

        jSpinner2.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        jSpinner2.setModel(new javax.swing.SpinnerNumberModel(Integer.valueOf(0), Integer.valueOf(0), null, Integer.valueOf(1)));
        jPanel2.add(jSpinner2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 260, 114, 35));

        btnasssave.setBackground(new java.awt.Color(0, 0, 0));
        btnasssave.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btnasssave.setForeground(new java.awt.Color(255, 255, 255));
        btnasssave.setText("SAVE");
        btnasssave.setContentAreaFilled(false);
        btnasssave.setOpaque(true);
        btnasssave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnasssaveActionPerformed(evt);
            }
        });
        jPanel2.add(btnasssave, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 520, -1, -1));

        btnassdelete.setBackground(new java.awt.Color(0, 0, 0));
        btnassdelete.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btnassdelete.setForeground(new java.awt.Color(255, 255, 255));
        btnassdelete.setText("DELETE");
        btnassdelete.setContentAreaFilled(false);
        btnassdelete.setOpaque(true);
        btnassdelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnassdeleteActionPerformed(evt);
            }
        });
        jPanel2.add(btnassdelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 520, -1, -1));

        btnassclear.setBackground(new java.awt.Color(0, 0, 0));
        btnassclear.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btnassclear.setForeground(new java.awt.Color(255, 255, 255));
        btnassclear.setText("CLEAR");
        btnassclear.setContentAreaFilled(false);
        btnassclear.setOpaque(true);
        btnassclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnassclearActionPerformed(evt);
            }
        });
        jPanel2.add(btnassclear, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 520, -1, -1));

        btnasssearch.setBackground(new java.awt.Color(0, 0, 0));
        btnasssearch.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btnasssearch.setForeground(new java.awt.Color(255, 255, 255));
        btnasssearch.setText("SEARCH");
        btnasssearch.setContentAreaFilled(false);
        btnasssearch.setOpaque(true);
        btnasssearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnasssearchActionPerformed(evt);
            }
        });
        jPanel2.add(btnasssearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 520, -1, -1));

        jTable1.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name Of Item", "Item ID", "Quantity", "Date"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable1);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(456, 55, -1, 417));

        jDateChooser1.setDateFormatString("yyyy-MM-d");
        jPanel2.add(jDateChooser1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 340, 180, 30));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lakshiimage/4Swiral.png"))); // NOI18N
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 950, 600));

        jTabbedPane1.addTab(" Assest Details ", jPanel2);

        jPanel3.setBackground(new java.awt.Color(0, 231, 166));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable2.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "ID Number", "Category", "Select", "Purchased On", "Quantity", "Price Per Unit", "Total Cost", "Receipt No", "Approved By", "Note"
            }
        ));
        jScrollPane3.setViewportView(jTable2);

        jPanel3.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(45, 45, 865, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lakshiimage/4Swiral.png"))); // NOI18N
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 950, 630));

        jTabbedPane1.addTab("Archives", jPanel3);

        jPanel4.setBackground(new java.awt.Color(0, 231, 166));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblinvodate.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblinvodate.setText("Date                 :");
        jPanel4.add(lblinvodate, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 200, 99, 35));

        lblinvoreceiptno.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblinvoreceiptno.setText("Receipt No       :");
        jPanel4.add(lblinvoreceiptno, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 150, 96, 35));

        lblinvopaymenttype.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblinvopaymenttype.setText("Payment Type      :");
        jPanel4.add(lblinvopaymenttype, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 260, -1, 35));

        lblitemname.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblitemname.setText("Item Name         :");
        jPanel4.add(lblitemname, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 40, -1, 35));

        lblinvoquantity.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblinvoquantity.setText("Quantity             :");
        jPanel4.add(lblinvoquantity, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 320, 110, 35));

        lblinvopriceperunit.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblinvopriceperunit.setText("Price Per Unit       :");
        jPanel4.add(lblinvopriceperunit, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 380, 110, 35));

        lblinvototalcost.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblinvototalcost.setText("Total Cost              :");
        jPanel4.add(lblinvototalcost, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 430, -1, 35));

        lblinvosupplier.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblinvosupplier.setText("Supplier                 :");
        jPanel4.add(lblinvosupplier, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 490, -1, 35));

        lblinvoitemid.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblinvoitemid.setText("Item ID              :");
        jPanel4.add(lblinvoitemid, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 90, 110, 35));

        txtitemidinvo.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        txtitemidinvo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtitemidinvoActionPerformed(evt);
            }
        });
        txtitemidinvo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtitemidinvoKeyTyped(evt);
            }
        });
        jPanel4.add(txtitemidinvo, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 90, 190, 35));

        txtitemnameinvo.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        txtitemnameinvo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtitemnameinvoActionPerformed(evt);
            }
        });
        jPanel4.add(txtitemnameinvo, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 40, 190, 35));

        txtreceiptnoinvo.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        txtreceiptnoinvo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtreceiptnoinvoActionPerformed(evt);
            }
        });
        txtreceiptnoinvo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtreceiptnoinvoKeyTyped(evt);
            }
        });
        jPanel4.add(txtreceiptnoinvo, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 150, 190, 35));

        combopaymenttype.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        combopaymenttype.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Cheque", "Cash" }));
        combopaymenttype.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combopaymenttypeActionPerformed(evt);
            }
        });
        jPanel4.add(combopaymenttype, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 260, 180, 35));

        txtpriceperunitinvo.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        txtpriceperunitinvo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtpriceperunitinvoActionPerformed(evt);
            }
        });
        txtpriceperunitinvo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtpriceperunitinvoKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtpriceperunitinvoKeyTyped(evt);
            }
        });
        jPanel4.add(txtpriceperunitinvo, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 380, 180, 35));

        jSpinner3.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        jSpinner3.setModel(new javax.swing.SpinnerNumberModel(Integer.valueOf(0), Integer.valueOf(0), null, Integer.valueOf(1)));
        jPanel4.add(jSpinner3, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 320, 130, 35));

        txttotalcostinvo.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        txttotalcostinvo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txttotalcostinvoActionPerformed(evt);
            }
        });
        txttotalcostinvo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txttotalcostinvoKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txttotalcostinvoKeyTyped(evt);
            }
        });
        jPanel4.add(txttotalcostinvo, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 430, 180, 35));

        combosupplier.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        combosupplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combosupplierActionPerformed(evt);
            }
        });
        jPanel4.add(combosupplier, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 490, 300, 35));

        btnsaveinvo.setBackground(new java.awt.Color(0, 0, 0));
        btnsaveinvo.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btnsaveinvo.setForeground(new java.awt.Color(255, 255, 255));
        btnsaveinvo.setText("SAVE");
        btnsaveinvo.setContentAreaFilled(false);
        btnsaveinvo.setOpaque(true);
        btnsaveinvo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsaveinvoActionPerformed(evt);
            }
        });
        jPanel4.add(btnsaveinvo, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 130, 80, 30));

        btnviewinvo.setBackground(new java.awt.Color(0, 0, 0));
        btnviewinvo.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btnviewinvo.setForeground(new java.awt.Color(255, 255, 255));
        btnviewinvo.setText("VIEW");
        btnviewinvo.setContentAreaFilled(false);
        btnviewinvo.setOpaque(true);
        btnviewinvo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnviewinvoActionPerformed(evt);
            }
        });
        jPanel4.add(btnviewinvo, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 260, 80, 30));

        jDateChooser3.setDateFormatString("yyyy-MM-d");
        jPanel4.add(jDateChooser3, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 200, 170, 30));

        btnclearinvo.setBackground(new java.awt.Color(0, 0, 0));
        btnclearinvo.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btnclearinvo.setForeground(new java.awt.Color(255, 255, 255));
        btnclearinvo.setText("CLEAR");
        btnclearinvo.setContentAreaFilled(false);
        btnclearinvo.setOpaque(true);
        btnclearinvo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnclearinvoActionPerformed(evt);
            }
        });
        jPanel4.add(btnclearinvo, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 200, -1, -1));

        btnsearchinvo.setBackground(new java.awt.Color(0, 0, 0));
        btnsearchinvo.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btnsearchinvo.setForeground(new java.awt.Color(255, 255, 255));
        btnsearchinvo.setText("SEARCH");
        btnsearchinvo.setContentAreaFilled(false);
        btnsearchinvo.setOpaque(true);
        btnsearchinvo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsearchinvoActionPerformed(evt);
            }
        });
        jPanel4.add(btnsearchinvo, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 320, -1, -1));

        btnupdateinvo.setBackground(new java.awt.Color(0, 0, 0));
        btnupdateinvo.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btnupdateinvo.setForeground(new java.awt.Color(255, 255, 255));
        btnupdateinvo.setText("UPDATE");
        btnupdateinvo.setContentAreaFilled(false);
        btnupdateinvo.setOpaque(true);
        btnupdateinvo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupdateinvoActionPerformed(evt);
            }
        });
        jPanel4.add(btnupdateinvo, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 380, -1, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lakshiimage/4Swiral.png"))); // NOI18N
        jPanel4.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 950, 600));

        jTabbedPane1.addTab("Invoice ", jPanel4);

        jPanel7.setBackground(new java.awt.Color(0, 231, 166));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable5.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        jTable5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item Name", "Item ID", "Receipt No", "Date", "Payment Type", "Quantity", "Price Per Unit", "Total Cost", "Supplier"
            }
        ));
        jScrollPane6.setViewportView(jTable5);

        jPanel7.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 930, -1));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lakshiimage/4Swiral.png"))); // NOI18N
        jPanel7.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 960, 630));

        jTabbedPane1.addTab("View Invoice Table", jPanel7);

        jPanel5.setBackground(new java.awt.Color(0, 231, 166));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblsupname.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblsupname.setText("Name             :");
        jPanel5.add(lblsupname, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 40, 100, 35));

        lblsupaddress.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblsupaddress.setText("Address         :");
        jPanel5.add(lblsupaddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 100, 92, 35));

        lblsuptelephoneno.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblsuptelephoneno.setText("Telephone No  :");
        jPanel5.add(lblsuptelephoneno, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 200, 92, 35));

        lblsupcity.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblsupcity.setText("City                :");
        jPanel5.add(lblsupcity, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 240, 92, 35));

        lblsupstorelocation.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblsupstorelocation.setText("Store Location  :");
        jPanel5.add(lblsupstorelocation, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 280, 100, 35));

        txtnamesupplier.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        txtnamesupplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnamesupplierActionPerformed(evt);
            }
        });
        jPanel5.add(txtnamesupplier, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 40, 390, 35));

        txttelephoneno.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        txttelephoneno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txttelephonenoActionPerformed(evt);
            }
        });
        txttelephoneno.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txttelephonenoKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txttelephonenoKeyTyped(evt);
            }
        });
        jPanel5.add(txttelephoneno, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 200, 220, 35));

        txtcity.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        txtcity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcityActionPerformed(evt);
            }
        });
        jPanel5.add(txtcity, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 240, 220, 35));

        txtstorelocation.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        txtstorelocation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtstorelocationActionPerformed(evt);
            }
        });
        jPanel5.add(txtstorelocation, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 280, 220, 35));

        btnsavesupplier.setBackground(new java.awt.Color(0, 0, 0));
        btnsavesupplier.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btnsavesupplier.setForeground(new java.awt.Color(255, 255, 255));
        btnsavesupplier.setText("SAVE");
        btnsavesupplier.setContentAreaFilled(false);
        btnsavesupplier.setOpaque(true);
        btnsavesupplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsavesupplierActionPerformed(evt);
            }
        });
        jPanel5.add(btnsavesupplier, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 70, 100, -1));

        btndeletesup.setBackground(new java.awt.Color(0, 0, 0));
        btndeletesup.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btndeletesup.setForeground(new java.awt.Color(255, 255, 255));
        btndeletesup.setText("DELETE");
        btndeletesup.setContentAreaFilled(false);
        btndeletesup.setOpaque(true);
        btndeletesup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndeletesupActionPerformed(evt);
            }
        });
        jPanel5.add(btndeletesup, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 130, 100, -1));

        btnupdatesup.setBackground(new java.awt.Color(0, 0, 0));
        btnupdatesup.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btnupdatesup.setForeground(new java.awt.Color(255, 255, 255));
        btnupdatesup.setText("UPDATE");
        btnupdatesup.setContentAreaFilled(false);
        btnupdatesup.setOpaque(true);
        btnupdatesup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupdatesupActionPerformed(evt);
            }
        });
        jPanel5.add(btnupdatesup, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 190, 100, -1));

        btnsearchsup.setBackground(new java.awt.Color(0, 0, 0));
        btnsearchsup.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btnsearchsup.setForeground(new java.awt.Color(255, 255, 255));
        btnsearchsup.setText("SEARCH");
        btnsearchsup.setContentAreaFilled(false);
        btnsearchsup.setOpaque(true);
        btnsearchsup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsearchsupActionPerformed(evt);
            }
        });
        jPanel5.add(btnsearchsup, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 250, 100, -1));

        jTable3.setFont(new java.awt.Font("Sakkal Majalla", 0, 18)); // NOI18N
        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Address", "Telephone No", "City", "Store Location"
            }
        ));
        jTable3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable3MouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(jTable3);

        jPanel5.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(45, 364, 849, 240));
        jPanel5.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 339, 953, 10));

        txtareaaddress.setColumns(20);
        txtareaaddress.setRows(5);
        jScrollPane7.setViewportView(txtareaaddress);

        jPanel5.add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 90, 280, -1));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lakshiimage/4Swiral.png"))); // NOI18N
        jPanel5.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 960, 630));

        jTabbedPane1.addTab("       Supplier Details      ", jPanel5);

        jPanel8.setBackground(new java.awt.Color(0, 231, 166));
        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtitemnocurrent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtitemnocurrentActionPerformed(evt);
            }
        });
        jPanel8.add(txtitemnocurrent, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 80, 150, 20));

        lblcurrentname.setText("Name     :");
        jPanel8.add(lblcurrentname, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 150, 50, 20));

        lblcurriemid.setText("Item No  :");
        jPanel8.add(lblcurriemid, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 80, 60, 20));

        btnaddcurrent.setBackground(new java.awt.Color(0, 0, 0));
        btnaddcurrent.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btnaddcurrent.setForeground(new java.awt.Color(255, 255, 255));
        btnaddcurrent.setText("ADD");
        btnaddcurrent.setContentAreaFilled(false);
        btnaddcurrent.setOpaque(true);
        btnaddcurrent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnaddcurrentActionPerformed(evt);
            }
        });
        jPanel8.add(btnaddcurrent, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 120, 100, 30));

        jTable6.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item No", "Name", "Date"
            }
        ));
        jTable6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable6MouseClicked(evt);
            }
        });
        jScrollPane8.setViewportView(jTable6);

        jPanel8.add(jScrollPane8, new org.netbeans.lib.awtextra.AbsoluteConstraints(142, 320, 610, 210));

        jLabel12.setText("Date     :");
        jPanel8.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 210, 50, 20));

        jDateChooser6.setDateFormatString("yyyy-MM-d");
        jPanel8.add(jDateChooser6, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 210, 150, 30));

        jButton1.setBackground(new java.awt.Color(0, 0, 0));
        jButton1.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("UPDATE");
        jButton1.setContentAreaFilled(false);
        jButton1.setOpaque(true);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel8.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 170, -1, 30));
        jPanel8.add(txtnamecur, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 150, 150, -1));

        btncuradd.setBackground(new java.awt.Color(0, 0, 0));
        btncuradd.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btncuradd.setForeground(new java.awt.Color(255, 255, 255));
        btncuradd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lakshiimage/4Swiral.png"))); // NOI18N
        jPanel8.add(btncuradd, new org.netbeans.lib.awtextra.AbsoluteConstraints(-4, -5, 960, 600));

        jTabbedPane1.addTab("Current Status", jPanel8);

        jPanel9.setBackground(new java.awt.Color(0, 231, 166));
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder("Purchase Details"));
        jPanel10.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btngeneratereportselect.setBackground(new java.awt.Color(0, 0, 0));
        btngeneratereportselect.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btngeneratereportselect.setForeground(new java.awt.Color(255, 255, 255));
        btngeneratereportselect.setText("GENERATE REPORT");
        btngeneratereportselect.setContentAreaFilled(false);
        btngeneratereportselect.setOpaque(true);
        btngeneratereportselect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btngeneratereportselectActionPerformed(evt);
            }
        });
        jPanel10.add(btngeneratereportselect, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 80, -1, -1));

        lblselectreport.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        lblselectreport.setText("Select     :");
        jPanel10.add(lblselectreport, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 80, -1, -1));

        comboselectreport.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        comboselectreport.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "News Paper ", "Magazine", "Book" }));
        jPanel10.add(comboselectreport, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 80, 140, -1));

        jPanel9.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 50, 730, 190));

        jPanel11.setBorder(javax.swing.BorderFactory.createTitledBorder("Purchase Details"));
        jPanel11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton3.setBackground(new java.awt.Color(0, 0, 0));
        jButton3.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("GENERATE REPORT");
        jButton3.setContentAreaFilled(false);
        jButton3.setOpaque(true);
        jPanel11.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 390, -1, -1));

        jLabel14.setText("Catogory");
        jPanel11.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 82, 70, -1));

        btngenetarereportcatogory.setBackground(new java.awt.Color(0, 0, 0));
        btngenetarereportcatogory.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btngenetarereportcatogory.setForeground(new java.awt.Color(255, 255, 255));
        btngenetarereportcatogory.setText("GENERATE REPORT");
        btngenetarereportcatogory.setContentAreaFilled(false);
        btngenetarereportcatogory.setOpaque(true);
        btngenetarereportcatogory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btngenetarereportcatogoryActionPerformed(evt);
            }
        });
        jPanel11.add(btngenetarereportcatogory, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 80, -1, -1));

        datereports.setDateFormatString("yyyy-MM-dd");
        jPanel11.add(datereports, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 80, 140, 30));

        jPanel9.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 300, 720, 200));

        btnreport1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lakshiimage/4Swiral.png"))); // NOI18N
        jPanel9.add(btnreport1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-4, -5, 960, 580));

        jTabbedPane1.addTab("Report", jPanel9);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 960, 630));

        jLabel11.setBackground(new java.awt.Color(22, 160, 133));
        jLabel11.setOpaque(true);
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1030, 720));

        jLabel1.setBackground(new java.awt.Color(22, 160, 133));
        jLabel1.setOpaque(true);
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 770));

        setSize(new java.awt.Dimension(1040, 738));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnsaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsaveActionPerformed

// TODO add your handling code here:
        try {
            int x = JOptionPane.showConfirmDialog(rootPane, "Do You Want To Save This Recode");
            if (x == 0) {

                Connection c = DBconnect.mycon();
                Statement s = c.createStatement();

                SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-d");
                String value = ((JTextField) jDateChooser2.getDateEditor().getUiComponent()).getText();
                try {
                    s.executeUpdate("INSERT INTO purchasedetails VALUES('" + txtname.getText() + "','" + txtidnumber.getText() + "','" + combocategory.getSelectedItem().toString() + "','" + comboselect.getSelectedItem().toString() + "','" + value + "','" + jSpinner1.getValue().toString() + "','" + txtpriceperunit.getText() + "','" + txttotalcost.getText() + "','" + comboreceiptnopurchase.getSelectedItem().toString() + "','" + txtapprovedby.getText() + "','" + txtnote.getText() + "','" + 0 + "')");
                    JOptionPane.showMessageDialog(rootPane, "Recode Saved Successfuly");
                    DefaultTableModel dt = (DefaultTableModel) jTable4.getModel();

                    String name = (txtname.getText());
                    int itemid = Integer.parseInt(txtidnumber.getText());
                    String catogory = (combocategory.getSelectedItem().toString());
                    String select = (comboselect.getSelectedItem().toString());
                    String date1 = (((JTextField) jDateChooser2.getDateEditor().getUiComponent()).getText());
                    int quantity = Integer.parseInt(jSpinner1.getValue().toString());
                    double priceperunit = Double.parseDouble(txtpriceperunit.getText());
                    double totalcost = Double.parseDouble(txttotalcost.getText());
                    int recipt = Integer.parseInt(comboreceiptnopurchase.getSelectedItem().toString());
                    String approve = (txtapprovedby.getText());
                    String note = (txtnote.getText());
                    dt.addRow(new Object[]{name, itemid, catogory, select, date1, quantity, priceperunit, totalcost, recipt, approve, note});

                } catch (Exception e) {
                    JOptionPane.showMessageDialog(txttelephoneno, "Please fill all records !");
                }

                txtname.setText("");
                txtidnumber.setText("");
                txtnote.setText("");
                txttotalcost.setText("");
                jDateChooser2.setDate(null);
                txtpriceperunit.setText("");
                txtapprovedby.setText("");
                autoIncrement();

            } else if (x == 1) {

                txtname.setText("");
                txtidnumber.setText("");
                txtnote.setText("");
                txttotalcost.setText("");
                jDateChooser2.setDate(null);
                txtpriceperunit.setText("");
                txtapprovedby.setText("");
                autoIncrement();

            } else {

                txtname.setText("");
                txtidnumber.setText("");
                txtnote.setText("");
                txttotalcost.setText("");
                jDateChooser2.setDate(null);
                txtpriceperunit.setText("");
                txtapprovedby.setText("");
                autoIncrement();

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        // JOptionPane.showMessageDialog(rootPane, "Please Fill All The Fields....");

    }//GEN-LAST:event_btnsaveActionPerformed

    private void txtpriceperunitKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtpriceperunitKeyTyped
        // TODO add your handling code here:
        char c = evt.getKeyChar();
        if (!(Character.isDigit(c) || (c == KeyEvent.VK_BACK_SPACE) || c == KeyEvent.VK_DELETE)) {
            getToolkit().beep();
            evt.consume();
        }
    }//GEN-LAST:event_txtpriceperunitKeyTyped

    private void txtidnumberKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtidnumberKeyTyped
        // TODO add your handling code here:
        char c = evt.getKeyChar();
        if (!(Character.isDigit(c) || (c == KeyEvent.VK_BACK_SPACE) || c == KeyEvent.VK_DELETE)) {
            getToolkit().beep();
            evt.consume();
        }
    }//GEN-LAST:event_txtidnumberKeyTyped

    private void txttotalcostKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txttotalcostKeyTyped
        // TODO add your handling code here:
        char c = evt.getKeyChar();
        if (!(Character.isDigit(c) || (c == KeyEvent.VK_BACK_SPACE) || c == KeyEvent.VK_DELETE)) {
            getToolkit().beep();
            evt.consume();
        }

    }//GEN-LAST:event_txttotalcostKeyTyped

    private void jSpinner1StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSpinner1StateChanged
    }//GEN-LAST:event_jSpinner1StateChanged

    private void btnclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnclearActionPerformed
        // TODO add your handling code here:
        txtname.setText("");
        txtidnumber.setText("");
        jDateChooser2.setDate(null);
        //txtdate.setText("");
        txtpriceperunit.setText("");
        txttotalcost.setText("");
        txtapprovedby.setText("");
        txtnote.setText("");
        autoIncrement();
    }//GEN-LAST:event_btnclearActionPerformed

    private void txtapprovedbyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtapprovedbyActionPerformed
        // TODO add your handling code here:
        txtnote.grabFocus();

    }//GEN-LAST:event_txtapprovedbyActionPerformed

    private void txtidnumberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtidnumberActionPerformed
        // TODO add your handling code here:

        try {
            Connection c = DBconnect.mycon();
            Statement s = c.createStatement();
            String q1 = "SELECT idnumber FROM purchasedetails WHERE idnumber='" + txtidnumber.getText() + "'";
            ResultSet rs = s.executeQuery(q1);
            combocategory.grabFocus();
            if (rs.first()) {
                JOptionPane.showMessageDialog(rootPane, "Invalid Item Id...Check Again");
                txtitemid.setText("");
            } else {
                combocategory.grabFocus();
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

    }//GEN-LAST:event_txtidnumberActionPerformed

    private void btnasssaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnasssaveActionPerformed
        // TODO add your handling code here:

        try {
            int x = JOptionPane.showConfirmDialog(rootPane, "Do You Want To Save This Recode");
            if (x == 0) {

                Connection c = DBconnect.mycon();
                Statement s = c.createStatement();

                SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-d");
                String value = ((JTextField) jDateChooser1.getDateEditor().getUiComponent()).getText();

                 try {
                s.executeUpdate("INSERT INTO assestdetails VALUES('" + txtnameofitem.getText() + "','" + txtitemid.getText() + "','" + jSpinner2.getValue().toString() + "','" + value + "')");
                JOptionPane.showMessageDialog(rootPane, "Recode Saved Successfuly");

               

                    DefaultTableModel dt = (DefaultTableModel) jTable1.getModel();
                    String name2 = (txtnameofitem.getText().toString());
                    int itemid = Integer.parseInt(txtitemid.getText().toString());
                    String date1 = (((JTextField) jDateChooser1.getDateEditor().getUiComponent()).getText().toString());
                    int quantity = Integer.parseInt(jSpinner1.getValue().toString());

                    dt.addRow(new Object[]{name2, itemid, quantity, date1});

                } catch (Exception e) {
                    JOptionPane.showMessageDialog(txttelephoneno,"Please fill all Records !");
                }
                 

            } else if (x == 1) {

                txtnameofitem.setText("");
                txtitemid.setText("");
                jDateChooser1.setDate(null);

            } else {

                txtnameofitem.setText("");
                txtitemid.setText("");
                jDateChooser1.setDate(null);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
      // JOptionPane.showMessageDialog(rootPane, "Please Fill All The Fields....");


    }//GEN-LAST:event_btnasssaveActionPerformed

    private void btnsaveinvoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsaveinvoActionPerformed
        // TODO add your handling code here:
        try {
            int x = JOptionPane.showConfirmDialog(rootPane, "Do You Want To Save This Recode");
            if (x == 0) {

                Connection c = DBconnect.mycon();
                Statement s = c.createStatement();

                SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-d");
                String value = ((JTextField) jDateChooser3.getDateEditor().getUiComponent()).getText();
                
                try {
                s.executeUpdate("INSERT INTO invoice VALUES('" + txtitemnameinvo.getText() + "','" + txtitemidinvo.getText() + "','" + txtreceiptnoinvo.getText() + "','" + value + "','" + combopaymenttype.getSelectedItem().toString() + "','" + jSpinner3.getValue().toString() + "','" + txtpriceperunitinvo.getText() + "','" + txttotalcostinvo.getText() + "','" + combosupplier.getSelectedItem().toString() + "')");
                JOptionPane.showMessageDialog(rootPane, "Recode Saved Successfuly");

                

                    DefaultTableModel dt = (DefaultTableModel) jTable5.getModel();

                    String nameinvo = (txtitemnameinvo.getText().toString());
                    int itemidinvo = Integer.parseInt(txtitemidinvo.getText().toString());
                    int riceiptinvo = Integer.parseInt(txtreceiptnoinvo.getText().toString());
                    String dateinvo = (((JTextField) jDateChooser3.getDateEditor().getUiComponent()).getText().toString());
                    String paytypeinvo = (combopaymenttype.getSelectedItem().toString());
                    int quantityinvo = Integer.parseInt(jSpinner3.getValue().toString());
                    double priceperunitinvo = Integer.parseInt(txtpriceperunitinvo.getText().toString());
                    double totalcostinvo = Double.parseDouble(txttotalcostinvo.getText().toString());
                    String supplierinvo = (combosupplier.getSelectedItem().toString());

                    dt.addRow(new Object[]{nameinvo, itemidinvo, riceiptinvo, dateinvo, paytypeinvo, quantityinvo, priceperunitinvo, totalcostinvo, supplierinvo});

                } catch (Exception e) {
                    JOptionPane.showMessageDialog(txttelephoneno,"Please fill all Fields !");
                }

                txtitemnameinvo.setText("");
                txtitemidinvo.setText("");
                txtreceiptnoinvo.setText("");
                jDateChooser3.setDate(null);
                txtpriceperunitinvo.setText("");
                jSpinner3.setValue(null);
                txttotalcostinvo.setText("");

            } else if (x == 1) {

                txtitemnameinvo.setText("");
                txtitemidinvo.setText("");
                txtreceiptnoinvo.setText("");
                jDateChooser3.setDate(null);
                txtpriceperunitinvo.setText("");
                jSpinner3.setValue(null);
                txttotalcostinvo.setText("");

            } else {

                txtitemnameinvo.setText("");
                txtitemidinvo.setText("");
                txtreceiptnoinvo.setText("");
                jDateChooser3.setDate(null);
                txtpriceperunitinvo.setText("");
                jSpinner3.setValue(null);
                txttotalcostinvo.setText("");

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }//GEN-LAST:event_btnsaveinvoActionPerformed

    private void combocategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combocategoryActionPerformed
        // TODO add your handling code here:
        comboselect.grabFocus();
    }//GEN-LAST:event_combocategoryActionPerformed

    private void comboselectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboselectActionPerformed
        // TODO add your handling code here:
        jDateChooser2.grabFocus();
    }//GEN-LAST:event_comboselectActionPerformed

    private void txtpriceperunitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtpriceperunitActionPerformed
        // TODO add your handling code here:
        String p = jSpinner1.getValue().toString();
        int p1 = Integer.parseInt(p);
        String Q = txtpriceperunit.getText();
        int Q1 = Integer.parseInt(Q);
        int ans = p1 * Q1;
        txttotalcost.grabFocus();
        txttotalcost.setText("" + ans);

    }//GEN-LAST:event_txtpriceperunitActionPerformed

    private void txttotalcostActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txttotalcostActionPerformed
        // TODO add your handling code here:
        comboreceiptnopurchase.grabFocus();
    }//GEN-LAST:event_txttotalcostActionPerformed

    private void btnupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupdateActionPerformed
        // TODO add your handling code here:
        try {
            Connection c = DBconnect.mycon();
            Statement s1 = c.createStatement();
            SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-d");
            String value = ((JTextField) jDateChooser2.getDateEditor().getUiComponent()).getText();
            s1.executeUpdate("UPDATE purchasedetails SET name='" + txtname.getText() + "',catogory='" + combocategory.getSelectedItem().toString() + "',choose='" + comboselect.getSelectedItem().toString() + "',purchasedon='" + value + "',quantity='" + jSpinner1.getValue().toString() + "', priceperunit='" + txtpriceperunit.getText() + "', totalcost='" + txttotalcost.getText() + "',receiptno='" + comboreceiptnopurchase.getSelectedItem().toString() + "',approvedby='" + txtapprovedby.getText() + "',note='" + txtnote.getText() + "'where idnumber='" + txtidnumber.getText() + "'");

            JOptionPane.showMessageDialog(rootPane, "Recode Update Successfuly");
            try {
                DefaultTableModel dt = (DefaultTableModel) jTable4.getModel();

                String name = (txtname.getText().toString());
                int itemid = Integer.parseInt(txtidnumber.getText().toString());
                String catogory = (combocategory.getSelectedItem().toString());
                String select = (comboselect.getSelectedItem().toString());
                String date1 = (((JTextField) jDateChooser2.getDateEditor().getUiComponent()).getText().toString());
                int quantity = Integer.parseInt(jSpinner1.getValue().toString());
                double priceperunit = Double.parseDouble(txtpriceperunit.getText().toString());
                double totalcost = Double.parseDouble(txttotalcost.getText().toString());
                int recipt = Integer.parseInt(comboreceiptnopurchase.getSelectedItem().toString());
                String approve = (txtapprovedby.getText().toString());
                String note = (txtnote.getText().toString());

                //dt.addRow(new Object[]{});
                dt.addRow(new Object[]{name, itemid, catogory, select, date1, quantity, priceperunit, totalcost, recipt, approve, note});

            } catch (Exception e) {
                e.printStackTrace();
            }

            txtname.setText("");
            txtidnumber.setText("");
            jDateChooser2.setDate(null);
            txtpriceperunit.setText("");
            txttotalcost.setText("");
            txtapprovedby.setText("");
            txtnote.setText("");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }//GEN-LAST:event_btnupdateActionPerformed

    private void btnsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsearchActionPerformed
        // TODO add your handling code here:
        try {

            Connection c = DBconnect.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM purchasedetails WHERE idnumber='" + txtidnumber.getText() + "'");
            int i = 0;
            while (rs.next()) {

                txtname.setText(rs.getString("name"));
                txtidnumber.setText(rs.getString("idnumber"));
                combocategory.setSelectedItem(rs.getString("catogory"));
                comboselect.setSelectedItem(rs.getString("choose"));
                jDateChooser2.setDate(rs.getDate("purchasedon"));
                jSpinner1.setValue(rs.getInt("quantity"));
                txtpriceperunit.setText(rs.getString("priceperunit"));
                txttotalcost.setText(rs.getString("totalcost"));
                combosupplier.setSelectedItem(rs.getString("receiptno"));
                txtapprovedby.setText(rs.getString("approvedby"));
                txtnote.setText(rs.getString("note"));

                i++;

            }
            if (i == 0) {

                JOptionPane.showMessageDialog(rootPane, "No Matching Value Found");
                txtidnumber.setText("");
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }//GEN-LAST:event_btnsearchActionPerformed

    private void viewpurchsdamountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewpurchsdamountActionPerformed
        // TODO add your handling code here:

        SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-d");
        String value = ((JTextField) jDateChooser2.getDateEditor().getUiComponent()).getText();
        try {
            Connection c = DBconnect.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("select sum(totalcost) as 'totalcost' from purchasedetails where purchasedon between '" + ((JTextField) jDateChooser4.getDateEditor().getUiComponent()).getText() + "' and '" + ((JTextField) jDateChooser5.getDateEditor().getUiComponent()).getText() + "'");
            rs.next();
            int total = rs.getInt("totalcost");

            lblamount.setText(String.valueOf(total));

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.getClass().getName() + "rs" + e);
        }
    }//GEN-LAST:event_viewpurchsdamountActionPerformed

    private void btnsavesupplierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsavesupplierActionPerformed
        // TODO add your handling code here:
        try {
            int x = JOptionPane.showConfirmDialog(rootPane, "Do You Want To Save This Recode");
            if (x == 0) {

                Connection c = DBconnect.mycon();
                Statement s = c.createStatement();
                s.executeUpdate("INSERT INTO supplierdetails VALUES('" + txtnamesupplier.getText() + "','" + txtareaaddress.getText() + "','" + txttelephoneno.getText() + "','" + txtcity.getText() + "','" + txtstorelocation.getText() + "')");
                JOptionPane.showMessageDialog(rootPane, "Recode Saved Successfuly");

                try {

                    DefaultTableModel dt = (DefaultTableModel) jTable3.getModel();
                    String namesup = (txtnamesupplier.getText());
                    String addr = (txtareaaddress.getText());
                    int phone = Integer.parseInt(txttelephoneno.getText());
                    String city = (txtcity.getText());
                    String location = (txtstorelocation.getText());

                    dt.addRow(new Object[]{namesup, addr, phone, city, location});

                } catch (Exception e) {
                    e.printStackTrace();
                }

            } else if (x == 1) {

                txtnamesupplier.setText("");
                txtareaaddress.setText("");
                txttelephoneno.setText("");
                txtcity.setText("");
                txtstorelocation.setText("");

            } else {

                txtnamesupplier.setText("");
                txtareaaddress.setText("");
                txttelephoneno.setText("");
                txtcity.setText("");
                txtstorelocation.setText("");

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }//GEN-LAST:event_btnsavesupplierActionPerformed

    private void btndeletepurActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndeletepurActionPerformed
        // TODO add your handling code here:
        try {
            int x = JOptionPane.showConfirmDialog(rootPane, "Do You Want To Delete This Recode");
            if (x == 0) {

                Connection c = DBconnect.mycon();
                Statement s = c.createStatement();
                s.executeUpdate("DELETE FROM purchasedetails WHERE idnumber ='" + txtidnumber.getText() + "'");
                JOptionPane.showMessageDialog(rootPane, "DELETED");
                DefaultTableModel dtm = (DefaultTableModel) jTable4.getModel();
                dtm.setRowCount(0);

                txtname.setText("");
                txtidnumber.setText("");
                jDateChooser2.setDate(null);
                txtpriceperunit.setText("");
                txttotalcost.setText("");
                txtapprovedby.setText("");
                txtnote.setText("");

            } else if (x == 1) {

                txtname.setText("");
                txtidnumber.setText("");
                jDateChooser2.setDate(null);
                txtpriceperunit.setText("");
                txttotalcost.setText("");
                txtapprovedby.setText("");
                txtnote.setText("");

            } else {

                txtname.setText("");
                txtidnumber.setText("");
                jDateChooser2.setDate(null);
                txtpriceperunit.setText("");
                txttotalcost.setText("");
                txtapprovedby.setText("");
                txtnote.setText("");

            }
        } catch (Exception e) {

            e.printStackTrace();
            JOptionPane.showMessageDialog(rootPane, "Erro Occurs");
        }

        try {
            Connection c = DBconnect.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT name,idnumber,catogory,choose,purchasedon,quantity,priceperunit,totalcost,receiptno,approvedby,note,misplace FROM purchasedetails");

            DefaultTableModel dtm = (DefaultTableModel) jTable4.getModel();

            while (rs.next()) {

                Vector v = new Vector();

                v.add(rs.getString("name"));
                v.add(rs.getString("idnumber"));
                v.add(rs.getString("catogory"));
                v.add(rs.getString("choose"));
                v.add(rs.getString("purchasedon"));
                v.add(rs.getString("quantity"));
                v.add(rs.getString("priceperunit"));
                v.add(rs.getString("totalcost"));
                v.add(rs.getString("receiptno"));
                v.add(rs.getString("approvedby"));
                v.add(rs.getString("note"));
                v.add(rs.getBoolean("misplace"));

                dtm.addRow(v);

            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }//GEN-LAST:event_btndeletepurActionPerformed

    private void btnassdeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnassdeleteActionPerformed
        // TODO add your handling code here:
        try {
            int x = JOptionPane.showConfirmDialog(rootPane, "Do You Want To Delete This Recode");
            if (x == 0) {

                Connection c = DBconnect.mycon();
                Statement s = c.createStatement();
                s.executeUpdate("DELETE FROM assestdetails WHERE itemid ='" + txtitemid.getText() + "'");
                JOptionPane.showMessageDialog(rootPane, "DELETED");

                DefaultTableModel dtm = (DefaultTableModel) jTable1.getModel();
                dtm.setRowCount(0);

                txtitemid.setText("");
                txtnameofitem.setText("");
                jDateChooser1.setDate(null);

            } else if (x == 1) {

                txtitemid.setText("");
                txtnameofitem.setText("");

            } else {

                txtitemid.setText("");
                txtnameofitem.setText("");

            }
        } catch (Exception e) {

            e.printStackTrace();
            JOptionPane.showMessageDialog(rootPane, "Erro Occurs");
        }

        try {
            Connection c = DBconnect.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT nameofitem,itemid,quantity,date FROM assestdetails");

            DefaultTableModel dtm = (DefaultTableModel) jTable1.getModel();

            while (rs.next()) {

                Vector v = new Vector();

                v.add(rs.getString("nameofitem"));
                v.add(rs.getString("itemid"));
                v.add(rs.getString("quantity"));
                v.add(rs.getString("date"));
                dtm.addRow(v);
            }
        } catch (Exception e) {

            e.printStackTrace();
        }

    }//GEN-LAST:event_btnassdeleteActionPerformed

    private void btnasssearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnasssearchActionPerformed
        // TODO add your handling code here:
        try {

            Connection c = DBconnect.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM assestdetails WHERE itemid='" + txtitemid.getText() + "'");

            while (rs.next()) {

                txtnameofitem.setText(rs.getString("nameofitem"));
                txtitemid.setText(rs.getString("itemid"));
                jDateChooser1.setDate(rs.getDate("date"));
                jSpinner2.setValue(rs.getInt("quantity"));
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

    }//GEN-LAST:event_btnasssearchActionPerformed

    private void btnassclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnassclearActionPerformed
        // TODO add your handling code here:
        txtnameofitem.setText("");
        txtitemid.setText("");
        jDateChooser1.setDate(null);

    }//GEN-LAST:event_btnassclearActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        txtnameofitem.setText(model.getValueAt(jTable1.getSelectedRow(), 0).toString());
        txtitemid.setText(model.getValueAt(jTable1.getSelectedRow(), 1).toString());
        ((JTextField) jDateChooser1.getDateEditor().getUiComponent()).setText(jTable1.getValueAt(jTable1.getSelectedRow(), 3).toString());

    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable3MouseClicked
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel) jTable3.getModel();
        txtnamesupplier.setText(model.getValueAt(jTable3.getSelectedRow(), 0).toString());
        txtareaaddress.setText(model.getValueAt(jTable3.getSelectedRow(), 1).toString());
        txttelephoneno.setText(model.getValueAt(jTable3.getSelectedRow(), 2).toString());
        txtcity.setText(model.getValueAt(jTable3.getSelectedRow(), 3).toString());
        txtstorelocation.setText(model.getValueAt(jTable3.getSelectedRow(), 4).toString());

    }//GEN-LAST:event_jTable3MouseClicked

    private void btndeletesupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndeletesupActionPerformed
        // TODO add your handling code here:
        try {
            int x = JOptionPane.showConfirmDialog(rootPane, "Do You Want To Delete This Recode");
            if (x == 0) {

                Connection c = DBconnect.mycon();
                Statement s = c.createStatement();
                s.executeUpdate("DELETE FROM supplierdetails WHERE name ='" + txtnamesupplier.getText() + "'");
                JOptionPane.showMessageDialog(rootPane, "DELETED");

                DefaultTableModel dtm = (DefaultTableModel) jTable3.getModel();
                dtm.setRowCount(0);

                txtnamesupplier.setText("");
                txtareaaddress.setText("");
                txttelephoneno.setText("");
                txtcity.setText("");
                txtstorelocation.setText("");

            } else if (x == 1) {

                txtnamesupplier.setText("");
                txtareaaddress.setText("");
                txttelephoneno.setText("");
                txtcity.setText("");
                txtstorelocation.setText("");

            } else {

                txtitemid.setText("");
                txtnameofitem.setText("");

            }
        } catch (Exception e) {

            e.printStackTrace();
            JOptionPane.showMessageDialog(rootPane, "Erro Occurs");
        }

        try {
            Connection c = DBconnect.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT name,address,telephoneno,city,storelocation FROM supplierdetails");

            DefaultTableModel dtm = (DefaultTableModel) jTable3.getModel();

            while (rs.next()) {

                Vector v = new Vector();

                v.add(rs.getString("name"));
                v.add(rs.getString("address"));
                v.add(rs.getString("telephoneno"));
                v.add(rs.getString("city"));
                v.add(rs.getString("storelocation"));
                dtm.addRow(v);

            }
        } catch (Exception e) {

            e.printStackTrace();
        }


    }//GEN-LAST:event_btndeletesupActionPerformed

    private void btnupdatesupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupdatesupActionPerformed
        // TODO add your handling code here:

        try {
            Connection c = DBconnect.mycon();
            Statement s1 = c.createStatement();
            s1.executeUpdate("UPDATE supplierdetails SET address='" + txtareaaddress.getText() + "', telephoneno='" + txttelephoneno.getText() + "', city='" + txtcity.getText() + "',storelocation='" + txtstorelocation.getText() + "'where name='" + txtnamesupplier.getText() + "'");

            JOptionPane.showMessageDialog(rootPane, "Recode Update Successfuly");
            try {
                DefaultTableModel dt = (DefaultTableModel) jTable3.getModel();

                String namesup = (txtnamesupplier.getText().toString());
                String address = (txtareaaddress.getText().toString());
                String tele = (txttelephoneno.getText().toString());
                String city = (txtcity.getText().toString());
                String store = (txtstorelocation.getText().toString());

                dt.addRow(new Object[]{namesup, address, tele, city, store});

            } catch (Exception e) {
                e.printStackTrace();
            }

            txtnamesupplier.setText("");
            txtareaaddress.setText("");
            txttelephoneno.setText("");
            txtcity.setText("");
            txtstorelocation.setText("");

        } catch (Exception e) {
            e.printStackTrace();
        }

    }//GEN-LAST:event_btnupdatesupActionPerformed

    private void jTable4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable4MouseClicked
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel) jTable4.getModel();
        int i = jTable4.getSelectedRow();
        txtidnumber.setText(model.getValueAt(jTable4.getSelectedRow(), 0).toString());
        txtpriceperunit.setText(model.getValueAt(jTable4.getSelectedRow(), 0).toString());
        txttotalcost.setText(model.getValueAt(jTable4.getSelectedRow(), 0).toString());
        txtapprovedby.setText(model.getValueAt(jTable4.getSelectedRow(), 0).toString());
        txtnote.setText(model.getValueAt(jTable4.getSelectedRow(), 0).toString());
        String id = model.getValueAt(i, 1).toString();
        txthideid.setText(id);
        try {
            Connection c = DBconnect.mycon();
            Statement s1 = c.createStatement();
            String query = "UPDATE purchasedetails SET misplace ='1' WHERE idnumber='" + txthideid.getText() + "'";
            int rs = s1.executeUpdate(query);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }//GEN-LAST:event_jTable4MouseClicked

    private void btnarchiveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnarchiveActionPerformed

        try {
            int x = JOptionPane.showConfirmDialog(rootPane, "Do You Want To Archive This Recode");
            if (x == 0) {

                Connection c = DBconnect.mycon();
                Statement s = c.createStatement();

                SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-d");
                String value = ((JTextField) jDateChooser2.getDateEditor().getUiComponent()).getText();

                s.executeUpdate("INSERT INTO archives VALUES('" + txtname.getText() + "','" + txtidnumber.getText() + "','" + combocategory.getSelectedItem().toString() + "','" + comboselect.getSelectedItem().toString() + "','" + value + "','" + jSpinner1.getValue().toString() + "','" + txtpriceperunit.getText() + "','" + txttotalcost.getText() + "','" + comboreceiptnopurchase.getSelectedItem().toString() + "','" + txtapprovedby.getText() + "','" + txtnote.getText() + "')");
                JOptionPane.showMessageDialog(rootPane, "Recode Archived Successfuly");
                {

                }
                jTabbedPane1.setSelectedIndex(3);

                try {

                    DefaultTableModel dt = (DefaultTableModel) jTable2.getModel();

                    String name = (txtname.getText().toString());
                    int itemid = Integer.parseInt(txtidnumber.getText().toString());
                    String catogory = (combocategory.getSelectedItem().toString());
                    String select = (comboselect.getSelectedItem().toString());
                    String date1 = (((JTextField) jDateChooser2.getDateEditor().getUiComponent()).getText().toString());
                    int quantity = Integer.parseInt(jSpinner1.getValue().toString());
                    double priceperunit = Double.parseDouble(txtpriceperunit.getText().toString());
                    double totalcost = Double.parseDouble(txttotalcost.getText().toString());
                    int recipt = Integer.parseInt(comboreceiptnopurchase.getSelectedItem().toString());
                    String approve = (txtapprovedby.getText().toString());
                    String note = (txtnote.getText().toString());

                    dt.addRow(new Object[]{name, itemid, catogory, select, date1, quantity, priceperunit, totalcost, recipt, approve, note});

                } catch (Exception e) {
                    e.printStackTrace();
                }

                txtname.setText("");
                txtidnumber.setText("");
                txtnote.setText("");
                txttotalcost.setText("");
                txtpriceperunit.setText("");
                txtapprovedby.setText("");

            } else if (x == 1) {

                txtname.setText("");
                txtidnumber.setText("");
                txtnote.setText("");
                txttotalcost.setText("");
                txtpriceperunit.setText("");
                txtapprovedby.setText("");

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {

            Connection c = DBconnect.mycon();
            Statement s = c.createStatement();
            s.executeUpdate("DELETE FROM purchasedetails WHERE idnumber ='" + txtidnumber.getText() + "'");

            txtname.setText("");
            txtidnumber.setText("");
            txtnameofitem.setText("");
            txtpriceperunit.setText("");
            txttotalcost.setText("");
            txtapprovedby.setText("");
            txtnote.setText("");
        } catch (Exception e) {

            e.printStackTrace();
            JOptionPane.showMessageDialog(rootPane, "Erro Occurs");
        }

    }//GEN-LAST:event_btnarchiveActionPerformed

    private void txttelephonenoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txttelephonenoActionPerformed
        // TODO add your handling code here:
        String tele = txttelephoneno.getText();
        if (!tele.matches("\\d{10}")) {
            JOptionPane.showMessageDialog(txttelephoneno, "Inalid Phone Number !");
            txtcity.grabFocus();

        }
    }//GEN-LAST:event_txttelephonenoActionPerformed

    private void txtnameofitemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnameofitemActionPerformed
        // TODO add your handling code here:
        txtitemid.grabFocus();
    }//GEN-LAST:event_txtnameofitemActionPerformed

    private void txtitemidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtitemidActionPerformed
        // TODO add your handling code here:
        jSpinner2.grabFocus();
    }//GEN-LAST:event_txtitemidActionPerformed

    private void btnviewinvoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnviewinvoActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(5);
    }//GEN-LAST:event_btnviewinvoActionPerformed

    private void txtitemnameinvoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtitemnameinvoActionPerformed
        // TODO add your handling code here:
        txtitemidinvo.grabFocus();
    }//GEN-LAST:event_txtitemnameinvoActionPerformed

    private void txtitemidinvoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtitemidinvoActionPerformed
        // TODO add your handling code here:

        try {
            Connection c = DBconnect.mycon();
            Statement s = c.createStatement();
            String q1 = "SELECT itemid FROM invoice WHERE itemid='" + txtitemidinvo.getText() + "'";
            ResultSet rs = s.executeQuery(q1);
            txtreceiptnoinvo.grabFocus();
            if (rs.first()) {
                JOptionPane.showMessageDialog(rootPane, "Invalid Item Id...Check Again");
                txtitemidinvo.setText("");
            } else {
                txtreceiptnoinvo.grabFocus();
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

    }//GEN-LAST:event_txtitemidinvoActionPerformed

    private void txtreceiptnoinvoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtreceiptnoinvoActionPerformed
        // TODO add your handling code here:
        jDateChooser3.grabFocus();
    }//GEN-LAST:event_txtreceiptnoinvoActionPerformed

    private void combopaymenttypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combopaymenttypeActionPerformed
        // TODO add your handling code here:
        jSpinner3.grabFocus();
    }//GEN-LAST:event_combopaymenttypeActionPerformed

    private void txtpriceperunitinvoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtpriceperunitinvoActionPerformed
        // TODO add your handling code here:

        String pinvo = jSpinner3.getValue().toString();
        int p2 = Integer.parseInt(pinvo);
        String Qinvo = txtpriceperunitinvo.getText();
        int Q1 = Integer.parseInt(Qinvo);
        int ans2 = p2 * Q1;
        txttotalcostinvo.grabFocus();
        txttotalcostinvo.setText("" + ans2);
    }//GEN-LAST:event_txtpriceperunitinvoActionPerformed

    private void txttotalcostinvoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txttotalcostinvoActionPerformed
        // TODO add your handling code here:
        combosupplier.grabFocus();
    }//GEN-LAST:event_txttotalcostinvoActionPerformed

    private void combosupplierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combosupplierActionPerformed
        // TODO add your handling code here:
        btnsaveinvo.grabFocus();
    }//GEN-LAST:event_combosupplierActionPerformed

    private void btnclearinvoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnclearinvoActionPerformed
        // TODO add your handling code here:
        txtitemnameinvo.setText("");
        txtitemidinvo.setText("");
        txtreceiptnoinvo.setText("");
        jDateChooser3.setDate(null);
        txtpriceperunitinvo.setText("");
        txttotalcostinvo.setText("");
    }//GEN-LAST:event_btnclearinvoActionPerformed

    private void btnsearchinvoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsearchinvoActionPerformed
        // TODO add your handling code here:

        try {

            Connection c = DBconnect.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM invoice WHERE itemid='" + txtitemidinvo.getText() + "'");
            int i = 0;
            while (rs.next()) {

                txtitemnameinvo.setText(rs.getString("itemname"));
                txtitemidinvo.setText(rs.getString("itemid"));
                txtreceiptnoinvo.setText(rs.getString("receiptno"));
                jDateChooser3.setDate(rs.getDate("date"));
                combopaymenttype.setSelectedItem(rs.getString("paymenttype"));
                jSpinner3.setValue(rs.getInt("quantity"));
                txtpriceperunitinvo.setText(rs.getString("priceperunit"));
                txttotalcostinvo.setText(rs.getString("totalcost"));
                combosupplier.setSelectedItem(rs.getString("supplier"));

                i++;

            }
            if (i == 0) {

                JOptionPane.showMessageDialog(rootPane, "No Matching Value Found");
                txtidnumber.setText("");
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }//GEN-LAST:event_btnsearchinvoActionPerformed

    private void btnupdateinvoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupdateinvoActionPerformed
        // TODO add your handling code here:
        try {
            Connection c = DBconnect.mycon();
            Statement s1 = c.createStatement();
            SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-d");
            String value = ((JTextField) jDateChooser3.getDateEditor().getUiComponent()).getText();
            s1.executeUpdate("UPDATE invoice SET itemname='" + txtitemnameinvo.getText() + "',receiptno='" + txtreceiptnoinvo.getText() + "',date='" + value + "',paymenttype='" + combopaymenttype.getSelectedItem().toString() + "',quantity='" + jSpinner3.getValue().toString() + "', priceperunit='" + txtpriceperunitinvo.getText() + "', totalcost='" + txttotalcostinvo.getText() + "',supplier='" + combosupplier.getSelectedItem().toString() + "'where itemid='" + txtitemidinvo.getText() + "'");

            JOptionPane.showMessageDialog(rootPane, "Recode Update Successfuly");
            try {
                DefaultTableModel dt = (DefaultTableModel) jTable5.getModel();

                String itemname = (txtitemnameinvo.getText().toString());
                int itemid1 = Integer.parseInt(txtitemidinvo.getText().toString());
                int receipt = Integer.parseInt(txtreceiptnoinvo.getText().toString());
                String date2 = (((JTextField) jDateChooser3.getDateEditor().getUiComponent()).getText().toString());
                String payment = (combopaymenttype.getSelectedItem().toString());
                int quantity1 = Integer.parseInt(jSpinner3.getValue().toString());
                double priceperunit1 = Double.parseDouble(txtpriceperunitinvo.getText().toString());
                double totalcost1 = Double.parseDouble(txttotalcostinvo.getText().toString());
                String supplier = (combosupplier.getSelectedItem().toString());

                dt.addRow(new Object[]{itemname, itemid1, receipt, date2, payment, quantity1, priceperunit1, totalcost1, supplier});

            } catch (Exception e) {
                e.printStackTrace();
            }

            txtidnumber.setText("");
            jDateChooser2.setDate(null);
            txtpriceperunit.setText("");
            txttotalcost.setText("");
            txtapprovedby.setText("");
            txtnote.setText("");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnupdateinvoActionPerformed

    private void txtnamesupplierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnamesupplierActionPerformed
        // TODO add your handling code here:
        txtareaaddress.grabFocus();
    }//GEN-LAST:event_txtnamesupplierActionPerformed

    private void txtcityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcityActionPerformed
        // TODO add your handling code here:
        txtstorelocation.grabFocus();
    }//GEN-LAST:event_txtcityActionPerformed

    private void txtstorelocationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtstorelocationActionPerformed
        // TODO add your handling code here:
        btnsavesupplier.grabFocus();
    }//GEN-LAST:event_txtstorelocationActionPerformed

    private void btnsearchsupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsearchsupActionPerformed
        // TODO add your handling code here:
        try {

            Connection c = DBconnect.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM supplierdetails WHERE name='" + txtnamesupplier.getText() + "'");

            while (rs.next()) {

                txtnamesupplier.setText(rs.getString("name"));
                txtareaaddress.setText(rs.getString("address"));
                txttelephoneno.setText(rs.getString("telephoneno"));
                txtcity.setText(rs.getString("city"));
                txtstorelocation.setText("storelocation");
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

    }//GEN-LAST:event_btnsearchsupActionPerformed

    private void btnaddcurrentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnaddcurrentActionPerformed
        // TODO add your handling code here:

        try {
            int x = JOptionPane.showConfirmDialog(rootPane, "Do You Want To Add This Recode");
            if (x == 0) {

                Connection c = DBconnect.mycon();
                Statement s = c.createStatement();

                SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-d");
                String value = ((JTextField) jDateChooser6.getDateEditor().getUiComponent()).getText();

                s.executeUpdate("INSERT INTO currentstatus VALUES('" + txtitemnocurrent.getText() + "','" + txtnamecur.getText() + "','" + value + "')");
                JOptionPane.showMessageDialog(rootPane, "Recode Add Successfuly");

                try {

                    DefaultTableModel dt = (DefaultTableModel) jTable6.getModel();
                    int itemno = Integer.parseInt(txtitemnocurrent.getText().toString());
                    String namecur = (txtnamecur.getText().toString());
                    String datecur = (((JTextField) jDateChooser6.getDateEditor().getUiComponent()).getText().toString());
                    dt.addRow(new Object[]{itemno, namecur, datecur});

                } catch (Exception e) {
                    e.printStackTrace();
                }

            } else if (x == 1) {

                txtnamecur.setText("");
                txtitemnocurrent.setText("");
                jDateChooser6.setDate(null);

            } else {

                txtnamecur.setText("");
                txtitemnocurrent.setText("");
                jDateChooser6.setDate(null);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }//GEN-LAST:event_btnaddcurrentActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:

        try {
            Connection c = DBconnect.mycon();
            Statement s1 = c.createStatement();
            SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-d");
            String value = ((JTextField) jDateChooser6.getDateEditor().getUiComponent()).getText();
            s1.executeUpdate("UPDATE currentstatus SET itemno='" + txtitemnocurrent.getText() + "', name='" + txtnamecur.getText() + "',date='" + value + "'where itemno='" + txtitemnocurrent.getText() + "'");

            JOptionPane.showMessageDialog(rootPane, "Recode Update Successfuly");
            try {
                DefaultTableModel dt = (DefaultTableModel) jTable6.getModel();

                String namecur = (txtnamecur.getText().toString());
                int itemno = Integer.parseInt(txtitemnocurrent.getText().toString());
                String datecur = (((JTextField) jDateChooser6.getDateEditor().getUiComponent()).getText().toString());
                dt.addRow(new Object[]{itemno, namecur, datecur});

            } catch (Exception e) {
                e.printStackTrace();
            }

            txtnamecur.setText("");
            txtitemnocurrent.setText("");
            jDateChooser6.setDate(null);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTable6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable6MouseClicked
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel) jTable6.getModel();
        txtitemnocurrent.setText(model.getValueAt(jTable6.getSelectedRow(), 0).toString());
        txtnamecur.setText(model.getValueAt(jTable6.getSelectedRow(), 1).toString());
        ((JTextField) jDateChooser6.getDateEditor().getUiComponent()).setText(jTable6.getValueAt(jTable6.getSelectedRow(), 2).toString());
    }//GEN-LAST:event_jTable6MouseClicked

    private void txtitemnocurrentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtitemnocurrentActionPerformed
        // TODO add your handling code here:

        try {
            Connection c = DBconnect.mycon();
            Statement s = c.createStatement();
            String q1 = "SELECT itemno FROM currentstatus WHERE itemno='" + txtitemnocurrent.getText() + "'";
            ResultSet rs = s.executeQuery(q1);
            txtnamecur.grabFocus();
            if (rs.first()) {
                JOptionPane.showMessageDialog(rootPane, "Invalid Item Id...Check Again");
                txtitemnocurrent.setText("");
            } else {
                txtnamecur.grabFocus();
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }//GEN-LAST:event_txtitemnocurrentActionPerformed

    private void txtpriceperunitinvoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtpriceperunitinvoKeyPressed
        // TODO add your handling code here:

    }//GEN-LAST:event_txtpriceperunitinvoKeyPressed

    private void txttotalcostinvoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txttotalcostinvoKeyPressed
        // TODO add your handling code here:
        char c = evt.getKeyChar();
        if (!(Character.isDigit(c) || (c == KeyEvent.VK_BACK_SPACE) || c == KeyEvent.VK_DELETE)) {
            getToolkit().beep();
            evt.consume();
        }
    }//GEN-LAST:event_txttotalcostinvoKeyPressed

    private void txttelephonenoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txttelephonenoKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txttelephonenoKeyPressed

    private void txtpriceperunitinvoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtpriceperunitinvoKeyTyped
        // TODO add your handling code here:
        char c = evt.getKeyChar();
        if (!(Character.isDigit(c) || (c == KeyEvent.VK_BACK_SPACE) || c == KeyEvent.VK_DELETE)) {
            getToolkit().beep();
            evt.consume();
        }
    }//GEN-LAST:event_txtpriceperunitinvoKeyTyped

    private void txttotalcostinvoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txttotalcostinvoKeyTyped
        // TODO add your handling code here:
        char c = evt.getKeyChar();
        if (!(Character.isDigit(c) || (c == KeyEvent.VK_BACK_SPACE) || c == KeyEvent.VK_DELETE)) {
            getToolkit().beep();
            evt.consume();
        }
    }//GEN-LAST:event_txttotalcostinvoKeyTyped

    private void txttelephonenoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txttelephonenoKeyTyped
        // TODO add your handling code here:
        char c = evt.getKeyChar();
        if (!(Character.isDigit(c) || (c == KeyEvent.VK_BACK_SPACE) || c == KeyEvent.VK_DELETE)) {
            getToolkit().beep();
            evt.consume();
        }
    }//GEN-LAST:event_txttelephonenoKeyTyped

    private void txtnameKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtnameKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnameKeyTyped

    private void txtnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnameActionPerformed
        // TODO add your handling code here:
        txtidnumber.grabFocus();
    }//GEN-LAST:event_txtnameActionPerformed

    private void txtitemidinvoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtitemidinvoKeyTyped
        // TODO add your handling code here:
        char c = evt.getKeyChar();
        if (!(Character.isDigit(c) || (c == KeyEvent.VK_BACK_SPACE) || c == KeyEvent.VK_DELETE)) {
            getToolkit().beep();
            evt.consume();
        }
    }//GEN-LAST:event_txtitemidinvoKeyTyped

    private void txtreceiptnoinvoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtreceiptnoinvoKeyTyped
        // TODO add your handling code here:
        char c = evt.getKeyChar();
        if (!(Character.isDigit(c) || (c == KeyEvent.VK_BACK_SPACE) || c == KeyEvent.VK_DELETE)) {
            getToolkit().beep();
            evt.consume();
        }
    }//GEN-LAST:event_txtreceiptnoinvoKeyTyped

    private void btngeneratereportselectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btngeneratereportselectActionPerformed
        // TODO add your handling code here:
        try {
            HashMap param = new HashMap();
            param.put("cat", comboselectreport.getSelectedItem().toString());
            param.put("cat1", comboselectreport.getSelectedItem().toString());
            param.put("cat2", comboselectreport.getSelectedItem().toString());
            MyiReportViewer viewer = new MyiReportViewer("C:\\Users\\HP Laptop\\Desktop\\Aliya Aliya\\Aliya\\Removable Disk\\2020\\Launcher\\src\\purchase\\param_select.jasper", param);
            viewer.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btngeneratereportselectActionPerformed

    private void btngenetarereportcatogoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btngenetarereportcatogoryActionPerformed
        // TODO add your handling code here:
        try {
            HashMap param = new HashMap();
            SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-d");
                String value = ((JTextField) datereports.getDateEditor().getUiComponent()).getText();
            param.put("date",value);
            
            MyiReportViewer view = new MyiReportViewer("C:\\Users\\HP Laptop\\Desktop\\Aliya Aliya\\Aliya\\Removable Disk\\2020\\Launcher\\src\\purchase\\datechkitem.jasper", param);
            view.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btngenetarereportcatogoryActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(purchasedetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(purchasedetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(purchasedetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(purchasedetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new purchasedetails().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnaddcurrent;
    private javax.swing.JButton btnarchive;
    private javax.swing.JButton btnassclear;
    private javax.swing.JButton btnassdelete;
    private javax.swing.JButton btnasssave;
    private javax.swing.JButton btnasssearch;
    private javax.swing.JButton btnclear;
    private javax.swing.JButton btnclearinvo;
    private javax.swing.JLabel btncuradd;
    private javax.swing.JButton btndeletepur;
    private javax.swing.JButton btndeletesup;
    private javax.swing.JButton btngeneratereportselect;
    private javax.swing.JButton btngenetarereportcatogory;
    private javax.swing.JLabel btnreport1;
    private javax.swing.JButton btnsave;
    private javax.swing.JButton btnsaveinvo;
    private javax.swing.JButton btnsavesupplier;
    private javax.swing.JButton btnsearch;
    private javax.swing.JButton btnsearchinvo;
    private javax.swing.JButton btnsearchsup;
    private javax.swing.JButton btnupdate;
    private javax.swing.JButton btnupdateinvo;
    private javax.swing.JButton btnupdatesup;
    private javax.swing.JButton btnviewinvo;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox combocategory;
    private javax.swing.JComboBox combopaymenttype;
    private javax.swing.JComboBox comboreceiptnopurchase;
    private javax.swing.JComboBox comboselect;
    private javax.swing.JComboBox comboselectreport;
    private javax.swing.JComboBox combosupplier;
    private com.toedter.calendar.JDateChooser datereports;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private com.toedter.calendar.JDateChooser jDateChooser2;
    private com.toedter.calendar.JDateChooser jDateChooser3;
    private com.toedter.calendar.JDateChooser jDateChooser4;
    private com.toedter.calendar.JDateChooser jDateChooser5;
    private com.toedter.calendar.JDateChooser jDateChooser6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JSpinner jSpinner2;
    private javax.swing.JSpinner jSpinner3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable4;
    private javax.swing.JTable jTable5;
    private javax.swing.JTable jTable6;
    private javax.swing.JLabel lblamount;
    private javax.swing.JLabel lblapprovedby;
    private javax.swing.JLabel lblassitemid;
    private javax.swing.JLabel lblassquantity;
    private javax.swing.JLabel lblcategory;
    private javax.swing.JLabel lblcurrentname;
    private javax.swing.JLabel lblcurriemid;
    private javax.swing.JLabel lbldate;
    private javax.swing.JLabel lblinvodate;
    private javax.swing.JLabel lblinvoitemid;
    private javax.swing.JLabel lblinvopaymenttype;
    private javax.swing.JLabel lblinvopriceperunit;
    private javax.swing.JLabel lblinvoquantity;
    private javax.swing.JLabel lblinvoreceiptno;
    private javax.swing.JLabel lblinvosupplier;
    private javax.swing.JLabel lblinvototalcost;
    private javax.swing.JLabel lblitemid;
    private javax.swing.JLabel lblitemname;
    private javax.swing.JLabel lblname;
    private javax.swing.JLabel lblnameofitem;
    private javax.swing.JLabel lblnote;
    private javax.swing.JLabel lblpriceperunit;
    private javax.swing.JLabel lblpurchasedon;
    private javax.swing.JLabel lblquantity;
    private javax.swing.JLabel lblreceiptno;
    private javax.swing.JLabel lblselect;
    private javax.swing.JLabel lblselectreport;
    private javax.swing.JLabel lblsupaddress;
    private javax.swing.JLabel lblsupcity;
    private javax.swing.JLabel lblsupname;
    private javax.swing.JLabel lblsupstorelocation;
    private javax.swing.JLabel lblsuptelephoneno;
    private javax.swing.JLabel lbltotalcost;
    private javax.swing.JTextField txtapprovedby;
    private javax.swing.JTextArea txtareaaddress;
    private javax.swing.JTextField txtcity;
    private javax.swing.JTextField txthideid;
    private javax.swing.JTextField txtidnumber;
    private javax.swing.JTextField txtitemid;
    private javax.swing.JTextField txtitemidinvo;
    private javax.swing.JTextField txtitemnameinvo;
    private javax.swing.JTextField txtitemnocurrent;
    private javax.swing.JTextField txtname;
    private javax.swing.JTextField txtnamecur;
    private javax.swing.JTextField txtnameofitem;
    private javax.swing.JTextField txtnamesupplier;
    private javax.swing.JTextArea txtnote;
    private javax.swing.JTextField txtpriceperunit;
    private javax.swing.JTextField txtpriceperunitinvo;
    private javax.swing.JTextField txtreceiptnoinvo;
    private javax.swing.JTextField txtstorelocation;
    private javax.swing.JTextField txttelephoneno;
    private javax.swing.JTextField txttotalcost;
    private javax.swing.JTextField txttotalcostinvo;
    private javax.swing.JButton viewpurchsdamount;
    private javax.swing.JLabel viewpurfrom;
    private javax.swing.JLabel viewpurto;
    // End of variables declaration//GEN-END:variables
}
