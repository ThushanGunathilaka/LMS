/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Circulations;

import static Circulations.chk.toddMMyy;
import Data.DBConnection;
import MainHome.Home;
import com.sun.org.apache.xerces.internal.impl.dtd.models.DFAContentModel;
import java.awt.Container;
import java.awt.Panel;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author Theja
 */
public class BookLend extends javax.swing.JFrame {

    /**
     * Creates new form BookLend
     */
    public BookLend() {
        initComponents();
        //this.setUndecorated(true);

        txtpatronid.setText("");
        txtaccessno.setText("");
        txtpatronidlostbook.setText("");
        txtaccessionnoreturn.setText("");
        txtpatronidreturn.setText("");
        txtamountlostbook.setText("");
        txtaccLostbook.setText("");
        txtamountpayment.setText("");
        txtrciptpayment.setText("");
        txtpatronidpayment.setText("");
        txtaccessfine.setText("");
        txtreciptfine.setText("");
        txtpatronidfine.setText("");
        txtfinereturn.setText("");
        txtpatronidreseve.setText("");
        txtaccessionresevation.setText("");
        txteditavailabelbooks.setText("");
        txtid.setVisible(false);
        txtid2.setVisible(false);
        txtid3.setVisible(false);
        txtid4payment.setVisible(false);
        txtdate3.setVisible(false);
        txtacchidepayment.setVisible(false);
        txthideidlost.setVisible(false);
        txtreserveid.setVisible(false);
        txtaccesseditcircular.setVisible(false);
        txtamountreport.setText("");
        txtpatronidedit.setVisible(false);
        txthidedate2.setVisible(false);
        Date today = new Date();
        SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd"); // set default date to text feild
        txtborrowdate.setText(date.format(today));

        //  Date today = new Date();
        Date d1 = today;
        Calendar cal = Calendar.getInstance();

        //adding 7 days to current date
        cal.setTime(today);
        cal.add(Calendar.DAY_OF_MONTH, 7);
        txtaccessno2.setText(toddMMyy(cal.getTime()));

        try {
            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM patron_type");// Get values to combo Box
            Vector v = new Vector();

            while (rs.next()) {
                v.add(rs.getString("Patron_type"));

            }
            combotype.setModel(new DefaultComboBoxModel(v));

        } catch (Exception e) {

            e.printStackTrace();
        }
        try {
            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM patron_type");// Get values to combo Box
            Vector v = new Vector();

            while (rs.next()) {
                v.add(rs.getString("Patron_type"));

            }
            combotypefine.setModel(new DefaultComboBoxModel(v));

        } catch (Exception e) {

            e.printStackTrace();
        }
        try {
            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM patron_type");// Get values to combo Box
            Vector v = new Vector();

            while (rs.next()) {
                v.add(rs.getString("Patron_type"));

            }
            combotypeborrow.setModel(new DefaultComboBoxModel(v));

        } catch (Exception e) {

            e.printStackTrace();
        }

        try {
            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM patron_type");// Get values to combo Box
            Vector v = new Vector();

            while (rs.next()) {
                v.add(rs.getString("Patron_type"));

            }
            combotypereturnview.setModel(new DefaultComboBoxModel(v));

        } catch (Exception e) {

            e.printStackTrace();
        }

        try {

            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            String query = "SELECT Id,Patron_id,Accession_no,Status,Amount,Action FROM lostbook_payment";
            ResultSet rs = s.executeQuery(query);

            DefaultTableModel dtm = (DefaultTableModel) tableunclaim.getModel();
            while (rs.next()) {

                Vector v = new Vector();
                v.add(rs.getString("Id"));
                v.add(rs.getString("Patron_id"));
                v.add(rs.getString("Accession_no"));
                v.add(rs.getString("Status"));
                v.add(rs.getString("Amount"));
                v.add(rs.getString("Action"));

                dtm.addRow(v);

            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        try {

            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            String query = "SELECT Id,Patron_id,Accession_no,Amount,Recipt_no,Date_paid FROM lostbook_payment";
            ResultSet rs = s.executeQuery(query);

            DefaultTableModel dtm = (DefaultTableModel) tablepayment.getModel();
            while (rs.next()) {

                Vector v = new Vector();

                v.add(rs.getString("Id"));
                v.add(rs.getString("Patron_id"));
                v.add(rs.getString("Accession_no"));
                v.add(rs.getString("Amount"));
                v.add(rs.getString("Recipt_no"));
                v.add(rs.getString("Date_paid"));

                dtm.addRow(v);

            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        try {

            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            String query = "SELECT * FROM reservations";
            ResultSet rs = s.executeQuery(query);

            DefaultTableModel dtm = (DefaultTableModel) tablereserve.getModel();
            while (rs.next()) {

                Vector v = new Vector();

                v.add(rs.getString("reserveID"));
                v.add(rs.getString("userID"));
                v.add(rs.getString("accessionNO"));
                v.add(rs.getString("reservedDate"));

                dtm.addRow(v);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel5 = new javax.swing.JLabel();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        panelBorrow = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        txtpatronid = new javax.swing.JTextField();
        btnborrow = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        combotype = new javax.swing.JComboBox();
        jLabel18 = new javax.swing.JLabel();
        txtaccessno = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        btnclear = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableBorrow = new javax.swing.JTable();
        txtborrowdate = new javax.swing.JTextField();
        txtaccessno2 = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        txtaccessionnoreturn = new javax.swing.JTextField();
        jPanel8 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableReturn = new javax.swing.JTable();
        jLabel24 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        txtpatronidreturn = new javax.swing.JTextField();
        btnbooklost = new javax.swing.JButton();
        btnreturn = new javax.swing.JButton();
        txtfinereturn = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jLabel26 = new javax.swing.JLabel();
        txtid = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtpatronidfine = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tablefine = new javax.swing.JTable();
        jLabel27 = new javax.swing.JLabel();
        txtaccessfine = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        txtreciptfine = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        txtid2 = new javax.swing.JTextField();
        btnpaidreturn = new javax.swing.JButton();
        datepaidfine = new com.toedter.calendar.JDateChooser();
        jLabel30 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        txtpatronidlostbook = new javax.swing.JTextField();
        txtaccLostbook = new javax.swing.JTextField();
        cmbstatuslost = new javax.swing.JComboBox();
        txtamountlostbook = new javax.swing.JTextField();
        cmbactionlost = new javax.swing.JComboBox();
        btnlostbooksave = new javax.swing.JButton();
        btnlostbookclear = new javax.swing.JButton();
        btnlostbookdelete = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        tableunclaim = new javax.swing.JTable();
        jLabel12 = new javax.swing.JLabel();
        txthideidlost = new javax.swing.JTextField();
        jPanel13 = new javax.swing.JPanel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        combotypereturnview = new javax.swing.JComboBox();
        jScrollPane5 = new javax.swing.JScrollPane();
        tablereturnview = new javax.swing.JTable();
        dateretutnview = new com.toedter.calendar.JDateChooser();
        txtdatehide = new javax.swing.JTextField();
        jLabel42 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        tableveiwfine = new javax.swing.JTable();
        combotypefine = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jScrollPane8 = new javax.swing.JScrollPane();
        tablepayment = new javax.swing.JTable();
        btnreffreshpayment = new javax.swing.JButton();
        jPanel20 = new javax.swing.JPanel();
        jLabel48 = new javax.swing.JLabel();
        txtamountpayment = new javax.swing.JTextField();
        txtpatronidpayment = new javax.swing.JTextField();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        txtrciptpayment = new javax.swing.JTextField();
        btnclearpayment1 = new javax.swing.JButton();
        txtid4payment = new javax.swing.JTextField();
        btndeletepayment1 = new javax.swing.JButton();
        datepayment = new com.toedter.calendar.JDateChooser();
        btnsavepayment = new javax.swing.JButton();
        txtacchidepayment = new javax.swing.JTextField();
        jLabel39 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tableborrowview = new javax.swing.JTable();
        jLabel17 = new javax.swing.JLabel();
        combotypeborrow = new javax.swing.JComboBox();
        dateborrowview = new com.toedter.calendar.JDateChooser();
        txtid3 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        txtaccesseditcircular = new javax.swing.JTextField();
        txtdate3 = new javax.swing.JTextField();
        txtpatronidedit = new javax.swing.JTextField();
        txtpatronideditcirrcular = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        txtamountreport = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();
        jPanel18 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        datereport = new com.toedter.calendar.JDateChooser();
        jButton6 = new javax.swing.JButton();
        jPanel19 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        comboreport = new javax.swing.JComboBox();
        jButton7 = new javax.swing.JButton();
        txthidedate2 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        panelreserve = new javax.swing.JPanel();
        jScrollPane9 = new javax.swing.JScrollPane();
        tablereserve = new javax.swing.JTable();
        txtreserveid = new javax.swing.JTextField();
        txtaccessionresevation = new javax.swing.JTextField();
        txtpatronidreseve = new javax.swing.JTextField();
        btnreserveBorrow = new javax.swing.JButton();
        txteditavailabelbooks = new javax.swing.JTextField();
        lblcount = new javax.swing.JLabel();
        btnchk = new javax.swing.JButton();
        jLabel40 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Background.jpg"))); // NOI18N

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(22, 160, 133));
        setMinimumSize(new java.awt.Dimension(1024, 768));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setText("Close");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(2127, 0, -1, -1));

        jLabel4.setText("jLabel4");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(2019, 0, -1, -1));

        jTabbedPane1.setBackground(new java.awt.Color(255, 255, 255));
        jTabbedPane1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jTabbedPane1.setToolTipText("");
        jTabbedPane1.setAutoscrolls(true);
        jTabbedPane1.setFont(new java.awt.Font("Iskoola Pota", 0, 18)); // NOI18N
        jTabbedPane1.setPreferredSize(new java.awt.Dimension(1015, 685));

        panelBorrow.setBackground(new java.awt.Color(0, 231, 166));
        panelBorrow.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel6.setText("Patron ID    :");
        panelBorrow.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 60, 86, 30));

        txtpatronid.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        txtpatronid.setText("jTextField1");
        txtpatronid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtpatronidActionPerformed(evt);
            }
        });
        txtpatronid.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtpatronidKeyTyped(evt);
            }
        });
        panelBorrow.add(txtpatronid, new org.netbeans.lib.awtextra.AbsoluteConstraints(192, 60, 185, 30));

        btnborrow.setBackground(new java.awt.Color(0, 0, 0));
        btnborrow.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btnborrow.setForeground(new java.awt.Color(255, 255, 255));
        btnborrow.setText("BORROW");
        btnborrow.setContentAreaFilled(false);
        btnborrow.setOpaque(true);
        btnborrow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnborrowActionPerformed(evt);
            }
        });
        panelBorrow.add(btnborrow, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 370, 120, 30));

        jLabel11.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel11.setText("Patron Type  :");
        panelBorrow.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 101, -1, 30));

        combotype.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        combotype.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combotypeActionPerformed(evt);
            }
        });
        panelBorrow.add(combotype, new org.netbeans.lib.awtextra.AbsoluteConstraints(192, 101, 185, 30));

        jLabel18.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel18.setText("Accession No :");
        panelBorrow.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 154, -1, -1));

        txtaccessno.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        txtaccessno.setText("jTextField4");
        txtaccessno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtaccessnoActionPerformed(evt);
            }
        });
        txtaccessno.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtaccessnoKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtaccessnoKeyTyped(evt);
            }
        });
        panelBorrow.add(txtaccessno, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 150, 185, 30));

        jLabel19.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel19.setText("Borrowed Date :");
        panelBorrow.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 203, -1, -1));

        jButton5.setBackground(new java.awt.Color(0, 0, 0));
        jButton5.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("Date");
        panelBorrow.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1248, 197, 69, 30));

        btnclear.setBackground(new java.awt.Color(0, 0, 0));
        btnclear.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btnclear.setForeground(new java.awt.Color(255, 255, 255));
        btnclear.setText("CLEAR");
        btnclear.setContentAreaFilled(false);
        btnclear.setOpaque(true);
        btnclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnclearActionPerformed(evt);
            }
        });
        panelBorrow.add(btnclear, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 320, 120, 30));

        jLabel20.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel20.setText("Return  Date :");
        panelBorrow.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 245, -1, 30));

        jPanel7.setBackground(new java.awt.Color(0, 231, 166));
        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Borrowing Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Iskoola Pota", 0, 16))); // NOI18N

        jTableBorrow.setFont(new java.awt.Font("Iskoola Pota", 0, 11)); // NOI18N
        jTableBorrow.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Patron Id", "Patron Type", "Accession No", "Borrowed Date", "Return Date"
            }
        ));
        jScrollPane1.setViewportView(jTableBorrow);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 619, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE)
                .addContainerGap())
        );

        panelBorrow.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 680, 220));

        txtborrowdate.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        txtborrowdate.setText("jTextField4");
        txtborrowdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtborrowdateActionPerformed(evt);
            }
        });
        txtborrowdate.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtborrowdateKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtborrowdateKeyTyped(evt);
            }
        });
        panelBorrow.add(txtborrowdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 200, 185, 30));

        txtaccessno2.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        txtaccessno2.setText("jTextField4");
        txtaccessno2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtaccessno2ActionPerformed(evt);
            }
        });
        txtaccessno2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtaccessno2KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtaccessno2KeyTyped(evt);
            }
        });
        panelBorrow.add(txtaccessno2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 250, 185, 30));

        jLabel22.setBackground(new java.awt.Color(0, 231, 166));
        jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/4Swiral.png"))); // NOI18N
        jLabel22.setOpaque(true);
        jLabel22.setPreferredSize(new java.awt.Dimension(1000, 685));
        panelBorrow.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 950, 560));

        jTabbedPane1.addTab("Borrow Book", panelBorrow);

        jPanel2.setBackground(new java.awt.Color(0, 231, 166));
        jPanel2.setPreferredSize(new java.awt.Dimension(800, 400));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel21.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel21.setText("Patron ID  :");
        jPanel2.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(52, 59, -1, 30));

        txtaccessionnoreturn.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        txtaccessionnoreturn.setText("jTextField7");
        txtaccessionnoreturn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtaccessionnoreturnActionPerformed(evt);
            }
        });
        jPanel2.add(txtaccessionnoreturn, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 450, 185, 30));

        jPanel8.setBackground(new java.awt.Color(0, 231, 166));
        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Return Book Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Iskoola Pota", 0, 16))); // NOI18N

        tableReturn.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        tableReturn.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Accession No", "Borrowed Date", "To Be Returned Date", "Over Due Days", "Fine Amount"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tableReturn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableReturnMouseClicked(evt);
            }
        });
        tableReturn.addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentAdded(java.awt.event.ContainerEvent evt) {
                tableReturnComponentAdded(evt);
            }
        });
        jScrollPane2.setViewportView(tableReturn);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 721, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(57, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(54, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 120, 830, 310));

        jLabel24.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel24.setText("Accession No       :");
        jPanel2.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 450, 138, 30));

        jLabel47.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel47.setText("Total Fine Amount   :");
        jPanel2.add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(61, 503, 138, 30));

        txtpatronidreturn.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        txtpatronidreturn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtpatronidreturnActionPerformed(evt);
            }
        });
        txtpatronidreturn.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtpatronidreturnKeyTyped(evt);
            }
        });
        jPanel2.add(txtpatronidreturn, new org.netbeans.lib.awtextra.AbsoluteConstraints(185, 60, 185, 30));

        btnbooklost.setBackground(new java.awt.Color(0, 0, 0));
        btnbooklost.setFont(new java.awt.Font("Iskoola Pota", 1, 12)); // NOI18N
        btnbooklost.setForeground(new java.awt.Color(255, 255, 255));
        btnbooklost.setText("BOOK LOST");
        btnbooklost.setContentAreaFilled(false);
        btnbooklost.setOpaque(true);
        btnbooklost.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbooklostActionPerformed(evt);
            }
        });
        jPanel2.add(btnbooklost, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 500, 110, -1));

        btnreturn.setBackground(new java.awt.Color(0, 0, 0));
        btnreturn.setFont(new java.awt.Font("Iskoola Pota", 1, 12)); // NOI18N
        btnreturn.setForeground(new java.awt.Color(255, 255, 255));
        btnreturn.setText("RETURN");
        btnreturn.setContentAreaFilled(false);
        btnreturn.setOpaque(true);
        btnreturn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnreturnActionPerformed(evt);
            }
        });
        jPanel2.add(btnreturn, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 500, 110, -1));

        txtfinereturn.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        txtfinereturn.setText("jTextField7");
        txtfinereturn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtfinereturnActionPerformed(evt);
            }
        });
        jPanel2.add(txtfinereturn, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 500, 185, 30));

        jButton2.setBackground(new java.awt.Color(0, 0, 0));
        jButton2.setFont(new java.awt.Font("Iskoola Pota", 1, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("FINE PAYMENT");
        jButton2.setContentAreaFilled(false);
        jButton2.setOpaque(true);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 500, -1, -1));

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/4Swiral.png"))); // NOI18N
        jLabel26.setPreferredSize(new java.awt.Dimension(1000, 685));
        jPanel2.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 960, 560));

        txtid.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        txtid.setText("jTextField7");
        txtid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtidActionPerformed(evt);
            }
        });
        jPanel2.add(txtid, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 450, 130, 30));

        jTabbedPane1.addTab("Return Book", jPanel2);

        jPanel4.setBackground(new java.awt.Color(0, 231, 166));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel2.setText("Patron ID  :");
        jPanel4.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 60, -1, 30));

        txtpatronidfine.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        txtpatronidfine.setText("jTextField8");
        txtpatronidfine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtpatronidfineActionPerformed(evt);
            }
        });
        txtpatronidfine.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtpatronidfineKeyTyped(evt);
            }
        });
        jPanel4.add(txtpatronidfine, new org.netbeans.lib.awtextra.AbsoluteConstraints(181, 58, 185, 30));

        jPanel3.setBackground(new java.awt.Color(0, 231, 166));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Fine Payment", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Iskoola Pota", 0, 16))); // NOI18N

        tablefine.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        tablefine.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Accession No", "OverDue Days", "Fine"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablefine.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablefineMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tablefine);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(68, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(49, Short.MAX_VALUE))
        );

        jPanel4.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 110, 580, 270));

        jLabel27.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel27.setText("Acession No  :");
        jPanel4.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(64, 391, 137, 30));

        txtaccessfine.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        txtaccessfine.setText("jTextField9");
        txtaccessfine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtaccessfineActionPerformed(evt);
            }
        });
        jPanel4.add(txtaccessfine, new org.netbeans.lib.awtextra.AbsoluteConstraints(211, 392, 185, 30));

        jLabel28.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel28.setText("Recipt No  :");
        jPanel4.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 440, 130, 30));

        txtreciptfine.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        txtreciptfine.setText("jTextField10");
        txtreciptfine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtreciptfineActionPerformed(evt);
            }
        });
        txtreciptfine.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtreciptfineKeyTyped(evt);
            }
        });
        jPanel4.add(txtreciptfine, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 440, 185, 30));

        jLabel29.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel29.setText("Paid Date :");
        jPanel4.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 440, 100, 30));

        jButton9.setBackground(new java.awt.Color(0, 0, 0));
        jButton9.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        jButton9.setForeground(new java.awt.Color(255, 255, 255));
        jButton9.setContentAreaFilled(false);
        jButton9.setLabel("PAID & LOST BOOK");
        jButton9.setOpaque(true);
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 500, 180, -1));

        jButton10.setBackground(new java.awt.Color(0, 0, 0));
        jButton10.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        jButton10.setForeground(new java.awt.Color(255, 255, 255));
        jButton10.setContentAreaFilled(false);
        jButton10.setLabel("CLEAR");
        jButton10.setOpaque(true);
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 500, -1, -1));

        txtid2.setText("jTextField1");
        jPanel4.add(txtid2, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 60, 110, 30));

        btnpaidreturn.setBackground(new java.awt.Color(0, 0, 0));
        btnpaidreturn.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btnpaidreturn.setForeground(new java.awt.Color(255, 255, 255));
        btnpaidreturn.setText("PAID & RETURN");
        btnpaidreturn.setContentAreaFilled(false);
        btnpaidreturn.setOpaque(true);
        btnpaidreturn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnpaidreturnActionPerformed(evt);
            }
        });
        jPanel4.add(btnpaidreturn, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 500, -1, -1));

        datepaidfine.setDateFormatString("yyyy-MM-dd");
        datepaidfine.setFont(new java.awt.Font("Iskoola Pota", 0, 11)); // NOI18N
        jPanel4.add(datepaidfine, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 440, 160, 30));

        jLabel30.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/4Swiral.png"))); // NOI18N
        jPanel4.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 960, 600));

        jTabbedPane1.addTab("Fine payment", jPanel4);

        jPanel5.setBackground(new java.awt.Color(0, 231, 166));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel10.setBackground(new java.awt.Color(0, 231, 166));
        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Entry Lost Book Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Iskoola Pota", 0, 16))); // NOI18N

        jLabel31.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel31.setText("Patron ID  :");

        jLabel32.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel32.setText("Accession No  :");

        jLabel33.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel33.setText("Status   :");

        jLabel34.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel34.setText("Amount   :");

        jLabel35.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel35.setText("Action  :");

        txtpatronidlostbook.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        txtpatronidlostbook.setText("jTextField12");
        txtpatronidlostbook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtpatronidlostbookActionPerformed(evt);
            }
        });
        txtpatronidlostbook.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtpatronidlostbookKeyTyped(evt);
            }
        });

        txtaccLostbook.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        txtaccLostbook.setText("jTextField13");
        txtaccLostbook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtaccLostbookActionPerformed(evt);
            }
        });
        txtaccLostbook.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtaccLostbookKeyTyped(evt);
            }
        });

        cmbstatuslost.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        cmbstatuslost.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Replace Price", "Lost & Unclaim" }));
        cmbstatuslost.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbstatuslostActionPerformed(evt);
            }
        });

        txtamountlostbook.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        txtamountlostbook.setText("jTextField14");

        cmbactionlost.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        cmbactionlost.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Charge For Book", "Delete Book" }));
        cmbactionlost.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbactionlostActionPerformed(evt);
            }
        });

        btnlostbooksave.setBackground(new java.awt.Color(0, 0, 0));
        btnlostbooksave.setFont(new java.awt.Font("Iskoola Pota", 1, 11)); // NOI18N
        btnlostbooksave.setForeground(new java.awt.Color(255, 255, 255));
        btnlostbooksave.setText("SAVE");
        btnlostbooksave.setContentAreaFilled(false);
        btnlostbooksave.setOpaque(true);
        btnlostbooksave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlostbooksaveActionPerformed(evt);
            }
        });

        btnlostbookclear.setBackground(new java.awt.Color(0, 0, 0));
        btnlostbookclear.setFont(new java.awt.Font("Iskoola Pota", 1, 11)); // NOI18N
        btnlostbookclear.setForeground(new java.awt.Color(255, 255, 255));
        btnlostbookclear.setText("CLEAR");
        btnlostbookclear.setContentAreaFilled(false);
        btnlostbookclear.setOpaque(true);
        btnlostbookclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlostbookclearActionPerformed(evt);
            }
        });

        btnlostbookdelete.setBackground(new java.awt.Color(0, 0, 0));
        btnlostbookdelete.setFont(new java.awt.Font("Iskoola Pota", 1, 11)); // NOI18N
        btnlostbookdelete.setForeground(new java.awt.Color(255, 255, 255));
        btnlostbookdelete.setText("DELETE");
        btnlostbookdelete.setContentAreaFilled(false);
        btnlostbookdelete.setOpaque(true);
        btnlostbookdelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlostbookdeleteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel34)
                            .addComponent(jLabel35)
                            .addComponent(btnlostbooksave, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(42, 42, 42)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addComponent(btnlostbookclear, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
                                .addComponent(btnlostbookdelete)
                                .addGap(16, 16, 16))
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cmbactionlost, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtamountlostbook, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel31)
                            .addComponent(jLabel32)
                            .addComponent(jLabel33))
                        .addGap(31, 31, 31)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cmbstatuslost, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtpatronidlostbook, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtaccLostbook, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtpatronidlostbook, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtaccLostbook, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbstatuslost, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel34)
                    .addComponent(txtamountlostbook, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbactionlost, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(80, 80, 80)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnlostbooksave, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                    .addComponent(btnlostbookclear, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                    .addComponent(btnlostbookdelete, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE))
                .addGap(76, 76, 76))
        );

        jPanel5.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 30, 400, 510));

        jPanel6.setBackground(new java.awt.Color(0, 231, 166));
        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "All Unclaim Deatils", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Iskoola Pota", 0, 16))); // NOI18N

        tableunclaim.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        tableunclaim.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Patron ID", "Accession No", "Status", "Amount", "Action"
            }
        ));
        tableunclaim.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableunclaimMouseClicked(evt);
            }
        });
        jScrollPane7.setViewportView(tableunclaim);

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/4Swiral.png"))); // NOI18N

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 436, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 960, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 610, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 447, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel5.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 470, 510));

        txthideidlost.setText("jTextField1");
        jPanel5.add(txthideidlost, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 10, 90, -1));

        jTabbedPane1.addTab("Lost Book Details", jPanel5);

        jPanel13.setBackground(new java.awt.Color(0, 231, 166));
        jPanel13.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel36.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel36.setText("Date  :");
        jPanel13.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(78, 57, 90, 30));

        jLabel37.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel37.setText("Patron Type  :");
        jPanel13.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(78, 121, -1, 30));

        combotypereturnview.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        combotypereturnview.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combotypereturnviewActionPerformed(evt);
            }
        });
        jPanel13.add(combotypereturnview, new org.netbeans.lib.awtextra.AbsoluteConstraints(199, 121, 185, 30));

        tablereturnview.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        tablereturnview.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Patron ID", "Accession No", "To Be Return Date"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane5.setViewportView(tablereturnview);

        jPanel13.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 190, 565, 313));

        dateretutnview.setDateFormatString("yyyy-MM-dd");
        jPanel13.add(dateretutnview, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 50, 180, 30));

        txtdatehide.setText("jTextField1");
        jPanel13.add(txtdatehide, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 50, 120, 30));

        jLabel42.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/4Swiral.png"))); // NOI18N
        jPanel13.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 960, 610));

        jTabbedPane1.addTab("View To Be Return Books ", jPanel13);

        jPanel9.setBackground(new java.awt.Color(0, 231, 166));
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tableveiwfine.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Patron ID", "Accession No", "Borrowed Date", "To Be Returned Date", "OverDue Days", "Fine"
            }
        ));
        jScrollPane6.setViewportView(tableveiwfine);

        jPanel9.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(65, 104, 690, 410));

        combotypefine.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        combotypefine.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        combotypefine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combotypefineActionPerformed(evt);
            }
        });
        jPanel9.add(combotypefine, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 40, 180, 30));

        jLabel1.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel1.setText("Select Type :");
        jPanel9.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 50, -1, -1));

        jLabel41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/4Swiral.png"))); // NOI18N
        jPanel9.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 950, 610));

        jTabbedPane1.addTab("View Fine Holders", jPanel9);

        jPanel12.setBackground(new java.awt.Color(0, 231, 166));
        jPanel12.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel15.setBackground(new java.awt.Color(0, 231, 166));
        jPanel15.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Payments For Lost Books", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Iskoola Pota", 0, 16))); // NOI18N

        tablepayment.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        tablepayment.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Patron ID", "Accession No", "Amount", "Recipt No", "paid Date"
            }
        ));
        tablepayment.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablepaymentMouseClicked(evt);
            }
        });
        jScrollPane8.setViewportView(tablepayment);

        btnreffreshpayment.setBackground(new java.awt.Color(0, 0, 0));
        btnreffreshpayment.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        btnreffreshpayment.setForeground(new java.awt.Color(255, 255, 255));
        btnreffreshpayment.setText("REFRESH");
        btnreffreshpayment.setContentAreaFilled(false);
        btnreffreshpayment.setOpaque(true);
        btnreffreshpayment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnreffreshpaymentActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 448, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnreffreshpayment)
                .addGap(23, 23, 23))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 414, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnreffreshpayment)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel12.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 470, 490));

        jPanel20.setBackground(new java.awt.Color(0, 231, 166));
        jPanel20.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Lost Book Payment", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Iskoola Pota", 0, 16))); // NOI18N

        jLabel48.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel48.setText("Patron ID  :");

        txtamountpayment.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        txtamountpayment.setText("jTextField12");
        txtamountpayment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtamountpaymentActionPerformed(evt);
            }
        });

        txtpatronidpayment.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        txtpatronidpayment.setText("jTextField12");
        txtpatronidpayment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtpatronidpaymentActionPerformed(evt);
            }
        });
        txtpatronidpayment.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtpatronidpaymentKeyTyped(evt);
            }
        });

        jLabel49.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel49.setText("Amount   :");

        jLabel50.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel50.setText("Date Paid   :");

        jLabel51.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel51.setText("Recipt No :");

        txtrciptpayment.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        txtrciptpayment.setText("jTextField12");
        txtrciptpayment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtrciptpaymentActionPerformed(evt);
            }
        });
        txtrciptpayment.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtrciptpaymentKeyTyped(evt);
            }
        });

        btnclearpayment1.setBackground(new java.awt.Color(0, 0, 0));
        btnclearpayment1.setFont(new java.awt.Font("Iskoola Pota", 1, 11)); // NOI18N
        btnclearpayment1.setForeground(new java.awt.Color(255, 255, 255));
        btnclearpayment1.setText("CLEAR");
        btnclearpayment1.setContentAreaFilled(false);
        btnclearpayment1.setOpaque(true);
        btnclearpayment1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnclearpayment1ActionPerformed(evt);
            }
        });

        txtid4payment.setText("jTextField1");

        btndeletepayment1.setBackground(new java.awt.Color(0, 0, 0));
        btndeletepayment1.setFont(new java.awt.Font("Iskoola Pota", 1, 11)); // NOI18N
        btndeletepayment1.setForeground(new java.awt.Color(255, 255, 255));
        btndeletepayment1.setText("DELETE");
        btndeletepayment1.setContentAreaFilled(false);
        btndeletepayment1.setOpaque(true);
        btndeletepayment1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndeletepayment1ActionPerformed(evt);
            }
        });

        datepayment.setDateFormatString("yyyy-MM-dd");
        datepayment.setFont(new java.awt.Font("Iskoola Pota", 0, 11)); // NOI18N

        btnsavepayment.setBackground(new java.awt.Color(0, 0, 0));
        btnsavepayment.setFont(new java.awt.Font("Iskoola Pota", 1, 11)); // NOI18N
        btnsavepayment.setForeground(new java.awt.Color(255, 255, 255));
        btnsavepayment.setText("SAVE");
        btnsavepayment.setContentAreaFilled(false);
        btnsavepayment.setOpaque(true);
        btnsavepayment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsavepaymentActionPerformed(evt);
            }
        });

        txtacchidepayment.setText("jTextField1");

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel20Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(jLabel48)
                        .addGap(30, 30, 30))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel20Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel20Layout.createSequentialGroup()
                                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel51)
                                    .addComponent(jLabel49))
                                .addGap(23, 23, 23))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel20Layout.createSequentialGroup()
                                .addComponent(jLabel50)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))))
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtamountpayment, javax.swing.GroupLayout.DEFAULT_SIZE, 185, Short.MAX_VALUE)
                    .addComponent(txtpatronidpayment, javax.swing.GroupLayout.DEFAULT_SIZE, 185, Short.MAX_VALUE)
                    .addComponent(txtrciptpayment, javax.swing.GroupLayout.DEFAULT_SIZE, 185, Short.MAX_VALUE)
                    .addComponent(datepayment, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(btnsavepayment, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(51, 51, 51)
                .addComponent(btnclearpayment1, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 48, Short.MAX_VALUE)
                .addComponent(btndeletepayment1, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel20Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txtacchidepayment, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(txtid4payment, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(114, 114, 114))
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel20Layout.createSequentialGroup()
                        .addComponent(txtid4payment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12))
                    .addGroup(jPanel20Layout.createSequentialGroup()
                        .addComponent(txtacchidepayment)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtpatronidpayment, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel48, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel49, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtamountpayment, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel51, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtrciptpayment, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 58, Short.MAX_VALUE)
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel50, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(datepayment, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(85, 85, 85)
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnclearpayment1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btndeletepayment1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnsavepayment, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(66, 66, 66))
        );

        jPanel12.add(jPanel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 50, 400, 490));

        jLabel39.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/4Swiral.png"))); // NOI18N
        jLabel39.setText("jLabel39");
        jPanel12.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 940, 610));

        jTabbedPane1.addTab("Payment For Lost Books", jPanel12);

        jPanel11.setBackground(new java.awt.Color(0, 231, 166));
        jPanel11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel16.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel16.setText("Date  :");
        jPanel11.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(48, 60, 84, 30));

        tableborrowview.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Patron ID", "Accession No", "Borrowed Date", "Return Date"
            }
        ));
        tableborrowview.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableborrowviewMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tableborrowview);

        jPanel11.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 170, 677, 330));

        jLabel17.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        jLabel17.setText("Patron Type   :");
        jPanel11.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(48, 122, -1, 30));

        combotypeborrow.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        combotypeborrow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combotypeborrowActionPerformed(evt);
            }
        });
        jPanel11.add(combotypeborrow, new org.netbeans.lib.awtextra.AbsoluteConstraints(142, 122, 185, 30));

        dateborrowview.setDateFormatString("yyyy-MM-dd");
        dateborrowview.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dateborrowviewMouseClicked(evt);
            }
        });
        jPanel11.add(dateborrowview, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 60, 180, 30));

        txtid3.setText("jTextField1");
        jPanel11.add(txtid3, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 50, 70, 30));

        jButton1.setBackground(new java.awt.Color(0, 0, 0));
        jButton1.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("CLEAR");
        jButton1.setContentAreaFilled(false);
        jButton1.setOpaque(true);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 520, 90, -1));

        jButton3.setBackground(new java.awt.Color(0, 0, 0));
        jButton3.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("DELETE RECODE");
        jButton3.setContentAreaFilled(false);
        jButton3.setOpaque(true);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 520, -1, -1));

        txtaccesseditcircular.setText("jTextField1");
        jPanel11.add(txtaccesseditcircular, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 30, -1, 40));

        txtdate3.setText("jTextField1");
        jPanel11.add(txtdate3, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 90, 130, 30));

        txtpatronidedit.setText("jTextField1");
        jPanel11.add(txtpatronidedit, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 80, -1, 40));

        txtpatronideditcirrcular.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        txtpatronideditcirrcular.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/4Swiral.png"))); // NOI18N
        txtpatronideditcirrcular.setToolTipText("");
        jPanel11.add(txtpatronideditcirrcular, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 940, 560));

        jTabbedPane1.addTab("Edit Cirrculations", jPanel11);

        jPanel16.setBackground(new java.awt.Color(0, 231, 166));
        jPanel16.setFont(new java.awt.Font("Iskoola Pota", 0, 18)); // NOI18N
        jPanel16.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel17.setBackground(new java.awt.Color(0, 231, 166));
        jPanel17.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createTitledBorder("Fine Holders"), "Fine Holders", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Iskoola Pota", 0, 14))); // NOI18N
        jPanel17.setFont(new java.awt.Font("Iskoola Pota", 0, 18)); // NOI18N

        jLabel13.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel13.setText("Enter Amount :");

        txtamountreport.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        txtamountreport.setText("jTextField1");

        jButton4.setBackground(new java.awt.Color(0, 0, 0));
        jButton4.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("GENERATE  REPORT");
        jButton4.setContentAreaFilled(false);
        jButton4.setOpaque(true);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txtamountreport, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 71, Short.MAX_VALUE)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtamountreport, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(67, Short.MAX_VALUE))
        );

        jPanel16.add(jPanel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 660, 150));

        jPanel18.setBackground(new java.awt.Color(0, 231, 166));
        jPanel18.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createTitledBorder(""), "Borrowed Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Iskoola Pota", 0, 14))); // NOI18N

        jLabel14.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel14.setText("Enter Date :");

        datereport.setDateFormatString("yyyy-MM-dd");
        datereport.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N

        jButton6.setBackground(new java.awt.Color(0, 0, 0));
        jButton6.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("GENERATE REPORT");
        jButton6.setContentAreaFilled(false);
        jButton6.setOpaque(true);
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(47, 47, 47)
                .addComponent(datereport, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 73, Short.MAX_VALUE)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29))
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(datereport, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(55, Short.MAX_VALUE))
        );

        jPanel16.add(jPanel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, 660, 150));

        jPanel19.setBackground(new java.awt.Color(0, 231, 166));
        jPanel19.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createTitledBorder(""), "Unclaim Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Iskoola Pota", 0, 14))); // NOI18N

        jLabel15.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel15.setText("Select The Action :");

        comboreport.setFont(new java.awt.Font("Iskoola Pota", 0, 16)); // NOI18N
        comboreport.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Replace Price", "Lost & Unclaim", " " }));
        comboreport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboreportActionPerformed(evt);
            }
        });

        jButton7.setBackground(new java.awt.Color(0, 0, 0));
        jButton7.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setText("GENERATE  REPORT");
        jButton7.setContentAreaFilled(false);
        jButton7.setOpaque(true);
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel15)
                .addGap(36, 36, 36)
                .addComponent(comboreport, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(65, 65, 65)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(41, Short.MAX_VALUE))
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(comboreport, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(78, Short.MAX_VALUE))
        );

        jPanel16.add(jPanel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 370, 670, -1));

        txthidedate2.setText("jTextField1");
        jPanel16.add(txthidedate2, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 190, 110, 30));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/4Swiral.png"))); // NOI18N
        jLabel10.setText("jLabel10");
        jPanel16.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(-3, 2, 950, 570));

        jTabbedPane1.addTab("Get Reports", jPanel16);

        panelreserve.setBackground(new java.awt.Color(0, 231, 166));
        panelreserve.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        panelreserve.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tablereserve.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        tablereserve.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Resevation ID", "Patron ID", "Accession No", "Reseved Date"
            }
        ));
        tablereserve.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablereserveMouseClicked(evt);
            }
        });
        jScrollPane9.setViewportView(tablereserve);

        panelreserve.add(jScrollPane9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, 458));

        txtreserveid.setText("jTextField1");
        panelreserve.add(txtreserveid, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 230, -1, 31));

        txtaccessionresevation.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        txtaccessionresevation.setText("jTextField2");
        txtaccessionresevation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtaccessionresevationActionPerformed(evt);
            }
        });
        panelreserve.add(txtaccessionresevation, new org.netbeans.lib.awtextra.AbsoluteConstraints(677, 142, 185, 30));

        txtpatronidreseve.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        txtpatronidreseve.setText("jTextField3");
        panelreserve.add(txtpatronidreseve, new org.netbeans.lib.awtextra.AbsoluteConstraints(677, 77, 185, 30));

        btnreserveBorrow.setBackground(new java.awt.Color(0, 0, 0));
        btnreserveBorrow.setForeground(new java.awt.Color(255, 255, 255));
        btnreserveBorrow.setText("BORROW");
        btnreserveBorrow.setContentAreaFilled(false);
        btnreserveBorrow.setOpaque(true);
        btnreserveBorrow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnreserveBorrowActionPerformed(evt);
            }
        });
        panelreserve.add(btnreserveBorrow, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 190, 90, -1));

        txteditavailabelbooks.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        txteditavailabelbooks.setText("jTextField1");
        txteditavailabelbooks.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txteditavailabelbooksActionPerformed(evt);
            }
        });
        panelreserve.add(txteditavailabelbooks, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 300, 185, 30));

        lblcount.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        lblcount.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblcountMouseClicked(evt);
            }
        });
        panelreserve.add(lblcount, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 350, 260, 30));

        btnchk.setBackground(new java.awt.Color(0, 0, 0));
        btnchk.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        btnchk.setForeground(new java.awt.Color(255, 255, 255));
        btnchk.setText("CHECK");
        btnchk.setContentAreaFilled(false);
        btnchk.setOpaque(true);
        btnchk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnchkActionPerformed(evt);
            }
        });
        panelreserve.add(btnchk, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 350, -1, -1));

        jLabel40.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel40.setText("Check Available Books :");
        panelreserve.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 300, -1, 30));

        jLabel23.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel23.setText("Patron ID :");
        panelreserve.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(563, 83, -1, -1));

        jLabel25.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel25.setText("Accession No  :");
        panelreserve.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 150, -1, -1));

        jLabel38.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/4Swiral.png"))); // NOI18N
        panelreserve.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(-5, 1, 1040, 560));

        jTabbedPane1.addTab("Check Resevations", panelreserve);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 80, 950, 620));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/logoooo.png"))); // NOI18N
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 80, 60));

        jLabel8.setBackground(new java.awt.Color(102, 51, 0));
        jLabel8.setFont(new java.awt.Font("Iskoola Pota", 0, 36)); // NOI18N
        jLabel8.setText("Circulations");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 10, 250, 50));

        jLabel9.setBackground(new java.awt.Color(22, 160, 133));
        jLabel9.setOpaque(true);
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, -10, 1040, 750));

        setSize(new java.awt.Dimension(1033, 752));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtaccessfineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtaccessfineActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtaccessfineActionPerformed

    private void txtpatronidKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtpatronidKeyTyped
        // TODO add your handling code here:
        try {
            char ch = evt.getKeyChar();
            if (!Character.isDigit(ch)) {

                evt.consume();
                Toolkit.getDefaultToolkit().beep();

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_txtpatronidKeyTyped

    private void txtpatronidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtpatronidActionPerformed
        // TODO add your handling code here:

        try {

            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT Patron_id FROM registration WHERE Patron_id='" + txtpatronid.getText() + "'");

            if (!rs.first()) {

                JOptionPane.showMessageDialog(rootPane, " Invalid Patron Id...Please Chechk Again");
                txtpatronid.setText("");
                txtpatronid.grabFocus();
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
        try {

            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();

            String select = "SELECT Patron_id,Patron_type FROM registration WHERE Patron_id='" + txtpatronid.getText() + "'";

            ResultSet rs = s.executeQuery(select);

            while (rs.next()) {
                combotype.setSelectedItem(rs.getString("Patron_type"));
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        try {

            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();

            ResultSet rs = s.executeQuery("SELECT p.Patron_id,p.Book_count,p.Patron_type,u.Maximum_book_allowed,u.Patron_type FROM registration p,patron_type u WHERE p.Patron_id='" + txtpatronid.getText() + "'and p.Patron_type=u.Patron_type");

            DefaultTableModel dtm = (DefaultTableModel) jTableBorrow.getModel();

            while (rs.next()) {
                int maxcount = rs.getInt("u.Maximum_book_allowed");
                int borrowcount = rs.getInt("p.Book_count");
                //combotype.setSelectedItem(rs.getString("p.Patron_type"));

                if (borrowcount == maxcount) {

                    JOptionPane.showMessageDialog(rootPane, "Please Return Books Before Borrowing");
                    btnborrow.setEnabled(false);

                    Statement st = c.createStatement();
                    ResultSet result = st.executeQuery("SELECT Patron_id,User_type,Accession_no,Borrow_date,To_be_return_date FROM cirrculation WHERE Patron_id='" + txtpatronid.getText() + "'and Status = 'Borrow'");

                    while (result.next()) {

                        Vector v = new Vector();

                        v.add(result.getString("Patron_id"));
                        v.add(result.getString("User_type"));
                        v.add(result.getString("Accession_no"));
                        v.add(result.getString("Borrow_date"));
                        v.add(result.getString("To_be_return_date"));

                        dtm.addRow(v);

                    }

                } else {

                    Statement st = c.createStatement();
                    ResultSet result = st.executeQuery("SELECT Patron_id,User_type,Accession_no,Borrow_date,To_be_return_date FROM cirrculation WHERE Patron_id='" + txtpatronid.getText() + "'and Status = 'Borrow'");

                    while (result.next()) {

                        Vector v = new Vector();

                        v.add(result.getString("Patron_id"));
                        v.add(result.getString("User_type"));
                        v.add(result.getString("Accession_no"));
                        v.add(result.getString("Borrow_date"));
                        v.add(result.getString("To_be_return_date"));

                        dtm.addRow(v);
                        btnborrow.setEnabled(true);

                    }
                }

            }

        } catch (Exception e) {

            e.printStackTrace();
        }

//        try {
//            Connection c = DBConnection.mycon();
//            Statement s = c.createStatement();
//            String query = "Select Count(*) from cirrculation where Patron_id='" + txtpatronid.getText() + "'and Status='Borrow'";
//            ResultSet rs = s.executeQuery(query);
//            rs.next();
//            int count = rs.getInt(1);
//            String cout1 = String.valueOf(count);
//            //System.out.println(count);
//
//            Statement s1 = c.createStatement();
//            String query1 = "UPDATE registration  SET Book_count ='" + cout1 + "' WHERE Patron_id='" + txtpatronid.getText() + "'";
//            int rs1 = s1.executeUpdate(query1);
//
//            //   System.out.println(rs1);
//        } catch (Exception e) {
//
//            e.printStackTrace();
//        }
        try {

            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();

            String select = "SELECT Patron_id,patron_type FROM registration WHERE'" + txtpatronid.getText() + "'";

            ResultSet rs = s.executeQuery(select);

            while (rs.next()) {
                combotype.setSelectedItem(rs.getString("Patron_type"));
            }

        } catch (Exception e) {

            e.printStackTrace();
        }


    }//GEN-LAST:event_txtpatronidActionPerformed

    private void btnclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnclearActionPerformed
        // TODO add your handling code here:
        try {

            txtpatronid.setText("");
            txtaccessno.setText("");

            DefaultTableModel dtm = (DefaultTableModel) jTableBorrow.getModel();
            dtm.setRowCount(0);

            txtpatronid.grabFocus();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnclearActionPerformed

    private void btnborrowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnborrowActionPerformed
        // TODO add your handling code here:

        try {
            int x = JOptionPane.showConfirmDialog(rootPane, "Do You Want to Save !");

            if (x == 0) {

                Connection c = DBConnection.mycon();
                Statement s = c.createStatement();
                SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");

                Date today = new Date();
                Date d1 = today;
                Calendar cal = Calendar.getInstance();

                //adding 7 days to current date
                cal.setTime(today);
                cal.add(Calendar.DAY_OF_MONTH, 7);

                String query1 = "INSERT INTO cirrculation (`Patron_id`,`user_type`,`Accession_no`,`Borrow_date`,`To_be_return_date`,`Status`) VALUES('" + txtpatronid.getText() + "','" + combotype.getSelectedItem().toString() + "','" + txtaccessno.getText() + "','" + txtborrowdate.getText() + "','" + toddMMyy(cal.getTime()) + "','" + "Borrow" + "')";
                s.executeUpdate(query1);
//                ResultSet rs1 = null;
//                s.executeUpdate(query1, Statement.RETURN_GENERATED_KEYS);
//                rs1 = s.getGeneratedKeys();
//                rs1.next();
//                int id3 = rs1.getInt(1);

//                DefaultTableModel dtm = (DefaultTableModel) tableborrowview.getModel();
//                int pid = Integer.parseInt(txtpatronid.getText());
//               // String type = combotype.getSelectedItem().toString();
//                int acc_no = Integer.parseInt(txtaccessno.getText());
//                String dateborrow = txtborrowdate.getText();
//                String datereturn = txtaccessno2.getText();
//
//                dtm.addRow(new Object[]{id3, pid,  acc_no, dateborrow, datereturn});

                JOptionPane.showMessageDialog(rootPane, "Book Borrowed Successfully");

                //reduce book count   
                Statement s1 = c.createStatement();
                String query2 = "SELECT accessionNO,isAvailable FROM copies WHERE accessionNo='" + txtaccessno.getText() + "' ";
                ResultSet rs = s1.executeQuery(query2);


                Statement s3 = c.createStatement();
                String query3 = "UPDATE copies SET isAvailable='0' WHERE accessionNo='" + txtaccessno.getText() + "'";
                s3.executeUpdate(query3);

//                txtpatronid.setText("");
//                txtaccessno.setText("");
//                dtm.setRowCount(0);
                DefaultTableModel dt = (DefaultTableModel) tableborrowview.getModel();

                int id = Integer.parseInt(txtpatronid.getText());
                int access = Integer.parseInt(txtaccessno.getText());
                String date1 = txtborrowdate.getText();
                String date2 = txtaccessno2.getText();

                dt.addRow(new Object[]{id, access, date1, date2,});

            } else if (x == 1) {

                txtpatronid.setText("");
                txtaccessno.setText("");

                DefaultTableModel dtm = (DefaultTableModel) jTableBorrow.getModel();
                dtm.setRowCount(0);

            } else {

                txtpatronid.setText("");
                txtaccessno.setText("");

                DefaultTableModel dtm = (DefaultTableModel) jTableBorrow.getModel();
                dtm.setRowCount(0);

            }

        } catch (Exception e) {

            e.printStackTrace();
        }
        try {
            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            String query = "Select Count(*) from cirrculation where Patron_id='" + txtpatronid.getText() + "'and Status='Borrow'";
            ResultSet rs = s.executeQuery(query);
            rs.next();
            int count = rs.getInt(1);
            String cout1 = String.valueOf(count);
            //System.out.println(count);

            Statement s1 = c.createStatement();
            String query1 = "UPDATE registration  SET Book_count ='" + cout1 + "' WHERE Patron_id='" + txtpatronid.getText() + "'";
            int rs1 = s1.executeUpdate(query1);

            txtpatronid.setText("");
            txtaccessno.setText("");

            DefaultTableModel dtm = (DefaultTableModel) jTableBorrow.getModel();
            dtm.setRowCount(0);

            //   System.out.println(rs1);
        } catch (Exception e) {

            e.printStackTrace();
        }


    }//GEN-LAST:event_btnborrowActionPerformed
    public static String toddMMyy(Date day) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); //date setting method
        String date = formatter.format(day);
        return date;
    }
    private void txtaccessnoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtaccessnoKeyPressed
        // TODO add your handling code here:

    }//GEN-LAST:event_txtaccessnoKeyPressed

    private void txtaccessnoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtaccessnoKeyTyped
        // TODO add your handling code here:
        try {
            char ch = evt.getKeyChar();
            if (!Character.isDigit(ch)) {

                evt.consume();
                Toolkit.getDefaultToolkit().beep();

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_txtaccessnoKeyTyped

    private void txtaccessnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtaccessnoActionPerformed
        // TODO add your handling code here:
        try {

            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT accessionNo FROM copies WHERE accessionNo='" + txtaccessno.getText() + "'");
            btnborrow.grabFocus();

            if (!rs.first()) {

                JOptionPane.showMessageDialog(rootPane, " Invalid Accession Number...Please Chechk Again");
                txtaccessno.setText("");
                txtaccessno.grabFocus();
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
        try {

            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT accessionNo,isAvailable FROM copies WHERE accessionNo='" + txtaccessno.getText() + "'");

            if (rs.next()) {

                boolean bookcount = rs.getBoolean("isAvailable");

                if (bookcount == false) {

                    JOptionPane.showMessageDialog(datepayment, "Not Available !..");
                    //btnborrow.setEnabled(true);
                    txtaccessno.setText("");
                }

            }

        } catch (Exception e) {

            e.printStackTrace();
        }


    }//GEN-LAST:event_txtaccessnoActionPerformed

    private void combotypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combotypeActionPerformed
        // TODO add your handling code here:
        txtaccessno.grabFocus();
    }//GEN-LAST:event_combotypeActionPerformed

    private void txtpatronidreturnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtpatronidreturnActionPerformed
        // TODO add your handling code here:
        try {

            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT Patron_id FROM registration WHERE Patron_id='" + txtpatronidreturn.getText() + "'");

            if (!rs.first()) {

                JOptionPane.showMessageDialog(rootPane, " Invalid Patron Id...Please Chechk Again");
                txtpatronidreturn.setText("");
                txtpatronidreturn.grabFocus();
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
        try {

            Connection c = DBConnection.mycon();
            Statement s2 = c.createStatement();
            String type1 = "Clergy";
            String type2 = "Staff";
            String query = "SELECT Id,Patron_id,To_be_return_date,User_type FROM cirrculation WHERE Patron_id='" + txtpatronidreturn.getText() + "'and status='Borrow'";
            ResultSet rs1 = s2.executeQuery(query);

            Date today = new Date();
            long DAY_IN_MILLIS = 1000 * 60 * 60 * 24;
            int fineamount = 0, overduedays = 0;
            String qeury1 = "";
            Calendar cal = Calendar.getInstance();
            cal.setTime(today);
            while (rs1.next()) {

                String u_type = rs1.getString("User_type");
                int val = u_type.compareTo(type1);
                int val1 = u_type.compareTo(type2);

                Date tobereturn = rs1.getDate(3);
                System.out.println(tobereturn);
                if (val < 0 && val1 < 0) {

                    // int overduedays = today.getDate() - tobereturn.getDate();             
                    overduedays = (int) ((today.getTime() - tobereturn.getTime()) / DAY_IN_MILLIS);
                    if (overduedays > 0) {
                        String overdue = String.valueOf(overduedays);
                        fineamount = overduedays * 5;
                        String fine = String.valueOf(fineamount);

                        Statement s1 = c.createStatement();
                        qeury1 = "UPDATE cirrculation SET Return_date='" + toddMMyy(cal.getTime()) + "',Over_due_days='" + overdue + "',Fine='" + fine + "' WHERE Id='" + rs1.getString(1) + "'and Status='Borrow'";
                        s1.executeUpdate(qeury1);
                    } else {
                        qeury1 = "UPDATE cirrculation SET Return_date='" + toddMMyy(cal.getTime()) + "',Over_due_days='0',Fine='0' WHERE Id='" + rs1.getString(1) + "'and Status='Borrow'";
                    }
                    Statement s1 = c.createStatement();

                    s1.executeUpdate(qeury1);
                } else {

                    Statement s1 = c.createStatement();
                    qeury1 = "UPDATE cirrculation SET Return_date='" + toddMMyy(cal.getTime()) + "',Fine = 0,Over_due_days = 0 WHERE Id='" + rs1.getString(1) + "'and Status='Borrow'";
                    int r = s1.executeUpdate(qeury1);

                }
            }

            Statement st = c.createStatement();
            ResultSet result = st.executeQuery("SELECT Id,Patron_id,Accession_no,Borrow_date,To_be_return_date,Fine,Over_due_days FROM cirrculation WHERE Patron_id='" + txtpatronidreturn.getText() + "'and Status = 'Borrow'");

            DefaultTableModel dtm = (DefaultTableModel) tableReturn.getModel();
            dtm.setRowCount(0);
            while (result.next()) {

                Vector v = new Vector();
                v.add(result.getString("Id"));
                v.add(result.getString("Accession_no"));
                v.add(result.getString("Borrow_date"));
                v.add(result.getString("To_be_return_date"));
                //  v.add(result.getString("Return_date"));
                v.add(result.getString("Over_due_days"));
                v.add(result.getString("Fine"));

                dtm.addRow(v);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }


    }//GEN-LAST:event_txtpatronidreturnActionPerformed

    private void txtpatronidreturnKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtpatronidreturnKeyTyped
        // TODO add your handling code here:
        try {
            char ch = evt.getKeyChar();
            if (!Character.isDigit(ch)) {

                evt.consume();
                Toolkit.getDefaultToolkit().beep();

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_txtpatronidreturnKeyTyped

    private void txtaccessionnoreturnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtaccessionnoreturnActionPerformed
        // TODO add your handling code here:
        try {

            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT accessionNo FROM cpoies WHERE accessionNo='" + txtaccessionnoreturn.getText() + "'");
            ;

            if (!rs.first()) {

                JOptionPane.showMessageDialog(rootPane, " Invalid Accession Number...Please Chechk Again");
                txtaccessionnoreturn.setText("");
                txtaccessionnoreturn.grabFocus();
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }//GEN-LAST:event_txtaccessionnoreturnActionPerformed

    private void txtpatronidlostbookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtpatronidlostbookActionPerformed
        // TODO add your handling code here:

        try {

            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT Patron_id FROM registration WHERE Patron_id='" + txtpatronidlostbook.getText() + "'");

            if (!rs.first()) {

                JOptionPane.showMessageDialog(rootPane, " Invalid Patron Id...Please Chechk Again");
                txtpatronidlostbook.setText("");
                txtpatronidlostbook.grabFocus();
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
        txtaccLostbook.grabFocus();


    }//GEN-LAST:event_txtpatronidlostbookActionPerformed

    private void txtpatronidlostbookKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtpatronidlostbookKeyTyped
        // TODO add your handling code here:
        try {
            char ch = evt.getKeyChar();
            if (!Character.isDigit(ch)) {

                evt.consume();
                Toolkit.getDefaultToolkit().beep();

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_txtpatronidlostbookKeyTyped

    private void txtaccLostbookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtaccLostbookActionPerformed
        // TODO add your handling code here:
        try {

            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT accessionNo FROM copies WHERE accessionNo='" + txtaccLostbook.getText() + "'");

            if (!rs.first()) {

                JOptionPane.showMessageDialog(rootPane, " Invalid Accession Number...Please Chechk Again");
                txtaccLostbook.setText("");
                txtaccLostbook.grabFocus();
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }//GEN-LAST:event_txtaccLostbookActionPerformed

    private void txtaccLostbookKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtaccLostbookKeyTyped
        // TODO add your handling code here:
        try {
            char ch = evt.getKeyChar();
            if (!Character.isDigit(ch)) {

                evt.consume();
                Toolkit.getDefaultToolkit().beep();

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_txtaccLostbookKeyTyped

    private void txtborrowdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtborrowdateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtborrowdateActionPerformed

    private void txtborrowdateKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtborrowdateKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtborrowdateKeyPressed

    private void txtborrowdateKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtborrowdateKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtborrowdateKeyTyped

    private void txtaccessno2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtaccessno2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtaccessno2ActionPerformed

    private void txtaccessno2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtaccessno2KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtaccessno2KeyPressed

    private void txtaccessno2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtaccessno2KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtaccessno2KeyTyped

    private void btnlostbooksaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlostbooksaveActionPerformed
        // TODO add your handling code here:

        try {

            int x = JOptionPane.showConfirmDialog(rootPane, "Do You Want to Save !");
            if (x == 0) {

                Connection c = DBConnection.mycon();
                Statement s = c.createStatement();
                String query = "INSERT INTO lostbook_payment (`Patron_id`,`Accession_no`,`Status`,`Amount`,`Action`) VALUES('" + txtpatronidlostbook.getText() + "','" + txtaccLostbook.getText() + "','" + cmbstatuslost.getSelectedItem().toString() + "','" + txtamountlostbook.getText() + "','" + cmbactionlost.getSelectedItem().toString() + "')";

                ResultSet rs1 = null;

                s.executeUpdate(query, Statement.RETURN_GENERATED_KEYS);

                rs1 = s.getGeneratedKeys();
                rs1.next();
                int id = rs1.getInt(1);

                DefaultTableModel dt = (DefaultTableModel) tableunclaim.getModel();
                DefaultTableModel dtm = (DefaultTableModel) tablepayment.getModel();

                int id1 = Integer.parseInt(txtpatronidlostbook.getText());
                int access = Integer.parseInt(txtaccLostbook.getText());
                String state = cmbstatuslost.getSelectedItem().toString();
                double amount = Double.parseDouble(txtamountlostbook.getText());
                String action = cmbactionlost.getSelectedItem().toString();

                dt.addRow(new Object[]{id, id1, access, state, amount, action});
                dtm.addRow(new Object[]{id, id1, access, amount});

                JOptionPane.showMessageDialog(rootPane, "Details Saved");

                txtaccLostbook.setText("");
                txtpatronidlostbook.setText("");
                txtamountlostbook.setText("");

            } else if (x == 1) {

                txtaccLostbook.setText("");
                txtpatronidlostbook.setText("");
                txtamountlostbook.setText("");

            } else {

                txtaccLostbook.setText("");
                txtpatronidlostbook.setText("");
                txtamountlostbook.setText("");

            }

        } catch (Exception e) {

            e.printStackTrace();
        }

    }//GEN-LAST:event_btnlostbooksaveActionPerformed

    private void btnlostbookclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlostbookclearActionPerformed
        // TODO add your handling code here:
        txtaccLostbook.setText("");
        txtpatronidlostbook.setText("");
        txtamountlostbook.setText("");
    }//GEN-LAST:event_btnlostbookclearActionPerformed

    private void btnlostbookdeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlostbookdeleteActionPerformed
        // TODO add your handling code here:
        try {

            int x = JOptionPane.showConfirmDialog(rootPane, "Do You Want to Delete This ?");
            if (x == 0) {

                Connection c = DBConnection.mycon();
                Statement s = c.createStatement();
                String query = "DELETE  FROM lostbook_payment WHERE Id='" + txthideidlost.getText() + "'";
                s.executeUpdate(query);
                JOptionPane.showMessageDialog(rootPane, "Recode Deleted !");

                txtaccLostbook.setText("");
                txtamountlostbook.setText("");
                txtpatronidlostbook.setText("");

            } else if (x == 1) {

                txtaccLostbook.setText("");
                txtamountlostbook.setText("");
                txtpatronidlostbook.setText("");

            } else {

                txtaccLostbook.setText("");
                txtamountlostbook.setText("");
                txtpatronidlostbook.setText("");

            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }//GEN-LAST:event_btnlostbookdeleteActionPerformed

    private void tablefineMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablefineMouseClicked
        // TODO add your handling code here:
        try {
            DefaultTableModel dtm = (DefaultTableModel) tablefine.getModel();
            int i = tablefine.getSelectedRow();

            String id = dtm.getValueAt(i, 0).toString();
            txtid2.setText(id);

            String accession = dtm.getValueAt(i, 1).toString();
            txtaccessfine.setText(accession);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }//GEN-LAST:event_tablefineMouseClicked

    private void tableReturnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableReturnMouseClicked
        // TODO add your handling code here:
        try {
            DefaultTableModel dtm = (DefaultTableModel) tableReturn.getModel();
            int i = tableReturn.getSelectedRow();

            String accession = dtm.getValueAt(i, 1).toString();
            txtaccessionnoreturn.setText(accession);
            String fine = dtm.getValueAt(i, 5).toString();
            txtfinereturn.setText(fine);
            String id = dtm.getValueAt(i, 0).toString();
            txtid.setText(id);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_tableReturnMouseClicked

    private void txtfinereturnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtfinereturnActionPerformed
        // TODO add your handling code here:

        String fine = txtfinereturn.getText();
        double fine_amount = Double.valueOf(fine);

        if (fine_amount != 0) {

            //  jTabbedPane1.setSelectedIndex(3);
            btnreturn.setEnabled(false);

        } else {
            btnreturn.setEnabled(true);

        }
    }//GEN-LAST:event_txtfinereturnActionPerformed

    private void btnreturnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnreturnActionPerformed
        // TODO add your handling code here:
        try {
            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            String query = "SELECT Patron_id,Accession_no FROM cirrculation WHERE Id='" + txtid.getText() + "'";
            s.executeQuery(query);

            Statement s1 = c.createStatement();
            String query2 = "UPDATE cirrculation SET Status='Return' WHERE Id='" + txtid.getText() + "'";
            s1.executeUpdate(query2);

            JOptionPane.showMessageDialog(datepayment, "Book Returned");
           // Statement s2 = c.createStatement();

       //     String query3 = "SELECT accessionNo,isAvailable FROM copies WHERE accessionNo='" + txtaccessionnoreturn.getText() + "' ";
            //     ResultSet rs = s2.executeQuery(query3);
            Statement s3 = c.createStatement();
            String query4 = "UPDATE copies SET isAvailable='1' WHERE accessionNo='" + txtaccessionnoreturn.getText() + "'";
            s3.executeUpdate(query4);

            // Connection c = DBConnection.mycon();
            Statement s5 = c.createStatement();
            String query5 = "Select Count(*) from cirrculation where Patron_id='" + txtpatronidreturn.getText() + "'and Status='Borrow'";
            ResultSet rs5 = s5.executeQuery(query5);
            rs5.next();
            int count = rs5.getInt(1);
            String cout1 = String.valueOf(count);
            //System.out.println(count);

            Statement s6 = c.createStatement();
            String query1 = "UPDATE registration  SET Book_count ='" + cout1 + "' WHERE Patron_id='" + txtpatronidreturn.getText() + "'";
            s6.executeUpdate(query1);

            // int x = JOptionPane.showConfirmDialog(datepayment, "Any More Books To Return ? ");
            int x = JOptionPane.showConfirmDialog(datepayment, "Any More Books To Return ?");

            if (x == 1) {
                txtpatronidreturn.setText("");
                txtaccessionnoreturn.setText("");
                txtfinereturn.setText("");

                DefaultTableModel dtm = (DefaultTableModel) tableReturn.getModel();
                dtm.setRowCount(0);
            } else if (x == 0) {

                Statement st = c.createStatement();
                ResultSet result = st.executeQuery("SELECT Id,Patron_id,Accession_no,Borrow_date,To_be_return_date,Fine,Over_due_days FROM cirrculation WHERE Patron_id='" + txtpatronidreturn.getText() + "'and Status = 'Borrow'");

                DefaultTableModel dtm = (DefaultTableModel) tableReturn.getModel();
                dtm.setRowCount(0);
                while (result.next()) {

                    Vector v = new Vector();
                    v.add(result.getString("Id"));
                    v.add(result.getString("Accession_no"));
                    v.add(result.getString("Borrow_date"));
                    v.add(result.getString("To_be_return_date"));
                    //  v.add(result.getString("Return_date"));
                    v.add(result.getString("Over_due_days"));
                    v.add(result.getString("Fine"));

                    dtm.addRow(v);
                }

            } else {
                txtpatronidreturn.setText("");
                txtaccessionnoreturn.setText("");
                txtfinereturn.setText("");

                DefaultTableModel dtm = (DefaultTableModel) tableReturn.getModel();
                dtm.setRowCount(0);

            }
        } catch (Exception e) {

            e.printStackTrace();
        }
        try {

            Connection c = DBConnection.mycon();
            Statement st = c.createStatement();
            ResultSet result = st.executeQuery("SELECT Id,Patron_id,Accession_no,Borrow_date,To_be_return_date,Fine,Over_due_days FROM cirrculation WHERE Patron_id='" + txtpatronidreturn.getText() + "'and Status = 'Borrow'");

            DefaultTableModel dtm = (DefaultTableModel) tableReturn.getModel();
            dtm.setRowCount(0);
            while (result.next()) {

                Vector v = new Vector();
                v.add(result.getString("Id"));
                v.add(result.getString("Accession_no"));
                v.add(result.getString("Borrow_date"));
                v.add(result.getString("To_be_return_date"));
                //  v.add(result.getString("Return_date"));
                v.add(result.getString("Over_due_days"));
                v.add(result.getString("Fine"));

                dtm.addRow(v);
            }

        } catch (Exception e) {

            e.printStackTrace();
        }


    }//GEN-LAST:event_btnreturnActionPerformed

    private void btnbooklostActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbooklostActionPerformed
        // TODO add your handling code here
        try {
            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            String query = "SELECT Patron_id,Accession_no FROM cirrculation WHERE Id='" + txtid.getText() + "'";
            s.executeQuery(query);

            Statement s1 = c.createStatement();
            String query2 = "UPDATE cirrculation SET Status='Book Lost' WHERE Id='" + txtid.getText() + "'";
            s1.executeUpdate(query2);

            JOptionPane.showMessageDialog(datepayment, "Marked As Lost");

            txtpatronidreturn.setText("");
            txtaccessionnoreturn.setText("");
            txtfinereturn.setText("");

            DefaultTableModel dtm = (DefaultTableModel) tableReturn.getModel();
            dtm.setRowCount(0);

        } catch (Exception e) {

            e.printStackTrace();
        }


    }//GEN-LAST:event_btnbooklostActionPerformed

    private void tableReturnComponentAdded(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_tableReturnComponentAdded

    }//GEN-LAST:event_tableReturnComponentAdded

    private void txtidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtidActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
        try {

            txtpatronidfine.setText("");
            txtaccessfine.setText("");
            txtreciptfine.setText("");
            datepaidfine.setDate(null);

            DefaultTableModel dtm = (DefaultTableModel) tablefine.getModel();
            dtm.setRowCount(0);

            txtpatronidfine.grabFocus();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(2);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void txtpatronidfineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtpatronidfineActionPerformed
        // TODO add your handling code here:
        try {

            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT Patron_id FROM registration WHERE Patron_id='" + txtpatronidfine.getText() + "'");

            if (!rs.first()) {

                JOptionPane.showMessageDialog(rootPane, " Invalid Patron Id...Please Chechk Again");
                txtpatronidfine.setText("");
                txtpatronidfine.grabFocus();
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
        try {

            Connection c = DBConnection.mycon();
            Statement st = c.createStatement();
            ResultSet result = st.executeQuery("SELECT Id,Patron_id,Accession_no,Over_due_days,Fine FROM cirrculation WHERE Patron_id='" + txtpatronidfine.getText() + "'and Status='Borrow'and Over_due_days !=0 and Fine!=0");
            DefaultTableModel dtm = (DefaultTableModel) tablefine.getModel();
            while (result.next()) {

                Vector v = new Vector();

                v.add(result.getString("Id"));
                v.add(result.getString("Accession_no"));
                v.add(result.getString("Over_due_days"));
                v.add(result.getString("Fine"));

                dtm.addRow(v);

            }

        } catch (Exception e) {

            e.printStackTrace();
        }

    }//GEN-LAST:event_txtpatronidfineActionPerformed

    private void txtpatronidfineKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtpatronidfineKeyTyped
        // TODO add your handling code here:
        try {
            char ch = evt.getKeyChar();
            if (!Character.isDigit(ch)) {

                evt.consume();
                Toolkit.getDefaultToolkit().beep();

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_txtpatronidfineKeyTyped

    private void txtreciptfineKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtreciptfineKeyTyped
        // TODO add your handling code here:
        try {
            char ch = evt.getKeyChar();
            if (!Character.isDigit(ch)) {

                evt.consume();
                Toolkit.getDefaultToolkit().beep();

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }//GEN-LAST:event_txtreciptfineKeyTyped

    private void txtreciptfineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtreciptfineActionPerformed
        // TODO add your handling code here:
        String recipt = txtreciptfine.getText();
        if (!recipt.matches("\\d{7}")) {

            JOptionPane.showMessageDialog(datepayment, "Invalid Recipt Number");
            txtreciptfine.setText("");

        }
    }//GEN-LAST:event_txtreciptfineActionPerformed

    private void btnpaidreturnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnpaidreturnActionPerformed
        // TODO add your handling code here:
        try {
            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            String query = "SELECT Patron_id,Accession_no FROM cirrculation WHERE Id='" + txtid2.getText() + "'";
            s.executeQuery(query);

            Statement s1 = c.createStatement();
            Date paiddate = datepaidfine.getDate();
            Calendar cal = Calendar.getInstance();
            cal.setTime(paiddate);
            String query2 = "UPDATE cirrculation SET Status='Paid & Return',Recipt_no='" + txtreciptfine.getText() + "',paid_date='" + toddMMyy(cal.getTime()) + "' WHERE Id='" + txtid2.getText() + "'";
            s1.executeUpdate(query2);

            JOptionPane.showConfirmDialog(datepayment, " PAID ");
            Statement s2 = c.createStatement();

            String query3 = "SELECT accessionNo,isAvailable FROM copies WHERE accessionNO='" + txtaccessfine.getText() + "' ";
            ResultSet rs = s2.executeQuery(query3);

//            rs.next();
//
//            int count = rs.getInt("current_copies");
//
//            int count2 = count + 1;
//
//            String count3 = String.valueOf(count2);
            Statement s3 = c.createStatement();
            String query4 = "UPDATE copies SET isAvailable='1' WHERE accessionNo='" + txtaccessfine.getText() + "'";
            int rs1 = s3.executeUpdate(query4);

            int x = JOptionPane.showConfirmDialog(datepayment, "Any More Fine To Pay ?");

            if (x == 1) {
                txtpatronidfine.setText("");
                txtaccessfine.setText("");
                txtreciptfine.setText("");

                DefaultTableModel dtm = (DefaultTableModel) tablefine.getModel();
                dtm.setRowCount(0);

            }

            txtpatronidfine.setText("");
            txtaccessfine.setText("");
            DefaultTableModel dtm = (DefaultTableModel) tablefine.getModel();

            dtm.setRowCount(0);

        } catch (Exception e) {

            e.printStackTrace();
        }

    }//GEN-LAST:event_btnpaidreturnActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
        try {
            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            String query = "SELECT Patron_id,Accession_no FROM cirrculation WHERE Id='" + txtid2.getText() + "'";
            s.executeQuery(query);

            Statement s1 = c.createStatement();
            Date paiddate = datepaidfine.getDate();
            Calendar cal = Calendar.getInstance();
            cal.setTime(paiddate);
            String query2 = "UPDATE cirrculation SET Status='Paid & Book Lost',Recipt_no='" + txtreciptfine.getText() + "',paid_date='" + toddMMyy(cal.getTime()) + "' WHERE Id='" + txtid2.getText() + "'";
            s1.executeUpdate(query2);

            JOptionPane.showMessageDialog(datepayment, "Paid & Book Lost");
            txtpatronidfine.setText("");
            txtaccessfine.setText("");
            txtreciptfine.setText("");
            datepaidfine.setDate(null);

            DefaultTableModel dtm = (DefaultTableModel) tablefine.getModel();
            dtm.setRowCount(0);

        } catch (Exception e) {

            e.printStackTrace();
        }

    }//GEN-LAST:event_jButton9ActionPerformed

    private void combotypefineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combotypefineActionPerformed
        // TODO add your handling code here
        try {
            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            String query = ("SELECT Patron_id,Accession_no,Borrow_date,To_be_return_date,Over_due_days,Fine FROM cirrculation WHERE User_type='" + combotypefine.getSelectedItem() + "'and Status='Borrow'and Over_due_days !=0 and Fine !=0");
            ResultSet rs = s.executeQuery(query);

            DefaultTableModel dtm = (DefaultTableModel) tableveiwfine.getModel();
            dtm.setRowCount(0);
            while (rs.next()) {

                Vector v = new Vector();
                v.add(rs.getString("Patron_id"));
                v.add(rs.getString("Accession_no"));
                v.add(rs.getString("Borrow_date"));
                v.add(rs.getString("To_be_return_date"));

                v.add(rs.getString("Over_due_days"));
                v.add(rs.getString("Fine"));

                dtm.addRow(v);
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

    }//GEN-LAST:event_combotypefineActionPerformed

    private void combotypereturnviewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combotypereturnviewActionPerformed
        // TODO add your handling code here
        try {
            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            Date date1 = dateretutnview.getDate();

            Calendar cal = Calendar.getInstance();
            cal.setTime(date1);
            //  toddMMyy(cal.getTime())
            txtdatehide.setText(toddMMyy(date1));
            String query = ("SELECT Patron_id,Accession_no,Borrow_date FROM cirrculation WHERE User_type='" + combotypereturnview.getSelectedItem() + "'and Status='Borrow'and To_be_return_date='" + txtdatehide.getText() + "'");
            ResultSet rs = s.executeQuery(query);

            DefaultTableModel dtm = (DefaultTableModel) tablereturnview.getModel();
            dtm.setRowCount(0);
            while (rs.next()) {

                Vector v = new Vector();
                v.add(rs.getString("Patron_id"));
                v.add(rs.getString("Accession_no"));
                v.add(rs.getString("Borrow_date"));

                dtm.addRow(v);
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

    }//GEN-LAST:event_combotypereturnviewActionPerformed

    private void combotypeborrowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combotypeborrowActionPerformed
        // TODO add your handling code here:
        try {
            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            Date date1 = dateborrowview.getDate();

            Calendar cal = Calendar.getInstance();
            cal.setTime(date1);
            //  toddMMyy(cal.getTime())
            txtdate3.setText(toddMMyy(date1));
            //   txtdate3.setText(null);

            String query = ("SELECT Id, Patron_id,Accession_no,Borrow_date,To_be_return_date FROM cirrculation WHERE User_type='" + combotypeborrow.getSelectedItem() + "'and Status='Borrow' and Borrow_date='" + txtdate3.getText() + "'");
            ResultSet rs = s.executeQuery(query);
            //  txtdate3.setText("");

            DefaultTableModel dtm = (DefaultTableModel) tableborrowview.getModel();
            dtm.setRowCount(0);
            while (rs.next()) {

                Vector v = new Vector();
                v.add(rs.getString("Id"));
                v.add(rs.getString("Patron_id"));
                v.add(rs.getString("Accession_no"));
                v.add(rs.getString("Borrow_date"));
                v.add(rs.getString("To_be_return_date"));

                dtm.addRow(v);
                //txtdate3.setText("");
            }

        } catch (Exception e) {

            e.printStackTrace();
        }


    }//GEN-LAST:event_combotypeborrowActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        try {
            dateborrowview.setDate(null);
            DefaultTableModel dtm = (DefaultTableModel) tableborrowview.getModel();
            dtm.setRowCount(0);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void tableborrowviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableborrowviewMouseClicked
        // TODO add your handling code here:
        try {
            DefaultTableModel dtm = (DefaultTableModel) tableborrowview.getModel();
            int i = tableborrowview.getSelectedRow();

            String id = dtm.getValueAt(i, 0).toString();
            txtid3.setText(id);
            
            String pt=dtm.getValueAt(i, 1).toString();
            txtpatronidedit.setText(pt);
            
            String acc=dtm.getValueAt(i,2 ).toString();
            txtaccesseditcircular.setText(acc);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }//GEN-LAST:event_tableborrowviewMouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        try {

            int x = JOptionPane.showConfirmDialog(rootPane, "Do You Want to Delete This ?");
            if (x == 0) {

                Connection c = DBConnection.mycon();
                Statement s = c.createStatement();
                String query = "DELETE  FROM cirrculation WHERE Id='" + txtid3.getText() + "'";
                s.executeUpdate(query);
                JOptionPane.showMessageDialog(rootPane, "Recode Deleted !");

            }

        } catch (Exception e) {

            e.printStackTrace();
        }
        try {
            Connection c = DBConnection.mycon();
            Statement s2 = c.createStatement();
            String query3 = "SELECT accessionNo,isAvailable FROM copies WHERE accessionNo='" + txtaccesseditcircular.getText() + "' ";
            s2.executeQuery(query3);

            Statement s3 = c.createStatement();
            String query4 = "UPDATE copies SET isAvailable='1' WHERE accessionNo='" + txtaccesseditcircular.getText() + "'";
            s3.executeUpdate(query4);

            Statement s5 = c.createStatement();
            String query5 = "Select Count(*) from cirrculation where Patron_id='" + txtpatronidedit.getText() + "'and Status='Borrow'";
            ResultSet rs5 = s5.executeQuery(query5);
            rs5.next();
            int count = rs5.getInt(1);
            String cout1 = String.valueOf(count);
            System.out.println(count);

            Statement s6 = c.createStatement();
            String query1 = "UPDATE registration  SET Book_count ='" + cout1 + "' WHERE Patron_id='" + txtpatronidedit.getText() + "'";
            s6.executeUpdate(query1);

        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            String query = ("SELECT Id, Patron_id,Accession_no,Borrow_date,To_be_return_date FROM cirrculation WHERE User_type='" + combotypeborrow.getSelectedItem() + "'and Status='Borrow'");
            ResultSet rs = s.executeQuery(query);

            DefaultTableModel dtm = (DefaultTableModel) tableborrowview.getModel();
            dtm.setRowCount(0);
            while (rs.next()) {

                Vector v = new Vector();
                v.add(rs.getString("Id"));
                v.add(rs.getString("Patron_id"));
                v.add(rs.getString("Accession_no"));
                v.add(rs.getString("Borrow_date"));
                v.add(rs.getString("To_be_return_date"));

                dtm.addRow(v);
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
            try {
                
                     Date date1 = datereport.getDate();

            Calendar cal = Calendar.getInstance();
            cal.setTime(date1);
            //  toddMMyy(cal.getTime())
            txthidedate2.setText(toddMMyy(date1));
            
   HashMap param=new HashMap();
    param.put("Borrow_date",txthidedate2.getText());
    MyiReportViewer view=new MyiReportViewer("C:\\Users\\HP Laptop\\Desktop\\Aliya Aliya\\Aliya\\Removable Disk\\2020\\Launcher\\src\\Circulations\\Borrowing.jasper",param);
    view.setVisible(true);
    txthidedate2.setText("");
  //  datereport.set
            
        } catch (Exception e) {
            
            e.printStackTrace();
        }
        
    }//GEN-LAST:event_jButton6ActionPerformed

    private void dateborrowviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dateborrowviewMouseClicked
//         TODO add your handling code here:
//             Date date1=dateborrowview.getDate();
//            Calendar cal=Calendar.getInstance();
//            cal.setTime(date1);
//            toddMMyy(cal.getTime())
//             txtdate3.setText(toddMMyy(date1));
    }//GEN-LAST:event_dateborrowviewMouseClicked

    private void txtpatronidpaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtpatronidpaymentActionPerformed
        // TODO add your handling code here:
        try {

            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery("SELECT Patron_id FROM registration WHERE Patron_id='" + txtpatronidpayment.getText() + "'");

            if (!rs.first()) {

                JOptionPane.showMessageDialog(rootPane, " Invalid Patron Id...Please Chechk Again");
                txtpatronidpayment.setText("");
                txtpatronidpayment.grabFocus();
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

    }//GEN-LAST:event_txtpatronidpaymentActionPerformed

    private void txtpatronidpaymentKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtpatronidpaymentKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtpatronidpaymentKeyTyped

    private void txtrciptpaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtrciptpaymentActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtrciptpaymentActionPerformed

    private void txtrciptpaymentKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtrciptpaymentKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtrciptpaymentKeyTyped

    private void btnsavepaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsavepaymentActionPerformed
        // TODO add your handling code here:
        try {
            Connection c = DBConnection.mycon();
            Statement s1 = c.createStatement();
            Date paiddate = datepayment.getDate();
            Calendar cal = Calendar.getInstance();
            cal.setTime(paiddate);
            String query2 = "UPDATE lostbook_payment SET Recipt_no='" + txtrciptpayment.getText() + "',Date_paid='" + toddMMyy(cal.getTime()) + "' WHERE Id='" + txtid4payment.getText() + "'";
            s1.executeUpdate(query2);
//             ResultSet rs1 = null;
//                
//             s1.executeUpdate(query2,Statement.RETURN_GENERATED_KEYS);
//                
//                rs1 =s1.getGeneratedKeys();
//                rs1.next();
//                int id1 = rs1.getInt(1);

            JOptionPane.showMessageDialog(datepayment, "Details Saved !");

            txtrciptpayment.setText("");
            txtpatronidpayment.setText("");
            txtamountpayment.setText("");
            datepayment.setDate(null);
            txtid4payment.setText("");
            txtacchidepayment.setText("");

//            DefaultTableModel dtm = (DefaultTableModel) tablepayment.getModel();
//          
//           int id1 = Integer.parseInt(txtid4payment.getText());
//            int id = Integer.parseInt(txtpatronidpayment.getText());
//            int acc = Integer.parseInt(txtacchidepayment.getText());
//            int recipt = Integer.parseInt(txtrciptpayment.getText());
//            String datepaid = toddMMyy(cal.getTime());
//           
//
//            dtm.addRow(new Object[]{id1,id, acc, recipt, datepaid});
        } catch (Exception e) {
            e.printStackTrace();
        }


    }//GEN-LAST:event_btnsavepaymentActionPerformed

    private void btnclearpayment1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnclearpayment1ActionPerformed
        // TODO add your handling code here
        txtreciptfine.setText("");
        txtpatronidpayment.setText("");
        txtamountpayment.setText("");
        datepayment.setDate(null);
    }//GEN-LAST:event_btnclearpayment1ActionPerformed

    private void btndeletepayment1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndeletepayment1ActionPerformed
        // TODO add your handling code here:
        try {

            int x = JOptionPane.showConfirmDialog(rootPane, "Do You Want to Delete This ?");
            if (x == 0) {

                Connection c = DBConnection.mycon();
                Statement s = c.createStatement();
                String query = "DELETE  FROM lostbook_payment WHERE Id='" + txtid4payment.getText() + "'";
                s.executeUpdate(query);
                JOptionPane.showMessageDialog(rootPane, "Recode Deleted !");

                txtpatronidpayment.setText("");
                txtamountpayment.setText("");
                txtrciptpayment.setText("");
                datepayment.setDate(null);

            } else if (x == 1) {

                txtpatronidpayment.setText("");
                txtamountpayment.setText("");
                txtrciptpayment.setText("");
                datepayment.setDate(null);

            } else {

                txtpatronidpayment.setText("");
                txtamountpayment.setText("");
                txtrciptpayment.setText("");
                datepayment.setDate(null);

            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }//GEN-LAST:event_btndeletepayment1ActionPerformed

    private void tablepaymentMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablepaymentMouseClicked
        // TODO add your handling code here:
        try {
            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            String query = "SELECT Recipt_no FROM lostbook_payment";

            ResultSet rs = s.executeQuery(query);
            rs.next();
            int recipt = rs.getInt(1);

//            if (recipt == 0) {
            DefaultTableModel dtm = (DefaultTableModel) tablepayment.getModel();
            int i = tablepayment.getSelectedRow();

            String p_id = dtm.getValueAt(i, 1).toString();
            txtpatronidpayment.setText(p_id);

            String amount = dtm.getValueAt(i, 3).toString();
            txtamountpayment.setText(amount);
            String acc = dtm.getValueAt(i, 2).toString();
            txtacchidepayment.setText(acc);

            String id = dtm.getValueAt(i, 0).toString();
            txtid4payment.setText(id);
//            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }//GEN-LAST:event_tablepaymentMouseClicked

    private void tableunclaimMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableunclaimMouseClicked
        // TODO add your handling code here:
        try {
            DefaultTableModel dtm = (DefaultTableModel) tableunclaim.getModel();
            int i = tableunclaim.getSelectedRow();

            String p_id = dtm.getValueAt(i, 1).toString();
            txtpatronidlostbook.setText(p_id);

            String amount = dtm.getValueAt(i, 4).toString();
            txtamountlostbook.setText(amount);
            String acc = dtm.getValueAt(i, 2).toString();
            txtaccLostbook.setText(acc);
//            String  = dtm.getValueAt(i, 5).toString();
//            txtfinereturn.setText(fine);
            String id = dtm.getValueAt(i, 0).toString();
            txthideidlost.setText(id);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_tableunclaimMouseClicked

    private void btnreserveBorrowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnreserveBorrowActionPerformed

           
        try {

            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            String query = "SELECT accessionNo,isAvailable FROM copies";
            s.executeQuery(query);

            Statement s1 = c.createStatement();
            String query1 = "UPDATE copies SET isAvailable='1' WHERE accessionNo='" + txtaccessionresevation.getText() + "'";
            s1.executeUpdate(query1);

            jTabbedPane1.setSelectedIndex(0);

            txtpatronid.setText(txtpatronidreseve.getText());
            txtaccessno.setText(txtaccessionresevation.getText());

        } catch (Exception e) {

            e.printStackTrace();

        }

        try {
            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            String query = "DELETE FROM reservations WHERE reserveID='" + txtreserveid.getText() + "'";
            s.executeUpdate(query);
            txtreserveid.setText("");
            txtaccessionresevation.setText("");
            txtpatronidreseve.setText("");
              DefaultTableModel dtm = (DefaultTableModel) tablereserve.getModel();
              dtm.setRowCount(0);

        } catch (Exception e) {

            e.printStackTrace();
        }
        try {

            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            String query = "SELECT * FROM reservations";
            ResultSet rs = s.executeQuery(query);

            DefaultTableModel dtm = (DefaultTableModel) tablereserve.getModel();
            while (rs.next()) {

                Vector v = new Vector();

                v.add(rs.getString("reserveID"));
                v.add(rs.getString("accessionNO"));
                v.add(rs.getString("userID"));
                v.add(rs.getString("reservedDate"));

                dtm.addRow(v);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }


    }//GEN-LAST:event_btnreserveBorrowActionPerformed

    private void tablereserveMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablereserveMouseClicked
        // TODO add your handling code here:
        try {
            DefaultTableModel dtm = (DefaultTableModel) tablereserve.getModel();
            int i = tablereserve.getSelectedRow();

            String id = dtm.getValueAt(i, 0).toString();
            txtreserveid.setText(id);

            String acc = dtm.getValueAt(i, 2).toString();
            txtaccessionresevation.setText(acc);

            String pid = dtm.getValueAt(i, 1).toString();
            txtpatronidreseve.setText(pid);

        } catch (Exception e) {
            e.printStackTrace();
        }


    }//GEN-LAST:event_tablereserveMouseClicked

    private void txtamountpaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtamountpaymentActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtamountpaymentActionPerformed

    private void btnreffreshpaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnreffreshpaymentActionPerformed
        // TODO add your handling code here:
        try {

            Connection c = DBConnection.mycon();
            Statement s = c.createStatement();
            String query = "SELECT Id,Patron_id,Accession_no,Amount,Recipt_no,Date_paid FROM lostbook_payment";
            ResultSet rs = s.executeQuery(query);

            DefaultTableModel dtm = (DefaultTableModel) tablepayment.getModel();
            dtm.setRowCount(0);
            while (rs.next()) {

                Vector v = new Vector();

                v.add(rs.getString("Id"));
                v.add(rs.getString("Patron_id"));
                v.add(rs.getString("Accession_no"));
                v.add(rs.getString("Amount"));
                v.add(rs.getString("Recipt_no"));
                v.add(rs.getString("Date_paid"));

                dtm.addRow(v);

            }

        } catch (Exception e) {

            e.printStackTrace();
        }

    }//GEN-LAST:event_btnreffreshpaymentActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        try {
            
   HashMap param=new HashMap();
    param.put("Fine",txtamountreport.getText());
    MyiReportViewer viewer=new MyiReportViewer("C:\\Users\\HP Laptop\\Desktop\\Aliya Aliya\\Aliya\\Removable Disk\\2020\\Launcher\\src\\Circulations\\fineDetails.jasper",param);
    viewer.setVisible(true);
    txtamountreport.setText("");
            
        } catch (Exception e) {
            
            e.printStackTrace();
        }
        

    }//GEN-LAST:event_jButton4ActionPerformed

    private void cmbstatuslostActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbstatuslostActionPerformed
        // TODO add your handling code here:
        txtamountlostbook.grabFocus();
    }//GEN-LAST:event_cmbstatuslostActionPerformed

    private void cmbactionlostActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbactionlostActionPerformed
        // TODO add your handling code here:
        btnlostbooksave.grabFocus();
    }//GEN-LAST:event_cmbactionlostActionPerformed

    private void btnchkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnchkActionPerformed
        // TODO add your handling code here:
        try {
            Connection c= DBConnection.mycon();
            Statement s=c.createStatement();
            String query="SELECT COUNT(accessionNo)FROM copies WHERE isAvailable='1'and bookId='"+txteditavailabelbooks.getText()+"'";
            ResultSet rs = s.executeQuery(query);
            rs.next();
            int count = rs.getInt(1);
            String cout1 = String.valueOf(count);
          //
            txteditavailabelbooks.setText("");
            lblcount.setText(cout1+" More Available Copies  ");
            
          
        } catch (Exception e) {
            
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnchkActionPerformed

    private void lblcountMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblcountMouseClicked
        // TODO add your handling code here:
        lblcount.setText("");
    }//GEN-LAST:event_lblcountMouseClicked

    private void txteditavailabelbooksActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txteditavailabelbooksActionPerformed
        // TODO add your handling code here:
        btnchk.grabFocus();
    }//GEN-LAST:event_txteditavailabelbooksActionPerformed

    private void txtaccessionresevationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtaccessionresevationActionPerformed
        // TODO add your handling code here:
        btnreserveBorrow.grabFocus();
    }//GEN-LAST:event_txtaccessionresevationActionPerformed

    private void comboreportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboreportActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboreportActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
              try {
            
   HashMap param=new HashMap();
    param.put("Status",comboreport.getSelectedItem().toString());
    MyiReportViewer  veiw1=new MyiReportViewer("C:\\Users\\HP Laptop\\Desktop\\Aliya Aliya\\Aliya\\Removable Disk\\2020\\Launcher\\src\\Circulations\\Lostbook.jasper",param);
     veiw1.setVisible(true);
    //txtamountreport.setText("");
            
        } catch (Exception e) {
            
            e.printStackTrace();
        }
        
    }//GEN-LAST:event_jButton7ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BookLend.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BookLend.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BookLend.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BookLend.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BookLend().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnbooklost;
    private javax.swing.JButton btnborrow;
    private javax.swing.JButton btnchk;
    private javax.swing.JButton btnclear;
    private javax.swing.JButton btnclearpayment1;
    private javax.swing.JButton btndeletepayment1;
    private javax.swing.JButton btnlostbookclear;
    private javax.swing.JButton btnlostbookdelete;
    private javax.swing.JButton btnlostbooksave;
    private javax.swing.JButton btnpaidreturn;
    private javax.swing.JButton btnreffreshpayment;
    private javax.swing.JButton btnreserveBorrow;
    private javax.swing.JButton btnreturn;
    private javax.swing.JButton btnsavepayment;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JComboBox cmbactionlost;
    private javax.swing.JComboBox cmbstatuslost;
    private javax.swing.JComboBox comboreport;
    private javax.swing.JComboBox combotype;
    private javax.swing.JComboBox combotypeborrow;
    private javax.swing.JComboBox combotypefine;
    private javax.swing.JComboBox combotypereturnview;
    private com.toedter.calendar.JDateChooser dateborrowview;
    private com.toedter.calendar.JDateChooser datepaidfine;
    private com.toedter.calendar.JDateChooser datepayment;
    private com.toedter.calendar.JDateChooser datereport;
    private com.toedter.calendar.JDateChooser dateretutnview;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTableBorrow;
    private javax.swing.JLabel lblcount;
    private javax.swing.JPanel panelBorrow;
    private javax.swing.JPanel panelreserve;
    private javax.swing.JTable tableReturn;
    private javax.swing.JTable tableborrowview;
    private javax.swing.JTable tablefine;
    private javax.swing.JTable tablepayment;
    private javax.swing.JTable tablereserve;
    private javax.swing.JTable tablereturnview;
    private javax.swing.JTable tableunclaim;
    private javax.swing.JTable tableveiwfine;
    private javax.swing.JTextField txtaccLostbook;
    private javax.swing.JTextField txtaccesseditcircular;
    private javax.swing.JTextField txtaccessfine;
    private javax.swing.JTextField txtaccessionnoreturn;
    private javax.swing.JTextField txtaccessionresevation;
    private javax.swing.JTextField txtaccessno;
    private javax.swing.JTextField txtaccessno2;
    private javax.swing.JTextField txtacchidepayment;
    private javax.swing.JTextField txtamountlostbook;
    private javax.swing.JTextField txtamountpayment;
    public static javax.swing.JTextField txtamountreport;
    private javax.swing.JTextField txtborrowdate;
    private javax.swing.JTextField txtdate3;
    private javax.swing.JTextField txtdatehide;
    private javax.swing.JTextField txteditavailabelbooks;
    private javax.swing.JTextField txtfinereturn;
    private javax.swing.JTextField txthidedate2;
    private javax.swing.JTextField txthideidlost;
    private javax.swing.JTextField txtid;
    private javax.swing.JTextField txtid2;
    private javax.swing.JTextField txtid3;
    private javax.swing.JTextField txtid4payment;
    private javax.swing.JTextField txtpatronid;
    private javax.swing.JTextField txtpatronidedit;
    private javax.swing.JLabel txtpatronideditcirrcular;
    private javax.swing.JTextField txtpatronidfine;
    private javax.swing.JTextField txtpatronidlostbook;
    private javax.swing.JTextField txtpatronidpayment;
    private javax.swing.JTextField txtpatronidreseve;
    private javax.swing.JTextField txtpatronidreturn;
    private javax.swing.JTextField txtrciptpayment;
    private javax.swing.JTextField txtreciptfine;
    private javax.swing.JTextField txtreserveid;
    // End of variables declaration//GEN-END:variables
}
