import Thushan.Front;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.LineBorder;

public class PopupSample15 {

  public static void main(String args[]) {



        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PopupSample15.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PopupSample15.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PopupSample15.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PopupSample15.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }


 //UIManager.getLookAndFeelDefaults().put("PopupMenu[Enabled].backgroundPainter", new PopupPainter(/*new Color(127, 255, 191)*/Color.RED));
 
 
 
 
 
 
UIDefaults ui = UIManager.getLookAndFeelDefaults();
ui.put("PopupMenu.background",new Color(236,240,241));
ui.put("Menu.background", new Color(236,240,241));
ui.put("Menu.opaque", true);
ui.put("MenuItem.background",new Color(236,240,241));
ui.put("MenuItem.opaque", true);
ui.put("PopupMenu.contentMargins", null);

                           
    ActionListener actionListener = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            System.out.println("Selected: " + actionEvent.getActionCommand());
        }
    };

    JFrame frame = new JFrame("Tiger Popup Example");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    final JPopupMenu popupMenu = new JPopupMenu();
    popupMenu.setLightWeightPopupEnabled(false);
    popupMenu.setBorder(new LineBorder(new Color(52,73,94), 5));
    //popupMenu.setBackground(Color.red);
   // popupMenu.setBackground(Color.white);
   // popupMenu.setBorderPainted(true);
   // popupMenu.setOpaque(true);
    //popupMenu.setBorder(new LineBorder(Color.BLUE, 2));
   // popupMenu.setLabel("");
  //  popupMenu.setForeground(Color.red);
     // Cut
    JMenuItem cutMenuItem = new JMenuItem("Cut");
    cutMenuItem.setSize(100,50);
    cutMenuItem.setPreferredSize(new Dimension(150, 50));
    cutMenuItem.setMinimumSize(new Dimension(150, 50));
    cutMenuItem.setMaximumSize(new Dimension(150, 50));
    cutMenuItem.addActionListener(actionListener);
    popupMenu.add(cutMenuItem);

    // Copy
    JMenuItem copyMenuItem = new JMenuItem("Copy");
    copyMenuItem.addActionListener(actionListener);
    popupMenu.add(copyMenuItem);

    // Paste
    JMenuItem pasteMenuItem = new JMenuItem("Paste");
    pasteMenuItem.addActionListener(actionListener);
    pasteMenuItem.setEnabled(false);
    popupMenu.add(pasteMenuItem);

    // Separator
   // popupMenu.addSeparator();

    // Find
    JMenuItem findMenuItem = new JMenuItem("Find");
    findMenuItem.addActionListener(actionListener);
    popupMenu.add(findMenuItem);

    JButton button = new JButton("Hi");
    button.setComponentPopupMenu(popupMenu);
    frame.getContentPane().add(button, BorderLayout.CENTER);

    frame.setSize(350, 250);
    frame.setVisible(true);
  }
}