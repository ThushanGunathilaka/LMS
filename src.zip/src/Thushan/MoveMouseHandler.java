package Thushan;

import Book.BookSubMain;
import gpl_library.Members;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;
import library.Catalogue;
import library.Email;
import library.Main;
import library.Queue;
import library.Statistics;
import purchase.purchasedetails;

public class MoveMouseHandler extends MouseAdapter {

    private int xOffset;
    private int yOffset;
    private JComponent dragItem;
    private String oldText;

    @Override
    public void mouseReleased(MouseEvent e) {
        if (dragItem != null) {
            dragItem = null;
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
        JComponent child = (JComponent) e.getComponent();
        if (child instanceof JComponent && e.getButton()==3) {
            xOffset = e.getX() - child.getX();
            yOffset = e.getY() - child.getY();
            dragItem = (JComponent) child;
        }
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        if (dragItem != null) {
            int x1=e.getX() - xOffset;
            int y1=e.getY() - yOffset;
            int w = dragItem.getWidth();
            int h = dragItem.getHeight();
            int x2=e.getX() - xOffset + w;
            int y2=e.getY() - yOffset + h;
            
            if(x1>=0 && x1<1000 && y1>=115 && y1<=700 && x2>=0 && x2<1000 && y2>=0 && y2<=645){
                dragItem.setLocation(e.getX() - xOffset, e.getY() - yOffset);
            } else if((w > 350 && h > 350) || (w <= 110 && h <= 110)){
                dragItem.setLocation(e.getX() - xOffset, e.getY() - yOffset);
            }
        }
    }
        
    @Override
    public void mouseClicked(MouseEvent e) {
        JComponent comp = (JComponent) e.getComponent();
        int count = e.getClickCount();
        String link ="";
        for(Component c : comp.getComponents()){
            if(c instanceof JLabel && count == 1 && e.getButton()==1 && c.getHeight()==40 || c.getHeight()==30 || c.getHeight()==60){
                JLabel text = (JLabel) c;
                link = text.getText();
            }
        }
        select(link);
    }
        
    private void select(String link){
        if(link.contains("Books")) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                     new BookSubMain().setVisible(true);
                }
            }); 
        } else if(link.contains("Statistics")) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new library.Statistics().setVisible(true);
                    //new Thushan.Splash().setVisible(true);
                }
            });
        } else if(link.contains("DVDs")) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new DVDManagement.DVDMain().setVisible(true);
                }
            });
        } else if(link.contains("Archives")) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new Thushan.Splash().setVisible(true);
                }
            });
        } else if(link.contains("References")) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new Thushan.Splash().setVisible(true);
                }
            }); 
        } else if(link.contains("Messages")) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new Email().setVisible(true);
                }
            });  
        } else if(link.contains("Employees")) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new AddEmployee().setVisible(true);
                }
            });
        } else if(link.contains("Patrons")) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new Members().setVisible(true);
                }
            });
        } else if(link.contains("Webs")) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new Thushan.Splash().setVisible(true);
                }
            });
        } else if(link.contains("Queues")) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new Queue().setVisible(true);
                }
            });
        } else if(link.contains("Catalogues")) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new Catalogue().setVisible(true);
                }
            }); 
        } else if(link.contains("Circulations")) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new Circulations.BookLend().setVisible(true);
                }
            });
        } else if(link.contains("Acquisitions")) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new purchasedetails().setVisible(true);
                }
            });
        } else if(link.contains("Reports")) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new Thushan.Splash().setVisible(true);
                }
            });
        } else if(link.contains("Settings")) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new BackupAndRestore.BackupAndRestore().setVisible(true);
                }
            });
        }

    }
        /*
        private class MouseAdapterCustom extends MouseAdapter {
            @Override
            public void mousePressed(MouseEvent e) {
                JComponent comp = (JComponent) e.getComponent();
                for(Component c : comp.getComponents()){
                    if(c instanceof JLabel && c.getHeight()==40 || c.getHeight()==30 || c.getHeight()==60){
                        JLabel text = (JLabel) c;
                    }
                }
            }
        } */
    }


