/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Thushan;
import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.*;
import java.io.*;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;

import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.design.*;
import net.sf.jasperreports.view.*;

public class ReportCode extends JFrame {
    
    

public ReportCode(String fileName)
{
this(fileName,null);
}

public ReportCode(String fileName,HashMap parameter)
{
super(" Report");

try
{

Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "root", "root");

JasperPrint print = JasperFillManager.fillReport(fileName, parameter, con);

JRViewer viewer=new JRViewer(print);

Container c=getContentPane();
c.add(viewer);
}
catch(ClassNotFoundException cnfe)
{
cnfe.printStackTrace();
}
catch(SQLException sqle)
{
sqle.printStackTrace();
}
catch(JRException jre)
{
jre.printStackTrace();
}

setBounds(10,10,1300,500);
setDefaultCloseOperation(DISPOSE_ON_CLOSE);


}

public static void main(String args[])
{
/* A sample calling */
HashMap param=new HashMap();
//param.put("Fine",txtamountreport.getText());
ReportCode viewer=new ReportCode("C:\\Users\\HP Laptop\\Desktop\\Aliya Aliya\\Aliya\\Removable Disk\\2020\\Launcher\\src\\Thushan\\parameterRight.jasper",param);
viewer.setVisible(true);


}

//HashMap param1=new HashMap();
/*MyiReportViewer view=new MyiReportViewer("C:\\Users\\Theja\\Desktop\\report1\\Borrowing.jasper", param);
view.setVisible(true);

    MyiReportViewer veiw1=new MyiReportViewer("C:\\Users\\Theja\\Desktop\\report1\\Lostbook.jasper", param);
    veiw1.setVisible(true);*/
}
    

