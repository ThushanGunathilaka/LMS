/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Thushan;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.ToolTipManager;
import javax.swing.UIDefaults;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.plaf.ColorUIResource;

/**
 *
 * @author Design
 */
public class Front extends javax.swing.JFrame implements Translate.MultiLanguage {

    /**
     * Creates new form Front
     */
    private final Translate.LanguageTranslator translator;
    private String tip;
    public static String quoteInEnglish = "\"If information is the currency of democracy, then libraries are its banks.\"";
    public static String quoteInSinhala = "\"ප්‍රජාතන්ත්‍රවාදයේ මුදල තොරතුරු උවහොත් පුස්තකාලය එහි බැංකුව ය..\"";

    
    
    public static Color backgroundColor = /*new Color(0,231,166);/*/UserHandler.turquoise;
    public static Color formBackgroundColor =/* new Color(0,231,166);/*/UserHandler.turquoise;
    
    public static final String EnglishStart = "<html><font face=\"Segoe UI\">";
    public static final String SinhalaStart = "<html><font face=\"Iskoola pota\">";
    public static final String LineEnd = "</font></html>";
    
    public static String EnglishUsername = "Guest";
    public static String SinhalaUsername = "ආගන්තුකයා";
    
    private static boolean userIsAGuest = true;

    @Override
    public void changeUI() {
        formBackgroundColor = UserHandler.turquoise;
        backgroundColor = UserHandler.turquoise;
        formSwiral.setIcon(new StretchImage("Swiral.png",false,5000, 5000).getImageIcon());
        swiral.setIcon(new StretchImage("Swiral.png",false,5000, 5000).getImageIcon());
        wallpaper.setBackground(backgroundColor);
        formWallpaper.setBackground(formBackgroundColor);
        Backup.setBackground(formBackgroundColor);


        

        

        
        //{Employee,Book,EBook,DVD,Message,Reference,Archive,Patron,Setting,Web,Report,Circulation,Catalogue,Queue,Acqusition};
        //boolean [] IconVisibleArray ={false,true,true,true,false,/**/false,/**/false,false,false,false,/**/false,false,false,false,false,};
        boolean [] IconVisibleArray ={true,true,true,true,true,false,false,true,true,true,false,true,true,true,true,};
        Color [] IconBackgroundColorArray = {UserHandler.midNightBlue,UserHandler.midNightBlue,UserHandler.midNightBlue,UserHandler.midNightBlue,UserHandler.midNightBlue,/**/UserHandler.midNightBlue,
            /**/UserHandler.midNightBlue,UserHandler.midNightBlue,UserHandler.midNightBlue,UserHandler.midNightBlue,
            /**/UserHandler.midNightBlue,UserHandler.midNightBlue,UserHandler.midNightBlue,UserHandler.midNightBlue,UserHandler.midNightBlue};

        Color [] IconColorArray = {UserHandler.belizeHole,UserHandler.belizeHole,UserHandler.belizeHole,UserHandler.belizeHole,UserHandler.belizeHole,/**/UserHandler.belizeHole,
            /**/UserHandler.belizeHole,UserHandler.belizeHole,UserHandler.belizeHole,UserHandler.belizeHole,
            /**/UserHandler.belizeHole,UserHandler.belizeHole,UserHandler.belizeHole,UserHandler.belizeHole,UserHandler.belizeHole};
        
        ArrayList<int[]> IconBoundArray = new ArrayList<int []>();
        
        IconBoundArray.add(0,new int[]{420,120,160,160});
        IconBoundArray.add(1,new int[]{60,120,160,160});
        IconBoundArray.add(2,new int[]{60,300,160,160});
        IconBoundArray.add(3,new int[]{60,480,160,160});
        IconBoundArray.add(4,new int[]{240, 480,160,160});
        IconBoundArray.add(5,new int[]{240, 300,160,160});
        IconBoundArray.add(6,new int[]{240, 120,160,160}); 
        IconBoundArray.add(7,new int[]{420, 300,160,160});
        IconBoundArray.add(8,new int[]{420, 480,160,160}); 
        IconBoundArray.add(9,new int[]{780,300,160,160});
        IconBoundArray.add(10,new int[]{600,120,160,160});
        IconBoundArray.add(11,new int[]{600,300,160,160});
        IconBoundArray.add(12,new int[]{600, 480,160,160});
        IconBoundArray.add(13,new int[]{270, 120,160,160});
        IconBoundArray.add(14,new int[]{270, 290,160,160});
        
        setIconBackgroundColors(IconBackgroundColorArray);
        setIconBounds(IconBoundArray);
        showIconSet(IconVisibleArray);
        setIconForegroundColors(true,IconColorArray);//large icon
        

        
        this.pack();
        this.revalidate();
        this.repaint();
    }

    public void showIconSet(boolean [] IconVisibleArray) {
        Employee.setVisible(IconVisibleArray[0]);
        Book.setVisible(IconVisibleArray[1]);
        EBook.setVisible(IconVisibleArray[2]);
        DVD.setVisible(IconVisibleArray[3]);
        Message.setVisible(IconVisibleArray[4]);
        /**/Reference.setVisible(false);
        /**/Archive.setVisible(false);
        Patron.setVisible(IconVisibleArray[7]);
        Setting.setVisible(IconVisibleArray[8]);
        Web.setVisible(IconVisibleArray[9]);
        /**/Report.setVisible(false);
        Circulation.setVisible(IconVisibleArray[11]);
        Catalogue.setVisible(IconVisibleArray[12]);
        Queue.setVisible(IconVisibleArray[13]);
        Acqusition.setVisible(IconVisibleArray[14]);
    }
    
    public void showFormIcons(boolean check) {
        if(check) {
                            notificationsButton.setEnabled(true);
                            messagesButton.setEnabled(true);
                            profileButton.setEnabled(true);
                            helpButton.setEnabled(true);
                            settingsButton.setEnabled(true);
                            settings.setEnabled(true);
                            notificationsButton.setBackground(UserHandler.wetAsphalt);
                            messagesButton.setBackground(UserHandler.wetAsphalt);
                            profileButton.setBackground(UserHandler.wetAsphalt);
                            helpButton.setBackground(UserHandler.wetAsphalt);
                            settingsButton.setBackground(UserHandler.wetAsphalt);
        } else {          
                notificationsButton.setEnabled(false);
                messagesButton.setEnabled(false);
                profileButton.setEnabled(false);
                helpButton.setEnabled(false);
                settingsButton.setEnabled(false);
                notificationsButton.setBackground(UserHandler.concrete);
                messagesButton.setBackground(UserHandler.concrete);
                profileButton.setBackground(UserHandler.concrete);
                helpButton.setBackground(UserHandler.concrete);
                settingsButton.setBackground(UserHandler.concrete);
        }
    }

    public void Guest(boolean isGuest) {
        QuoteOfTheDay.setIcon(new StretchImage("Quote.png", true, 675,540).getImageIcon());
        showQuote.setVisible(isGuest);
        QuoteOfTheDay.setVisible(isGuest);
        showQuote.setOpaque(false);
        QuoteOfTheDay.setOpaque(false);
        popupEnableCell(!isGuest);
        
        if(!changeLanguage.isSelected()) {
            showQuote.setText("<html><font face=\"Segoe UI\">"+quoteInEnglish+"</font></html>");
            username.setText(EnglishStart + EnglishUsername + LineEnd);
            
        } else {
            
            if(quoteInSinhala != null && !quoteInSinhala.trim().isEmpty()) {
              showQuote.setText("<html><font face=\"Iskoola pota\">"+quoteInSinhala+"</font></html>");
            } else {
               showQuote.setText("<html><font face=\"Segoe UI\">"+quoteInEnglish+"</font></html>");
            }
            
            if(SinhalaUsername != null && !SinhalaUsername.trim().isEmpty()) {
               username.setText(SinhalaStart + SinhalaUsername + LineEnd);
            } else {
                username.setText(EnglishStart + EnglishUsername + LineEnd);
            }
        }
        
        if(isGuest){
            EnglishUsername = "Guest";
    SinhalaUsername = "ආගන්තුකයා";
            userIsAGuest = true;
            
                 if(!changeLanguage.isSelected()) {
            showQuote.setText("<html><font face=\"Segoe UI\">"+quoteInEnglish+"</font></html>");
            username.setText(EnglishStart + EnglishUsername + LineEnd);
            
        } else {
            
            if(quoteInSinhala != null && !quoteInSinhala.trim().isEmpty()) {
              showQuote.setText("<html><font face=\"Iskoola pota\">"+quoteInSinhala+"</font></html>");
            } else {
               showQuote.setText("<html><font face=\"Segoe UI\">"+quoteInEnglish+"</font></html>");
            }
            
            if(SinhalaUsername != null && !SinhalaUsername.trim().isEmpty()) {
               username.setText(SinhalaStart + SinhalaUsername + LineEnd);
            } else {
                username.setText(EnglishStart + EnglishUsername + LineEnd);
            }
        }
            
            boolean [] IconVisibleArray ={false,false,false,false,false,/**/false,/**/false,false,false,false,/**/false,false,false,false,false,};
            Color [] IconBackgroundColorArray = {UserHandler.midNightBlue,UserHandler.midNightBlue,UserHandler.midNightBlue,UserHandler.midNightBlue,UserHandler.midNightBlue,/**/UserHandler.midNightBlue,
                /**/UserHandler.midNightBlue,UserHandler.midNightBlue,UserHandler.midNightBlue,UserHandler.midNightBlue,
                /**/UserHandler.midNightBlue,UserHandler.midNightBlue,UserHandler.midNightBlue,UserHandler.midNightBlue,UserHandler.midNightBlue};

            Color [] IconColorArray = {UserHandler.belizeHole,UserHandler.belizeHole,UserHandler.belizeHole,UserHandler.belizeHole,UserHandler.belizeHole,/**/UserHandler.belizeHole,
                /**/UserHandler.belizeHole,UserHandler.belizeHole,UserHandler.belizeHole,UserHandler.belizeHole,
                /**/UserHandler.belizeHole,UserHandler.belizeHole,UserHandler.belizeHole,UserHandler.belizeHole,UserHandler.belizeHole};

            userImage.setIcon(StretchImage.colorImage("Guest.png", true,50,50,UserHandler.midNightBlue));
            
            ArrayList<int[]> IconBoundArray = new ArrayList<int []>();

            IconBoundArray.add(0,new int[]{420,120,160,160});
            IconBoundArray.add(1,new int[]{60,120,160,160});
            IconBoundArray.add(2,new int[]{60,300,160,160});
            IconBoundArray.add(3,new int[]{60,480,160,160});
            IconBoundArray.add(4,new int[]{240, 480,160,160});
            IconBoundArray.add(5,new int[]{240, 300,160,160});
            IconBoundArray.add(6,new int[]{240, 120,160,160}); 
            IconBoundArray.add(7,new int[]{420, 300,160,160});
            IconBoundArray.add(8,new int[]{420, 480,160,160}); 
            IconBoundArray.add(9,new int[]{780,300,160,160});
            IconBoundArray.add(10,new int[]{600,120,160,160});
            IconBoundArray.add(11,new int[]{600,300,160,160});
            IconBoundArray.add(12,new int[]{600, 480,160,160});
            IconBoundArray.add(13,new int[]{270, 120,160,160});
            IconBoundArray.add(14,new int[]{270, 290,160,160});

            setIconBackgroundColors(IconBackgroundColorArray);
            setIconBounds(IconBoundArray);
            showIconSet(IconVisibleArray);
            setIconForegroundColors(true,IconColorArray);
            
            formBackgroundColor = UserHandler.turquoise;
            backgroundColor = UserHandler.turquoise;
            
            formSwiral.setIcon(new StretchImage("Swiral.png",false,5000, 5000).getImageIcon());
            swiral.setIcon(new StretchImage("Swiral.png",false,5000, 5000).getImageIcon());
            wallpaper.setBackground(backgroundColor);
            formWallpaper.setBackground(formBackgroundColor);
            Backup.setBackground(formBackgroundColor);
            
        
        } else {
            userIsAGuest = false;
        }
    }
    public void setIconForegroundColors(boolean sizeIsLarge,Color [] IconColorArray) {
        int size;
        
        if(sizeIsLarge) {
            size = 80;
        } else {
            size = 50;
        }
        
        CirculationIcon.setIcon(StretchImage.colorImage("Circulations.png",true,size,size,IconColorArray[0]));
        CatalogueIcon.setIcon(StretchImage.colorImage("Catalogues.png",true,size,size,IconColorArray[1]));
        QueueIcon.setIcon(StretchImage.colorImage("Queues.png",true,size,size,IconColorArray[2]));
        AcqusitionIcon.setIcon(StretchImage.colorImage("Acquisitions.png",true,size,size,IconColorArray[3]));
        ReportIcon.setIcon(StretchImage.colorImage("Reports.png",true,size,size,IconColorArray[4]));
        WebIcon.setIcon(StretchImage.colorImage("Web.png",true,size,size,IconColorArray[5]));
        SettingIcon.setIcon(StretchImage.colorImage("Setting.png",true,size,size,IconColorArray[6]));
        PatronIcon.setIcon(StretchImage.colorImage("Patrons.png",true,size,size,IconColorArray[7]));
        ArchiveIcon.setIcon(StretchImage.colorImage("Archives.png",true,size,size,IconColorArray[8]));
        ReferenceIcon.setIcon(StretchImage.colorImage("References.png",true,size,size,IconColorArray[9]));
        MessageIcon.setIcon(StretchImage.colorImage("Messages.png",true,size,size,IconColorArray[10]));
        DVDIcon.setIcon(StretchImage.colorImage("DVDs.png",true,size,size,IconColorArray[11]));
        EBookIcon.setIcon(StretchImage.colorImage("EBooks.png",true,size,size,IconColorArray[12]));
        BookIcon.setIcon(StretchImage.colorImage("Books.png",true,size,size,IconColorArray[13]));
        EmployeeIcon.setIcon(StretchImage.colorImage("Employees.png",true,80,80,IconColorArray[14]));
    }
    
    public void setIconBackgroundColors(Color [] IconColorArray) {
        Employee.setBackground(IconColorArray[0]);
        Book.setBackground(IconColorArray[1]);
        EBook.setBackground(IconColorArray[2]);
        DVD.setBackground(IconColorArray[3]);
        Message.setBackground(IconColorArray[4]);
        Reference.setBackground(IconColorArray[5]);
        Archive.setBackground(IconColorArray[6]);
        Patron.setBackground(IconColorArray[7]);
        Setting.setBackground(IconColorArray[8]);
        Web.setBackground(IconColorArray[9]);
        Report.setBackground(IconColorArray[10]);
        Circulation.setBackground(IconColorArray[11]);
        Catalogue.setBackground(IconColorArray[12]);
        Queue.setBackground(IconColorArray[13]);
        Acqusition.setBackground(IconColorArray[14]);
    }
    
    public void popupEnableCell(boolean enable){
        imageMenuItem.setEnabled(enable);
        noticeMenuItem.setEnabled(enable);
        noticeListMenuItem.setEnabled(enable);
        signInMenuItem.setEnabled(enable);
        signOutMenuItem.setEnabled(enable);
        changePasswordMenuItem.setEnabled(enable);
        settingsMenuItem.setEnabled(enable);
        helpMenuItem.setEnabled(enable);
        exactMenuItem.setEnabled(enable);
        regularMenuItem.setEnabled(enable);
        viewProfileMenuItem.setEnabled(enable);
        manageProfileMenuItem.setEnabled(enable);
    }
    
    public void setIconBounds(ArrayList<int[]> IconBoundArray){
        int [] setIconBounds = IconBoundArray.get(0);
        Message.setBounds(setIconBounds[0],setIconBounds[1],setIconBounds[2],setIconBounds[3]); 
        setIconBounds = IconBoundArray.get(1);
        Book.setBounds(setIconBounds[0],setIconBounds[1],setIconBounds[2],setIconBounds[3]);
        setIconBounds = IconBoundArray.get(2);
        EBook.setBounds(setIconBounds[0],setIconBounds[1],setIconBounds[2],setIconBounds[3]);
        setIconBounds = IconBoundArray.get(3);
        DVD.setBounds(setIconBounds[0],setIconBounds[1],setIconBounds[2],setIconBounds[3]);
        setIconBounds = IconBoundArray.get(4);
        Web.setBounds(setIconBounds[0],setIconBounds[1],setIconBounds[2],setIconBounds[3]);     
        setIconBounds = IconBoundArray.get(5);
        Catalogue.setBounds(setIconBounds[0],setIconBounds[1],setIconBounds[2],setIconBounds[3]);  
        setIconBounds = IconBoundArray.get(6);
        Patron.setBounds(setIconBounds[0],setIconBounds[1],setIconBounds[2],setIconBounds[3]);
        setIconBounds = IconBoundArray.get(7);
        Queue.setBounds(setIconBounds[0],setIconBounds[1],setIconBounds[2],setIconBounds[3]);  
        setIconBounds = IconBoundArray.get(8);
        Circulation.setBounds(setIconBounds[0],setIconBounds[1],setIconBounds[2],setIconBounds[3]);   
        setIconBounds = IconBoundArray.get(9);
        Report.setBounds(setIconBounds[0],setIconBounds[1],setIconBounds[2],setIconBounds[3]);   
        setIconBounds = IconBoundArray.get(10);
        Employee.setBounds(setIconBounds[0],setIconBounds[1],setIconBounds[2],setIconBounds[3]);  
        setIconBounds = IconBoundArray.get(11);
        Acqusition.setBounds(setIconBounds[0],setIconBounds[1],setIconBounds[2],setIconBounds[3]);  
        setIconBounds = IconBoundArray.get(12);
        Setting.setBounds(setIconBounds[0],setIconBounds[1],setIconBounds[2],setIconBounds[3]);  
        setIconBounds = IconBoundArray.get(13);
        Archive.setBounds(setIconBounds[0],setIconBounds[1],setIconBounds[2],setIconBounds[3]);
        setIconBounds = IconBoundArray.get(14);
        Reference.setBounds(setIconBounds[0],setIconBounds[1],setIconBounds[2],setIconBounds[3]);
    }

    @Override
    public void languageIsEnglish() {
        username.setText(EnglishStart + EnglishUsername + LineEnd);

        showQuote.setText("<html><font face=\"Segoe UI\">"+quoteInEnglish+"</font></html>");
        changeLanguage.setSelected(false);
        changeLanguage.setText("<html><font face=\"Segoe UI\">" +
                                            "Language : English<br>\n" +
                                            "</font></html>");
                
        tip ="<html><font color=\"#ffffff\" face=\"Segoe UI\">"+"    Close    "+"</font></html>";
        closeButton.setText(tip);
        tip ="<html><font color=\"#ffffff\" face=\"Segoe UI\">"+"   Profile   "+"</font></html>";
        profileButton.setText(tip);
        tip ="<html><font color=\"#ffffff\" face=\"Segoe UI\">"+"Translate"+"</font></html>";
        notificationsButton.setText(tip);
        tip ="<html><font color=\"#ffffff\" face=\"Segoe UI\">"+"  Messages   "+"</font></html>";
        messagesButton.setText(tip);
        tip ="<html><font color=\"#ffffff\" face=\"Segoe UI\">"+"    Help     "+"</font></html>";
        helpButton.setText(tip);
        tip ="<html><font color=\"#ffffff\" face=\"Segoe UI\">"+"  Settings   "+"</font></html>";
        settingsButton.setText(tip);
        
        tip ="<html><font color=\"#ffffff\" face=\"Segoe UI\">&nbsp&nbsp"+"  Employees   "+"</font></html>";
        Employee.setToolTipText(tip);
        EmployeeText.setText(tip);

        tip ="<html><font color=\"#ffffff\" face=\"Segoe UI\">&nbsp&nbsp"+"  Books  "+"</font></html>";
        Book.setToolTipText(tip);
        BookText.setText(tip);

        tip ="<html><font color=\"#ffffff\" face=\"Segoe UI\">&nbsp&nbsp"+"  Statistics  "+"</font></html>";
        EBook.setToolTipText(tip);
        EBookText.setText(tip);

        tip ="<html><font color=\"#ffffff\" face=\"Segoe UI\">&nbsp&nbsp"+"  DVDs  "+"</font></html>";
        DVD.setToolTipText(tip);
        DVDText.setText(tip);

        tip ="<html><font color=\"#ffffff\" face=\"Segoe UI\">&nbsp&nbsp"+"  Messages  "+"</font></html>";
        Message.setToolTipText(tip);
        MessageText.setText(tip);

        tip ="<html><font color=\"#ffffff\" face=\"Segoe UI\">&nbsp&nbsp"+"  References  "+"</font></html>";
        Reference.setToolTipText(tip);
        ReferenceText.setText(tip);

        tip ="<html><font color=\"#ffffff\" face=\"Segoe UI\">&nbsp&nbsp"+"  Archives  "+"</font></html>";
        Archive.setToolTipText(tip);
        ArchiveText.setText(tip);

        tip ="<html><font color=\"#ffffff\" face=\"Segoe UI\">&nbsp&nbsp"+"  Patrons  "+"</font></html>";
        Patron.setToolTipText(tip);
        PatronText.setText(tip);

        tip ="<html><font color=\"#ffffff\" face=\"Segoe UI\">&nbsp&nbsp"+"  Settings  "+"</font></html>";
        Setting.setToolTipText(tip);
        SettingText.setText(tip);

        tip ="<html><font color=\"#ffffff\" face=\"Segoe UI\">&nbsp&nbsp"+"  Web  "+"</font></html>";
        Web.setToolTipText(tip);
        WebText.setText(tip);

        tip ="<html><font color=\"#ffffff\" face=\"Segoe UI\">&nbsp&nbsp"+"  Reports  "+"</font></html>";
        Report.setToolTipText(tip);
        ReportText.setToolTipText(tip);
        
        tip ="<html><font color=\"#ffffff\" face=\"Segoe UI\">&nbsp&nbsp"+"  Circulations  "+"</font></html>";
        Circulation.setToolTipText(tip);
        CirculationText.setText(tip);
        
        tip ="<html><font color=\"#ffffff\" face=\"Segoe UI\">&nbsp&nbsp"+"  Catalogues  "+"</font></html>";
        Catalogue.setToolTipText(tip);
        CatalogueText.setText(tip);

        tip ="<html><font color=\"#ffffff\" face=\"Segoe UI\">&nbsp&nbsp"+"  Queues  "+"</font></html>";
        Queue.setToolTipText(tip);
        QueueText.setText(tip);        

        tip ="<html><font color=\"#ffffff\" face=\"Segoe UI\">&nbsp&nbsp"+"  Acquisitions  "+"</font></html>";
        Acqusition.setToolTipText(tip);
        AcqusitionText.setText(tip);
        
        this.repaint();
        this.validate();
    }

    @Override
    public void languageIsSinhala() {
        
        if(SinhalaUsername != null && !SinhalaUsername.trim().isEmpty()) {
           username.setText(SinhalaStart + SinhalaUsername + LineEnd);
        } else {
            username.setText(EnglishStart + EnglishUsername + LineEnd);
        }
           
        
        if(quoteInSinhala != null && !quoteInSinhala.trim().isEmpty()) {
          showQuote.setText("<html><font face=\"Iskoola pota\">"+quoteInSinhala+"</font></html>");
        } else {
           showQuote.setText("<html><font face=\"Segoe UI\">"+quoteInEnglish+"</font></html>");
        }
        
        changeLanguage.setSelected(true);
        changeLanguage.setText("<html>" + 
                                            "<font  size=\"3\" face=\"Iskoola Pota\">" +
                                            "භාෂාව : සිංහල\n" +
                                            "</font></html>");

        tip ="<html><font color=\"#ffffff\" face=\"Iskoola pota\">"+"    වසන්න     "+"</font></html>";
        closeButton.setText(tip);
        tip ="<html><font color=\"#ffffff\" face=\"Iskoola pota\">"+"   තොරතුරු  "+"</font></html>";
        profileButton.setText(tip);
        tip ="<html><font color=\"#ffffff\" face=\"Iskoola pota\">"+"   නිවේදන   "+"</font></html>";
        notificationsButton.setText(tip);
        tip ="<html><font color=\"#ffffff\" face=\"Iskoola pota\">"+"   පණිවිඩ    "+"</font></html>";
        messagesButton.setText(tip);
        tip ="<html><font color=\"#ffffff\" face=\"Iskoola pota\">"+"    උපකාර    "+"</font></html>";
        helpButton.setText(tip);
        tip ="<html><font color=\"#ffffff\" face=\"Iskoola pota\">"+"  වටාපිටාව   "+"</font></html>";
        settingsButton.setText(tip);
              
        tip ="<html><font color=\"#ffffff\" face=\"Iskoola pota\">&nbsp&nbsp"+"  කාර්ය මණ්ඩලය  "+"</font></html>";
        Employee.setToolTipText(tip);
        EmployeeText.setText(tip);

        tip ="<html><font color=\"#ffffff\" face=\"Iskoola pota\">&nbsp&nbsp"+"  පොත්  "+"</font></html>";
        Book.setToolTipText(tip);
        BookText.setText(tip);

        tip ="<html><font color=\"#ffffff\" face=\"Iskoola pota\">&nbsp&nbsp"+"  සංඛ්‍යාලේඛන "+"</font></html>";
        EBook.setToolTipText(tip);
        EBookText.setText(tip);

        tip ="<html><font color=\"#ffffff\" face=\"Iskoola pota\">&nbsp&nbsp"+"  දෘඩ  පිටපත්  "+"</font></html>";
        DVD.setToolTipText(tip);
        DVDText.setText(tip);

        tip ="<html><font color=\"#ffffff\" face=\"Iskoola pota\">&nbsp&nbsp"+"  පණිවිඩ  "+"</font></html>";
        Message.setToolTipText(tip);
        MessageText.setText(tip);

        tip ="<html><font color=\"#ffffff\" face=\"Iskoola pota\">&nbsp&nbsp"+"  යොමු  "+"</font></html>";
        Reference.setToolTipText(tip);
        ReferenceText.setText(tip);

        tip ="<html><font color=\"#ffffff\" face=\"Iskoola pota\">&nbsp&nbsp"+"  ලේඛනාගාරය  "+"</font></html>";
        Archive.setToolTipText(tip);
        ArchiveText.setText(tip);

        tip ="<html><font color=\"#ffffff\" face=\"Iskoola pota\">&nbsp&nbsp"+"  සාමාජිකයන්  "+"</font></html>";
        Patron.setToolTipText(tip);
        PatronText.setText(tip);

        tip ="<html><font color=\"#ffffff\" face=\"Iskoola pota\">&nbsp&nbsp"+"  විධාන  "+"</font></html>";
        Setting.setToolTipText(tip);
        SettingText.setText(tip);

        tip ="<html><font color=\"#ffffff\" face=\"Iskoola pota\">&nbsp&nbsp"+"  ජාලය  "+"</font></html>";
        Web.setToolTipText(tip);
        WebText.setText(tip);

        tip ="<html><font color=\"#ffffff\" face=\"Iskoola pota\">&nbsp&nbsp"+"  වාර්තා  "+"</font></html>";
        Report.setToolTipText(tip);
        ReportText.setToolTipText(tip);
        
        tip ="<html><font color=\"#ffffff\" face=\"Iskoola pota\">&nbsp&nbsp"+"  සංසරණ  "+"</font></html>";
        Circulation.setToolTipText(tip);
        CirculationText.setText(tip);
        
        tip ="<html><font color=\"#ffffff\" face=\"Iskoola pota\">&nbsp&nbsp"+"  නාමාවලිය  "+"</font></html>";
        Catalogue.setToolTipText(tip);
        CatalogueText.setText(tip);

        tip ="<html><font color=\"#ffffff\" face=\"Iskoola pota\">&nbsp&nbsp"+"  පෙළ  "+"</font></html>";
        Queue.setToolTipText(tip);
        QueueText.setText(tip);        

        tip ="<html><font color=\"#ffffff\" face=\"Iskoola pota\">&nbsp&nbsp"+"  භාණ්ඩ  "+"</font></html>";
        Acqusition.setToolTipText(tip);
        AcqusitionText.setText(tip);
        
        this.repaint();
        this.validate();
    }
    
    public void setTemp(ImageIcon icon,String UEng,String USin){
    userImage.setIcon(new StretchImage("Employees.png",true, 60,60).getImageIcon());
    if(changeLanguage.isSelected()){
    username.setText(UEng);
    }else {
        username.setText(USin);
    }
          EnglishUsername = UEng;
         SinhalaUsername = USin;
    }

    public static Color iconColor = UserHandler.belizeHole;
  //  public static Color backColor = UserHandler.pomegranate;
    private static boolean formVisible = true;
    //private static PanelSetter currentPanel = null;
    
    public Front() {
        initComponents();
         translator = new Translate.LanguageTranslator(this,changeLanguage);
       
        icon1.setVisible(false);
        searchPanel.setVisible(false);
        Notify.setVisible(false);
        
        
        icon.setIcon(StretchImage.colorImage("Icon.png", true,80,80,UserHandler.midNightBlue));
        icon1.setIcon(new StretchImage("logo.png",true,80,110).getImageIcon());

        settings.setIcon(StretchImage.colorImage("Settings.png", true,30,30,UserHandler.clouds));
       
        backspace.setIcon(StretchImage.colorImage("Back.png", true,40,40,UserHandler.midNightBlue));
        search.setIcon(StretchImage.colorImage("Search.png", true,40,40,UserHandler.clouds));
        userImage.setIcon(StretchImage.colorImage("Guest.png", true,50,50,UserHandler.midNightBlue));

        //Notify.setIcon(StretchImage.colorImage("Notify.png", true,40,40,UserHandler.pomegranate));
        Notify.setIcon(StretchImage.colorImage("Notify.png", true,40,40,UserHandler.clouds));
        
        UIManager.put("ToolTip.background", new ColorUIResource(Color.decode("#2c3e50"))); //#fff7c8
        Border border = BorderFactory.createLineBorder(Color.decode("#2c3e50"));    //#4c4f53
        UIManager.put("ToolTip.border", border);
        ToolTipManager.sharedInstance().setDismissDelay(10000); // 15 second display  
        
        closeButton.setIcon(StretchImage.colorImage("ClosePanel.png",true,20,20,iconColor));
        profileButton.setIcon(StretchImage.colorImage("ManageProfile.png",true,20,20,iconColor));
        notificationsButton.setIcon(StretchImage.colorImage("Notification.png",true,20,20,iconColor));
        messagesButton.setIcon(StretchImage.colorImage("Message.png",true,20,20,iconColor));
        helpButton.setIcon(StretchImage.colorImage("Help.png",true,20,20,iconColor));
        settingsButton.setIcon(StretchImage.colorImage("Settings.png",true,20,20,iconColor));
        
        if (SystemTray.isSupported()) {
            final SystemTray systemTray = SystemTray.getSystemTray();
            final TrayIcon trayIcon = new TrayIcon(StretchImage.colorImage("Icon.png", true,40,40,UserHandler.belizeHole).getImage(),
                    "ILMS, Gampaha Public Library");
            trayIcon.setImageAutoSize(true);
            MouseAdapter mouseAdapter = new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if(e.getClickCount() == 1 && e.getButton()==3) {
                    trayIcon.displayMessage("Welcome, We are up and running",
                            "Integrated Library Management System, Gampaha Public Library",
                            TrayIcon.MessageType.INFO);
                    } else {
                        Front.this.setVisible(true);
                        Front.this.setExtendedState(Front.NORMAL);
                    }
                }
            };
 
            trayIcon.addMouseListener(mouseAdapter);

            try {
                systemTray.add(trayIcon);
            } catch (Exception e) {
                e.printStackTrace();
            }
 
        }
        

       
        
        changeLanguage.setSelected(false);
        changeLanguage.setText("<html><font face=\"Segoe UI\">" +
                                            "Language : English<br>\n" +
                                            "</font></html>");
        
        String sinhalaTooltip ="භාෂා පරිවර්තනය";
        String englishTooltip ="Translate Language";
        changeLanguage.setToolTipText(UserHandler.setToolTip(englishTooltip, sinhalaTooltip));
        
        sinhalaTooltip ="ලාංඡනය";
        englishTooltip ="Logo";
        icon.setToolTipText(UserHandler.setToolTip(englishTooltip, sinhalaTooltip));

        sinhalaTooltip ="රූපය ";
        englishTooltip ="Image";
        userImage.setToolTipText(UserHandler.setToolTip(englishTooltip, sinhalaTooltip));

        sinhalaTooltip ="ගිණුම";
        englishTooltip ="Account";
        username.setToolTipText(UserHandler.setToolTip(englishTooltip, sinhalaTooltip));

        sinhalaTooltip ="විධාන";
        englishTooltip ="Settings";
        settings.setToolTipText(UserHandler.setToolTip(englishTooltip, sinhalaTooltip));

        sinhalaTooltip ="පණිිවිඩ";
        englishTooltip ="Messages";
        Notify.setToolTipText(UserHandler.setToolTip(englishTooltip, sinhalaTooltip));
        

        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        java.awt.Dimension frameSize = new java.awt.Dimension(1000, 700);
        this.setSize(frameSize);
        this.setPreferredSize(frameSize);
        this.setMaximumSize(frameSize);
        this.setMaximumSize(frameSize);
        java.awt.Point point;
        if((screenSize.width>frameSize.width && screenSize.height>frameSize.height) || (screenSize.width>=1024 && screenSize.height>=768)) {
            point = new java.awt.Point((int)(screenSize.width-frameSize.width)/2,(int)(screenSize.height-frameSize.height)/2);
        }else {
            point = new java.awt.Point(0,0);
        }
        this.setLocation(point);
        //this.getContentPane().setBackground(new java.awt.Color(0,0,0,0)); 
        this.setIconImage(StretchImage.colorImage("Icon.png", true,40,40,UserHandler.belizeHole).getImage());
        this.setLocationByPlatform(false);   
        this.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);        
        this.setFocusable(true);
        javax.swing.JFrame.setDefaultLookAndFeelDecorated(false);        
        this.setExtendedState(javax.swing.JFrame.NORMAL);
        this.setAlwaysOnTop(false);
        this.setFocusableWindowState(true);
        this.setFocusCycleRoot(true);
        
        
        Reference.setVisible(false);
        Report.setVisible(false);
        Archive.setVisible(false);
        
        
       /* form.setBackground(new Color(0,0,0,0));
        Dimension formSize = new Dimension(620, 560);
        form.setSize(formSize);
        form.setPreferredSize(formSize);
        form.setMaximumSize(formSize);
        form.setMinimumSize(formSize);
        form.setLocation(360, 95);
        //sign in form backgroun
        background.setSize(form.getSize());
        background.setPreferredSize(form.getSize());
        background.setMaximumSize(form.getSize());
        background.setMinimumSize(form.getSize());
        background.setLocation(0,0);
        background.setBorder(new CalloutBorder());
        background.setBackground(new Color(250,0,0,100));*/
        
        
        
        //

        //Notify.setIcon(new StretchImage("Notify.png",true,40, 40).getImageIcon());
        //MoveMouseHandler NotifyHandler = new MoveMouseHandler();
        //Notify.addMouseListener(NotifyHandler);
        //Notify.addMouseMotionListener(NotifyHandler);
        
        
        //wallpaper background
        wallpaper.setSize(this.getSize());
        wallpaper.setPreferredSize(this.getSize());
        wallpaper.setMaximumSize(this.getSize());
        wallpaper.setMinimumSize(this.getSize());
        wallpaper.setLocation(0,0);
        
        
        formWallpaper.setSize(new Dimension(880, 500));
        formWallpaper.setPreferredSize(new Dimension(880, 500));
        formWallpaper.setMaximumSize(new Dimension(880, 500));
        formWallpaper.setMinimumSize(new Dimension(880, 500));
        formWallpaper.setLocation(0,0);
      
        
        Backup.setSize(new Dimension(880, 500));
        Backup.setPreferredSize(new Dimension(880, 500));
        Backup.setMaximumSize(new Dimension(880, 500));
        Backup.setMinimumSize(new Dimension(880, 500));
        Backup.setLocation(10,10);
    




        
        /**********************
        MoveMouseHandler searchPanelHandler = new MoveMouseHandler();
            searchPanel.addMouseListener(searchPanelHandler);
            searchPanel.addMouseMotionListener(searchPanelHandler);
            
        MoveMouseHandler profilePanelHandler = new MoveMouseHandler();
            profilePanel.addMouseListener(profilePanelHandler);
            profilePanel.addMouseMotionListener(profilePanelHandler);
        
        MoveMouseHandler languagePanelHandler = new MoveMouseHandler();
            languagePanel.addMouseListener(languagePanelHandler);
            languagePanel.addMouseMotionListener(languagePanelHandler);
        
        //************************/
        MoveMouseHandler handler = new MoveMouseHandler();
            icon.addMouseListener(handler);
            icon.addMouseMotionListener(handler);
            
        MoveMouseHandler handler1 = new MoveMouseHandler();
            icon1.addMouseListener(handler1);
            icon1.addMouseMotionListener(handler1);
        
        MoveMouseHandler swiralHandler = new MoveMouseHandler();
            swiral.addMouseListener(swiralHandler);
            swiral.addMouseMotionListener(swiralHandler);

        swiral.addMouseWheelListener(new ResizeHandler());
        swiral.setSize(new Dimension(1000, 700));
        swiral.setPreferredSize(new Dimension(1000, 700));
        swiral.setMinimumSize(new Dimension(100,100));
        swiral.setMaximumSize(new Dimension(5000,5000));
        swiral.setLocation(0,0);
        swiral.setBackground(new Color(0,0,0,0));
        swiral.setOpaque(false);
        // swiral.setIcon(StretchImage.colorImage("Swiral.png", false,1000,700, 255, 255, 255));

        
        MoveMouseHandler formSwiralHandler = new MoveMouseHandler();
            formSwiral.addMouseListener(formSwiralHandler);
            formSwiral.addMouseMotionListener(formSwiralHandler);

        formSwiral.addMouseWheelListener(new ResizeHandler());
        formSwiral.setSize(new Dimension(880, 500));
        formSwiral.setPreferredSize(new Dimension(880, 500));
        formSwiral.setMinimumSize(new Dimension(100,100));
        formSwiral.setMaximumSize(new Dimension(5000,5000));
        formSwiral.setLocation(0,0);
        formSwiral.setBackground(new Color(0,0,0,0));
        formSwiral.setOpaque(false);
        // formSwiral.setIcon(StretchImage.colorImage("formSwiral.png", false,1000,700, 255, 255, 255));

        //**********************************************
       // UIManager.put("ToolTip.background", Color.RED);

        sinhalaTooltip ="ආයුබෝවන";
        englishTooltip ="Click here to search";

        //<body bgcolor=\"#E6E6FA\"></body>
        search.setToolTipText(UserHandler.setToolTip(englishTooltip, sinhalaTooltip));
        //*********************************
        //*********************************
        Employee.addComponentListener( new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                if(e.getComponent() instanceof JPanel) {
                    Dimension size = e.getComponent().getSize();
                
                JPanel panel = (JPanel) e.getComponent();
                for(Component j : panel.getComponents()){
                    if(j instanceof JLabel){
                        j.setSize((int)size.getWidth(), j.getHeight());
                        if(j.getHeight()==40 || j.getHeight()==30 || j.getHeight()==60){
                            if(size.height<=130){
                               j.setSize((int)size.getWidth(), 30);
                               j.setLocation(0,(int)size.getHeight()-30);
                            } else if(size.height>=200){
                               j.setSize((int)size.getWidth(), 60);
                               j.setLocation(0,(int)size.getHeight()-60);
                            } else {
                               j.setSize((int)size.getWidth(), 40);
                               j.setLocation(0,(int)size.getHeight()-40);
                            }
                           
                        } else {
                            j.setLocation(0,0);
                            if(size.height<=130){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-30);
                            } else if(size.height>=200){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-60);
                            } else {
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-40);
                            }
                        }
                    }
                    }
                }

            }
        });
        Employee.setMinimumSize(new Dimension(100,130));
        EmployeeIcon.setMinimumSize(new Dimension(100,100));
        EmployeeText.setMinimumSize(new Dimension(100,30));
        Employee.setMaximumSize(new Dimension(340,340));
        EmployeeIcon.setMaximumSize(new Dimension(340,280));
        EmployeeText.setMaximumSize(new Dimension(340,60));
        Employee.setPreferredSize(new Dimension(160,160));
        EmployeeIcon.setPreferredSize(new Dimension(160,120));
        EmployeeText.setPreferredSize(new Dimension(160,40));
        Employee.setSize(new Dimension(160,160));
        EmployeeIcon.setSize(new Dimension(160,120));
        EmployeeText.setSize(new Dimension(160,40));
        MoveMouseHandler EmployeeHandler = new MoveMouseHandler();
        Employee.addMouseListener(EmployeeHandler);
        Employee.addMouseMotionListener(EmployeeHandler);
        Employee.addMouseWheelListener(new ResizeHandler());
        //***
        EmployeeText.setHorizontalAlignment(JLabel.LEFT);


        Book.addComponentListener( new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                if(e.getComponent() instanceof JPanel) {
                    Dimension size = e.getComponent().getSize();
                
                JPanel panel = (JPanel) e.getComponent();
                for(Component j : panel.getComponents()){
                    if(j instanceof JLabel){
                        j.setSize((int)size.getWidth(), j.getHeight());
                        if(j.getHeight()==40 || j.getHeight()==30 || j.getHeight()==60){
                            if(size.height<=130){
                               j.setSize((int)size.getWidth(), 30);
                               j.setLocation(0,(int)size.getHeight()-30);
                            } else if(size.height>=200){
                               j.setSize((int)size.getWidth(), 60);
                               j.setLocation(0,(int)size.getHeight()-60);
                            } else {
                               j.setSize((int)size.getWidth(), 40);
                               j.setLocation(0,(int)size.getHeight()-40);
                            }
                           
                        } else {
                            j.setLocation(0,0);
                            if(size.height<=130){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-30);
                            } else if(size.height>=200){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-60);
                            } else {
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-40);
                            }
                        }
                    }
                    }
                }

            }
        });
        Book.setMinimumSize(new Dimension(100,130));
        BookIcon.setMinimumSize(new Dimension(100,100));
        BookText.setMinimumSize(new Dimension(100,30));
        Book.setMaximumSize(new Dimension(340,340));
        BookIcon.setMaximumSize(new Dimension(340,280));
        BookText.setMaximumSize(new Dimension(340,60));
        Book.setPreferredSize(new Dimension(160,160));
        BookIcon.setPreferredSize(new Dimension(160,120));
        BookText.setPreferredSize(new Dimension(160,40));
        Book.setSize(new Dimension(160,160));
        BookIcon.setSize(new Dimension(160,120));
        BookText.setSize(new Dimension(160,40));
        MoveMouseHandler BookHandler = new MoveMouseHandler();
        Book.addMouseListener(BookHandler);
        Book.addMouseMotionListener(BookHandler);
        Book.addMouseWheelListener(new ResizeHandler());
        //***
        BookText.setHorizontalAlignment(JLabel.LEFT);


        EBook.addComponentListener( new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                if(e.getComponent() instanceof JPanel) {
                    Dimension size = e.getComponent().getSize();
                
                JPanel panel = (JPanel) e.getComponent();
                for(Component j : panel.getComponents()){
                    if(j instanceof JLabel){
                        j.setSize((int)size.getWidth(), j.getHeight());
                        if(j.getHeight()==40 || j.getHeight()==30 || j.getHeight()==60){
                            if(size.height<=130){
                               j.setSize((int)size.getWidth(), 30);
                               j.setLocation(0,(int)size.getHeight()-30);
                            } else if(size.height>=200){
                               j.setSize((int)size.getWidth(), 60);
                               j.setLocation(0,(int)size.getHeight()-60);
                            } else {
                               j.setSize((int)size.getWidth(), 40);
                               j.setLocation(0,(int)size.getHeight()-40);
                            }
                           
                        } else {
                            j.setLocation(0,0);
                            if(size.height<=130){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-30);
                            } else if(size.height>=200){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-60);
                            } else {
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-40);
                            }
                        }
                    }
                    }
                }

            }
        });
        EBook.setMinimumSize(new Dimension(100,130));
        EBookIcon.setMinimumSize(new Dimension(100,100));
        EBookText.setMinimumSize(new Dimension(100,30));
        EBook.setMaximumSize(new Dimension(340,340));
        EBookIcon.setMaximumSize(new Dimension(340,280));
        EBookText.setMaximumSize(new Dimension(340,60));
        EBook.setPreferredSize(new Dimension(160,160));
        EBookIcon.setPreferredSize(new Dimension(160,120));
        EBookText.setPreferredSize(new Dimension(160,40));
        EBook.setSize(new Dimension(160,160));
        EBookIcon.setSize(new Dimension(160,120));
        EBookText.setSize(new Dimension(160,40));
        MoveMouseHandler EBookHandler = new MoveMouseHandler();
        EBook.addMouseListener(EBookHandler);
        EBook.addMouseMotionListener(EBookHandler);
        EBook.addMouseWheelListener(new ResizeHandler());
        //***
        EBookText.setHorizontalAlignment(JLabel.LEFT);


        DVD.addComponentListener( new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                if(e.getComponent() instanceof JPanel) {
                    Dimension size = e.getComponent().getSize();
                
                JPanel panel = (JPanel) e.getComponent();
                for(Component j : panel.getComponents()){
                    if(j instanceof JLabel){
                        j.setSize((int)size.getWidth(), j.getHeight());
                        if(j.getHeight()==40 || j.getHeight()==30 || j.getHeight()==60){
                            if(size.height<=130){
                               j.setSize((int)size.getWidth(), 30);
                               j.setLocation(0,(int)size.getHeight()-30);
                            } else if(size.height>=200){
                               j.setSize((int)size.getWidth(), 60);
                               j.setLocation(0,(int)size.getHeight()-60);
                            } else {
                               j.setSize((int)size.getWidth(), 40);
                               j.setLocation(0,(int)size.getHeight()-40);
                            }
                           
                        } else {
                            j.setLocation(0,0);
                            if(size.height<=130){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-30);
                            } else if(size.height>=200){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-60);
                            } else {
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-40);
                            }
                        }
                    }
                    }
                }

            }
        });
        DVD.setMinimumSize(new Dimension(100,130));
        DVDIcon.setMinimumSize(new Dimension(100,100));
        DVDText.setMinimumSize(new Dimension(100,30));
        DVD.setMaximumSize(new Dimension(340,340));
        DVDIcon.setMaximumSize(new Dimension(340,280));
        DVDText.setMaximumSize(new Dimension(340,60));
        DVD.setPreferredSize(new Dimension(160,160));
        DVDIcon.setPreferredSize(new Dimension(160,120));
        DVDText.setPreferredSize(new Dimension(160,40));
        DVD.setSize(new Dimension(160,160));
        DVDIcon.setSize(new Dimension(160,120));
        DVDText.setSize(new Dimension(160,40));
        MoveMouseHandler DVDHandler = new MoveMouseHandler();
        DVD.addMouseListener(DVDHandler);
        DVD.addMouseMotionListener(DVDHandler);
        DVD.addMouseWheelListener(new ResizeHandler());
        //***
        DVDText.setHorizontalAlignment(JLabel.LEFT);


        Message.addComponentListener( new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                if(e.getComponent() instanceof JPanel) {
                    Dimension size = e.getComponent().getSize();
                
                JPanel panel = (JPanel) e.getComponent();
                for(Component j : panel.getComponents()){
                    if(j instanceof JLabel){
                        j.setSize((int)size.getWidth(), j.getHeight());
                        if(j.getHeight()==40 || j.getHeight()==30 || j.getHeight()==60){
                            if(size.height<=130){
                               j.setSize((int)size.getWidth(), 30);
                               j.setLocation(0,(int)size.getHeight()-30);
                            } else if(size.height>=200){
                               j.setSize((int)size.getWidth(), 60);
                               j.setLocation(0,(int)size.getHeight()-60);
                            } else {
                               j.setSize((int)size.getWidth(), 40);
                               j.setLocation(0,(int)size.getHeight()-40);
                            }
                           
                        } else {
                            j.setLocation(0,0);
                            if(size.height<=130){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-30);
                            } else if(size.height>=200){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-60);
                            } else {
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-40);
                            }
                        }
                    }
                    }
                }

            }
        });
        Message.setMinimumSize(new Dimension(100,130));
        MessageIcon.setMinimumSize(new Dimension(100,100));
        MessageText.setMinimumSize(new Dimension(100,30));
        Message.setMaximumSize(new Dimension(340,340));
        MessageIcon.setMaximumSize(new Dimension(340,280));
        MessageText.setMaximumSize(new Dimension(340,60));
        Message.setPreferredSize(new Dimension(160,160));
        MessageIcon.setPreferredSize(new Dimension(160,120));
        MessageText.setPreferredSize(new Dimension(160,40));
        Message.setSize(new Dimension(160,160));
        MessageIcon.setSize(new Dimension(160,120));
        MessageText.setSize(new Dimension(160,40));
        MoveMouseHandler MessageHandler = new MoveMouseHandler();
        Message.addMouseListener(MessageHandler);
        Message.addMouseMotionListener(MessageHandler);
        Message.addMouseWheelListener(new ResizeHandler());
        //***
        MessageText.setHorizontalAlignment(JLabel.LEFT);

        
        Reference.addComponentListener( new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                if(e.getComponent() instanceof JPanel) {
                    Dimension size = e.getComponent().getSize();
                
                JPanel panel = (JPanel) e.getComponent();
                for(Component j : panel.getComponents()){
                    if(j instanceof JLabel){
                        j.setSize((int)size.getWidth(), j.getHeight());
                        if(j.getHeight()==40 || j.getHeight()==30 || j.getHeight()==60){
                            if(size.height<=130){
                               j.setSize((int)size.getWidth(), 30);
                               j.setLocation(0,(int)size.getHeight()-30);
                            } else if(size.height>=200){
                               j.setSize((int)size.getWidth(), 60);
                               j.setLocation(0,(int)size.getHeight()-60);
                            } else {
                               j.setSize((int)size.getWidth(), 40);
                               j.setLocation(0,(int)size.getHeight()-40);
                            }
                           
                        } else {
                            j.setLocation(0,0);
                            if(size.height<=130){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-30);
                            } else if(size.height>=200){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-60);
                            } else {
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-40);
                            }
                        }
                    }
                    }
                }

            }
        });
        Reference.setMinimumSize(new Dimension(100,130));
        ReferenceIcon.setMinimumSize(new Dimension(100,100));
        ReferenceText.setMinimumSize(new Dimension(100,30));
        Reference.setMaximumSize(new Dimension(340,340));
        ReferenceIcon.setMaximumSize(new Dimension(340,280));
        ReferenceText.setMaximumSize(new Dimension(340,60));
        Reference.setPreferredSize(new Dimension(160,160));
        ReferenceIcon.setPreferredSize(new Dimension(160,120));
        ReferenceText.setPreferredSize(new Dimension(160,40));
        Reference.setSize(new Dimension(160,160));
        ReferenceIcon.setSize(new Dimension(160,120));
        ReferenceText.setSize(new Dimension(160,40));
        MoveMouseHandler ReferenceHandler = new MoveMouseHandler();
        Reference.addMouseListener(ReferenceHandler);
        Reference.addMouseMotionListener(ReferenceHandler);
        Reference.addMouseWheelListener(new ResizeHandler());
        //***
        ReferenceText.setHorizontalAlignment(JLabel.LEFT);


        Archive.addComponentListener( new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                if(e.getComponent() instanceof JPanel) {
                    Dimension size = e.getComponent().getSize();
                
                JPanel panel = (JPanel) e.getComponent();
                for(Component j : panel.getComponents()){
                    if(j instanceof JLabel){
                        j.setSize((int)size.getWidth(), j.getHeight());
                        if(j.getHeight()==40 || j.getHeight()==30 || j.getHeight()==60){
                            if(size.height<=130){
                               j.setSize((int)size.getWidth(), 30);
                               j.setLocation(0,(int)size.getHeight()-30);
                            } else if(size.height>=200){
                               j.setSize((int)size.getWidth(), 60);
                               j.setLocation(0,(int)size.getHeight()-60);
                            } else {
                               j.setSize((int)size.getWidth(), 40);
                               j.setLocation(0,(int)size.getHeight()-40);
                            }
                           
                        } else {
                            j.setLocation(0,0);
                            if(size.height<=130){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-30);
                            } else if(size.height>=200){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-60);
                            } else {
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-40);
                            }
                        }
                    }
                    }
                }

            }
        });
        Archive.setMinimumSize(new Dimension(100,130));
        ArchiveIcon.setMinimumSize(new Dimension(100,100));
        ArchiveText.setMinimumSize(new Dimension(100,30));
        Archive.setMaximumSize(new Dimension(340,340));
        ArchiveIcon.setMaximumSize(new Dimension(340,280));
        ArchiveText.setMaximumSize(new Dimension(340,60));
        Archive.setPreferredSize(new Dimension(160,160));
        ArchiveIcon.setPreferredSize(new Dimension(160,120));
        ArchiveText.setPreferredSize(new Dimension(160,40));
        Archive.setSize(new Dimension(160,160));
        ArchiveIcon.setSize(new Dimension(160,120));
        ArchiveText.setSize(new Dimension(160,40));
        MoveMouseHandler ArchiveHandler = new MoveMouseHandler();
        Archive.addMouseListener(ArchiveHandler);
        Archive.addMouseMotionListener(ArchiveHandler);
        Archive.addMouseWheelListener(new ResizeHandler());
        //***
        ArchiveText.setHorizontalAlignment(JLabel.LEFT);


        Patron.addComponentListener( new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                if(e.getComponent() instanceof JPanel) {
                    Dimension size = e.getComponent().getSize();
                
                JPanel panel = (JPanel) e.getComponent();
                for(Component j : panel.getComponents()){
                    if(j instanceof JLabel){
                        j.setSize((int)size.getWidth(), j.getHeight());
                        if(j.getHeight()==40 || j.getHeight()==30 || j.getHeight()==60){
                            if(size.height<=130){
                               j.setSize((int)size.getWidth(), 30);
                               j.setLocation(0,(int)size.getHeight()-30);
                            } else if(size.height>=200){
                               j.setSize((int)size.getWidth(), 60);
                               j.setLocation(0,(int)size.getHeight()-60);
                            } else {
                               j.setSize((int)size.getWidth(), 40);
                               j.setLocation(0,(int)size.getHeight()-40);
                            }
                           
                        } else {
                            j.setLocation(0,0);
                            if(size.height<=130){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-30);
                            } else if(size.height>=200){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-60);
                            } else {
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-40);
                            }
                        }
                    }
                    }
                }

            }
        });
        Patron.setMinimumSize(new Dimension(100,130));
        PatronIcon.setMinimumSize(new Dimension(100,100));
        PatronText.setMinimumSize(new Dimension(100,30));
        Patron.setMaximumSize(new Dimension(340,340));
        PatronIcon.setMaximumSize(new Dimension(340,280));
        PatronText.setMaximumSize(new Dimension(340,60));
        Patron.setPreferredSize(new Dimension(160,160));
        PatronIcon.setPreferredSize(new Dimension(160,120));
        PatronText.setPreferredSize(new Dimension(160,40));
        Patron.setSize(new Dimension(160,160));
        PatronIcon.setSize(new Dimension(160,120));
        PatronText.setSize(new Dimension(160,40));
        MoveMouseHandler PatronHandler = new MoveMouseHandler();
        Patron.addMouseListener(PatronHandler);
        Patron.addMouseMotionListener(PatronHandler);
        Patron.addMouseWheelListener(new ResizeHandler());
        //***
        PatronText.setHorizontalAlignment(JLabel.LEFT);


        Setting.addComponentListener( new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                if(e.getComponent() instanceof JPanel) {
                    Dimension size = e.getComponent().getSize();
                
                JPanel panel = (JPanel) e.getComponent();
                for(Component j : panel.getComponents()){
                    if(j instanceof JLabel){
                        j.setSize((int)size.getWidth(), j.getHeight());
                        if(j.getHeight()==40 || j.getHeight()==30 || j.getHeight()==60){
                            if(size.height<=130){
                               j.setSize((int)size.getWidth(), 30);
                               j.setLocation(0,(int)size.getHeight()-30);
                            } else if(size.height>=200){
                               j.setSize((int)size.getWidth(), 60);
                               j.setLocation(0,(int)size.getHeight()-60);
                            } else {
                               j.setSize((int)size.getWidth(), 40);
                               j.setLocation(0,(int)size.getHeight()-40);
                            }
                           
                        } else {
                            j.setLocation(0,0);
                            if(size.height<=130){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-30);
                            } else if(size.height>=200){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-60);
                            } else {
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-40);
                            }
                        }
                    }
                    }
                }

            }
        });
        Setting.setMinimumSize(new Dimension(100,130));
        SettingIcon.setMinimumSize(new Dimension(100,100));
        SettingText.setMinimumSize(new Dimension(100,30));
        Setting.setMaximumSize(new Dimension(340,340));
        SettingIcon.setMaximumSize(new Dimension(340,280));
        SettingText.setMaximumSize(new Dimension(340,60));
        Setting.setPreferredSize(new Dimension(160,160));
        SettingIcon.setPreferredSize(new Dimension(160,120));
        SettingText.setPreferredSize(new Dimension(160,40));
        Setting.setSize(new Dimension(160,160));
        SettingIcon.setSize(new Dimension(160,120));
        SettingText.setSize(new Dimension(160,40));
        MoveMouseHandler SettingHandler = new MoveMouseHandler();
        Setting.addMouseListener(SettingHandler);
        Setting.addMouseMotionListener(SettingHandler);
        Setting.addMouseWheelListener(new ResizeHandler());
        //***
        SettingText.setHorizontalAlignment(JLabel.LEFT);

 
        Web.addComponentListener( new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                if(e.getComponent() instanceof JPanel) {
                    Dimension size = e.getComponent().getSize();
                
                JPanel panel = (JPanel) e.getComponent();
                for(Component j : panel.getComponents()){
                    if(j instanceof JLabel){
                        j.setSize((int)size.getWidth(), j.getHeight());
                        if(j.getHeight()==40 || j.getHeight()==30 || j.getHeight()==60){
                            if(size.height<=130){
                               j.setSize((int)size.getWidth(), 30);
                               j.setLocation(0,(int)size.getHeight()-30);
                            } else if(size.height>=200){
                               j.setSize((int)size.getWidth(), 60);
                               j.setLocation(0,(int)size.getHeight()-60);
                            } else {
                               j.setSize((int)size.getWidth(), 40);
                               j.setLocation(0,(int)size.getHeight()-40);
                            }
                           
                        } else {
                            j.setLocation(0,0);
                            if(size.height<=130){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-30);
                            } else if(size.height>=200){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-60);
                            } else {
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-40);
                            }
                        }
                    }
                    }
                }

            }
        });
        Web.setMinimumSize(new Dimension(100,130));
        WebIcon.setMinimumSize(new Dimension(100,100));
        WebText.setMinimumSize(new Dimension(100,30));
        Web.setMaximumSize(new Dimension(340,340));
        WebIcon.setMaximumSize(new Dimension(340,280));
        WebText.setMaximumSize(new Dimension(340,60));
        Web.setPreferredSize(new Dimension(160,160));
        WebIcon.setPreferredSize(new Dimension(160,120));
        WebText.setPreferredSize(new Dimension(160,40));
        Web.setSize(new Dimension(160,160));
        WebIcon.setSize(new Dimension(160,120));
        WebText.setSize(new Dimension(160,40));
        MoveMouseHandler WebHandler = new MoveMouseHandler();
        Web.addMouseListener(WebHandler);
        Web.addMouseMotionListener(WebHandler);
        Web.addMouseWheelListener(new ResizeHandler());
        //***
        WebText.setHorizontalAlignment(JLabel.LEFT);


        Report.addComponentListener( new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                if(e.getComponent() instanceof JPanel) {
                    Dimension size = e.getComponent().getSize();
                
                JPanel panel = (JPanel) e.getComponent();
                for(Component j : panel.getComponents()){
                    if(j instanceof JLabel){
                        j.setSize((int)size.getWidth(), j.getHeight());
                        if(j.getHeight()==40 || j.getHeight()==30 || j.getHeight()==60){
                            if(size.height<=130){
                               j.setSize((int)size.getWidth(), 30);
                               j.setLocation(0,(int)size.getHeight()-30);
                            } else if(size.height>=200){
                               j.setSize((int)size.getWidth(), 60);
                               j.setLocation(0,(int)size.getHeight()-60);
                            } else {
                               j.setSize((int)size.getWidth(), 40);
                               j.setLocation(0,(int)size.getHeight()-40);
                            }
                           
                        } else {
                            j.setLocation(0,0);
                            if(size.height<=130){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-30);
                            } else if(size.height>=200){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-60);
                            } else {
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-40);
                            }
                        }
                    }
                    }
                }

            }
        });
        Report.setMinimumSize(new Dimension(100,130));
        ReportIcon.setMinimumSize(new Dimension(100,100));
        ReportText.setMinimumSize(new Dimension(100,30));
        Report.setMaximumSize(new Dimension(340,340));
        ReportIcon.setMaximumSize(new Dimension(340,280));
        ReportText.setMaximumSize(new Dimension(340,60));
        Report.setPreferredSize(new Dimension(160,160));
        ReportIcon.setPreferredSize(new Dimension(160,120));
        ReportText.setPreferredSize(new Dimension(160,40));
        Report.setSize(new Dimension(160,160));
        ReportIcon.setSize(new Dimension(160,120));
        ReportText.setSize(new Dimension(160,40));
        MoveMouseHandler ReportHandler = new MoveMouseHandler();
        Report.addMouseListener(ReportHandler);
        Report.addMouseMotionListener(ReportHandler);
        Report.addMouseWheelListener(new ResizeHandler());
        //***
        ReportText.setHorizontalAlignment(JLabel.LEFT);

        
        Acqusition.addComponentListener( new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                if(e.getComponent() instanceof JPanel) {
                    Dimension size = e.getComponent().getSize();
                
                JPanel panel = (JPanel) e.getComponent();
                for(Component j : panel.getComponents()){
                    if(j instanceof JLabel){
                        j.setSize((int)size.getWidth(), j.getHeight());
                        if(j.getHeight()==40 || j.getHeight()==30 || j.getHeight()==60){
                            if(size.height<=130){
                               j.setSize((int)size.getWidth(), 30);
                               j.setLocation(0,(int)size.getHeight()-30);
                            } else if(size.height>=200){
                               j.setSize((int)size.getWidth(), 60);
                               j.setLocation(0,(int)size.getHeight()-60);
                            } else {
                               j.setSize((int)size.getWidth(), 40);
                               j.setLocation(0,(int)size.getHeight()-40);
                            }
                           
                        } else {
                            j.setLocation(0,0);
                            if(size.height<=130){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-30);
                            } else if(size.height>=200){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-60);
                            } else {
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-40);
                            }
                        }
                    }
                    }
                }

            }
        });
        Acqusition.setMinimumSize(new Dimension(100,130));
        AcqusitionIcon.setMinimumSize(new Dimension(100,100));
        AcqusitionText.setMinimumSize(new Dimension(100,30));
        Acqusition.setMaximumSize(new Dimension(340,340));
        AcqusitionIcon.setMaximumSize(new Dimension(340,280));
        AcqusitionText.setMaximumSize(new Dimension(340,60));
        Acqusition.setPreferredSize(new Dimension(160,160));
        AcqusitionIcon.setPreferredSize(new Dimension(160,120));
        AcqusitionText.setPreferredSize(new Dimension(160,40));
        Acqusition.setSize(new Dimension(160,160));
        AcqusitionIcon.setSize(new Dimension(160,120));
        AcqusitionText.setSize(new Dimension(160,40));
        MoveMouseHandler AcqusitionHandler = new MoveMouseHandler();
        Acqusition.addMouseListener(AcqusitionHandler);
        Acqusition.addMouseMotionListener(AcqusitionHandler);
        Acqusition.addMouseWheelListener(new ResizeHandler());
        //***
        AcqusitionText.setHorizontalAlignment(JLabel.LEFT);


        Queue.addComponentListener( new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                if(e.getComponent() instanceof JPanel) {
                    Dimension size = e.getComponent().getSize();
                
                JPanel panel = (JPanel) e.getComponent();
                for(Component j : panel.getComponents()){
                    if(j instanceof JLabel){
                        j.setSize((int)size.getWidth(), j.getHeight());
                        if(j.getHeight()==40 || j.getHeight()==30 || j.getHeight()==60){
                            if(size.height<=130){
                               j.setSize((int)size.getWidth(), 30);
                               j.setLocation(0,(int)size.getHeight()-30);
                            } else if(size.height>=200){
                               j.setSize((int)size.getWidth(), 60);
                               j.setLocation(0,(int)size.getHeight()-60);
                            } else {
                               j.setSize((int)size.getWidth(), 40);
                               j.setLocation(0,(int)size.getHeight()-40);
                            }
                           
                        } else {
                            j.setLocation(0,0);
                            if(size.height<=130){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-30);
                            } else if(size.height>=200){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-60);
                            } else {
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-40);
                            }
                        }
                    }
                    }
                }

            }
        });
        Queue.setMinimumSize(new Dimension(100,130));
        QueueIcon.setMinimumSize(new Dimension(100,100));
        QueueText.setMinimumSize(new Dimension(100,30));
        Queue.setMaximumSize(new Dimension(340,340));
        QueueIcon.setMaximumSize(new Dimension(340,280));
        QueueText.setMaximumSize(new Dimension(340,60));
        Queue.setPreferredSize(new Dimension(160,160));
        QueueIcon.setPreferredSize(new Dimension(160,120));
        QueueText.setPreferredSize(new Dimension(160,40));
        Queue.setSize(new Dimension(160,160));
        QueueIcon.setSize(new Dimension(160,120));
        QueueText.setSize(new Dimension(160,40));
        MoveMouseHandler QueueHandler = new MoveMouseHandler();
        Queue.addMouseListener(QueueHandler);
        Queue.addMouseMotionListener(QueueHandler);
        Queue.addMouseWheelListener(new ResizeHandler());
        //***
        QueueText.setHorizontalAlignment(JLabel.LEFT);


        Catalogue.addComponentListener( new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                if(e.getComponent() instanceof JPanel) {
                    Dimension size = e.getComponent().getSize();
                
                JPanel panel = (JPanel) e.getComponent();
                for(Component j : panel.getComponents()){
                    if(j instanceof JLabel){
                        j.setSize((int)size.getWidth(), j.getHeight());
                        if(j.getHeight()==40 || j.getHeight()==30 || j.getHeight()==60){
                            if(size.height<=130){
                               j.setSize((int)size.getWidth(), 30);
                               j.setLocation(0,(int)size.getHeight()-30);
                            } else if(size.height>=200){
                               j.setSize((int)size.getWidth(), 60);
                               j.setLocation(0,(int)size.getHeight()-60);
                            } else {
                               j.setSize((int)size.getWidth(), 40);
                               j.setLocation(0,(int)size.getHeight()-40);
                            }
                           
                        } else {
                            j.setLocation(0,0);
                            if(size.height<=130){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-30);
                            } else if(size.height>=200){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-60);
                            } else {
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-40);
                            }
                        }
                    }
                    }
                }

            }
        });
        Catalogue.setMinimumSize(new Dimension(100,130));
        CatalogueIcon.setMinimumSize(new Dimension(100,100));
        CatalogueText.setMinimumSize(new Dimension(100,30));
        Catalogue.setMaximumSize(new Dimension(340,340));
        CatalogueIcon.setMaximumSize(new Dimension(340,280));
        CatalogueText.setMaximumSize(new Dimension(340,60));
        Catalogue.setPreferredSize(new Dimension(160,160));
        CatalogueIcon.setPreferredSize(new Dimension(160,120));
        CatalogueText.setPreferredSize(new Dimension(160,40));
        Catalogue.setSize(new Dimension(160,160));
        CatalogueIcon.setSize(new Dimension(160,120));
        CatalogueText.setSize(new Dimension(160,40));
        MoveMouseHandler CatalogueHandler = new MoveMouseHandler();
        Catalogue.addMouseListener(CatalogueHandler);
        Catalogue.addMouseMotionListener(CatalogueHandler);
        Catalogue.addMouseWheelListener(new ResizeHandler());
        //***
        CatalogueText.setHorizontalAlignment(JLabel.LEFT);


        Circulation.addComponentListener( new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                if(e.getComponent() instanceof JPanel) {
                    Dimension size = e.getComponent().getSize();
                
                JPanel panel = (JPanel) e.getComponent();
                for(Component j : panel.getComponents()){
                    if(j instanceof JLabel){
                        j.setSize((int)size.getWidth(), j.getHeight());
                        if(j.getHeight()==40 || j.getHeight()==30 || j.getHeight()==60){
                            if(size.height<=130){
                               j.setSize((int)size.getWidth(), 30);
                               j.setLocation(0,(int)size.getHeight()-30);
                            } else if(size.height>=200){
                               j.setSize((int)size.getWidth(), 60);
                               j.setLocation(0,(int)size.getHeight()-60);
                            } else {
                               j.setSize((int)size.getWidth(), 40);
                               j.setLocation(0,(int)size.getHeight()-40);
                            }
                           
                        } else {
                            j.setLocation(0,0);
                            if(size.height<=130){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-30);
                            } else if(size.height>=200){
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-60);
                            } else {
                                j.setSize((int)size.getWidth(), (int)size.getHeight()-40);
                            }
                        }
                    }
                    }
                }

            }
        });
        Circulation.setMinimumSize(new Dimension(100,130));
        CirculationIcon.setMinimumSize(new Dimension(100,100));
        CirculationText.setMinimumSize(new Dimension(100,30));
        Circulation.setMaximumSize(new Dimension(340,340));
        CirculationIcon.setMaximumSize(new Dimension(340,280));
        CirculationText.setMaximumSize(new Dimension(340,60));
        Circulation.setPreferredSize(new Dimension(160,160));
        CirculationIcon.setPreferredSize(new Dimension(160,120));
        CirculationText.setPreferredSize(new Dimension(160,40));
        Circulation.setSize(new Dimension(160,160));
        CirculationIcon.setSize(new Dimension(160,120));
        CirculationText.setSize(new Dimension(160,40));
        MoveMouseHandler CirculationHandler = new MoveMouseHandler();
        Circulation.addMouseListener(CirculationHandler);
        Circulation.addMouseMotionListener(CirculationHandler);
        Circulation.addMouseWheelListener(new ResizeHandler());
        //***
        CirculationText.setHorizontalAlignment(JLabel.LEFT);
/*
    //  /*
        Message.setLocation(420, 120);
        Book.setLocation(60, 120);
        EBook.setLocation(60,300);
        DVD.setLocation(60, 480);
        Web.setLocation(240, 480);
        //Reference.setLocation(240, 300);
        //Archive.setLocation(240, 120);
        Catalogue.setLocation(240, 300);
        Patron.setLocation(240, 120);
        
        Queue.setLocation(420, 300);
        Circulation.setLocation(420, 480);
        //Setting.setLocation(780, 480);
        Report.setLocation(780,300);
        //Acqusition.setLocation(780,120);
        Employee.setLocation(600,120);
        Acqusition.setLocation(600,300);
        Setting.setLocation(600, 480);
 */
      //  */
        /*
        Book.setLocation(100, 120);
        EBook.setLocation(100,290);
        DVD.setLocation(100, 460);

        //Archive.setLocation(270, 120);
        //Reference.setLocation(270, 290);
        Message.setLocation(270, 460);
        
        Employee.setLocation(440, 120);
        Patron.setLocation(440, 290);
        Web.setLocation(440, 460);

        Queue.setLocation(610,120);
        Catalogue.setLocation(610,290);
        Circulation.setLocation(610, 460);
        
        //Acqusition.setLocation(780,120);
        Report.setLocation(780,290);
        //Setting.setLocation(780, 460);
        
        
        Setting.setLocation(270, 290);
        Acqusition.setLocation(270, 120);
*/
/*
        closeButton.setIcon(StretchImage.colorImage("ClosePanel.png",true,20,20,iconColor));
        profileButton.setIcon(StretchImage.colorImage("ManageProfile.png",true,20,20,iconColor));
        notificationsButton.setIcon(StretchImage.colorImage("Notification.png",true,20,20,iconColor));
        messagesButton.setIcon(StretchImage.colorImage("Message.png",true,20,20,iconColor));
        helpButton.setIcon(StretchImage.colorImage("Help.png",true,20,20,iconColor));
        settingsButton.setIcon(StretchImage.colorImage("Settings.png",true,20,20,iconColor));
        
        UIDefaults ui = UIManager.getLookAndFeelDefaults();
        ui.put("PopupMenu.background",new Color(236,240,241));
        ui.put("Menu.background", new Color(236,240,241));
        ui.put("Menu.opaque", true);
        ui.put("MenuItem.background",new Color(236,240,241));
        ui.put("MenuItem.opaque", true);
        ui.put("PopupMenu.contentMargins", null);
        */
        
        settings.setComponentPopupMenu(settingsPopup());
        username.setComponentPopupMenu(profilePopup());
        userImage.setComponentPopupMenu(imagePopup());
        search.setComponentPopupMenu(searchPopup());
        Notify.setComponentPopupMenu(messagePopup());
        
        Backup.add(putPanel(SignInPanel));
        Backup.add(putPanel(SignInPanel));
        Backup.add(putPanel(ProfilePanel));
        Backup.add(putPanel(MessagesPanel));
        Backup.add(putPanel(HelpPanel));
        Backup.add(putPanel(SettingsPanel));
        Backup.add(putPanel(SearchPanel));
        Backup.add(putPanel(QuotePanel));
        Backup.add(putPanel(NotificationsPanel));
        
        Backup.setComponentZOrder(SignInPanel, 0);
        Backup.setComponentZOrder(ProfilePanel, 1);
        Backup.setComponentZOrder(MessagesPanel, 2);
        Backup.setComponentZOrder(HelpPanel, 3);
        Backup.setComponentZOrder(SettingsPanel, 4);
        Backup.setComponentZOrder(SearchPanel, 5);
        Backup.setComponentZOrder(QuotePanel, 6);
        Backup.setComponentZOrder(NotificationsPanel, 7);
        
        languageIsEnglish();

        changeLanguage.setSelected(false);
        changeLanguage.setText("<html><font face=\"Segoe UI\">" +
                                            "Language : English<br>\n" +
                                            "</font></html>");
        
        if(!formVisible){
            this.repaint();
            form.setVisible(true);
            formVisible =true;
        } else {
            form.setVisible(false);
            formVisible =false;
        }
        Guest(true);
        show(SignInPanel);
        messagesButton.setVisible(false);
      //  changeUI();
       // this.pack();
        //this.repaint();

    }
    
    private final JPanel SignInPanel = new SignIn();
    private final JPanel ProfilePanel = new Profile();
    private final JPanel MessagesPanel = new Messages();
    private final JPanel HelpPanel = new Help();
    private final JPanel SettingsPanel = new Settings();
    private final JPanel SearchPanel = new Search();
    private final JPanel QuotePanel = new Quote();
    private final JPanel NotificationsPanel = new Notifications();
    //*****
    

    


    //private final JPanel ViewProfilePanel = new SignIn();
    
    
    //private final JPanel ChangePicturePanel = new SignIn();
    
    
    

    
   // private final JPanel NotificationListPanel = new SignIn();

   // private final JPanel ViewDailyQuote = new SignIn();
   /// private final JPanel SetDailyQuote = new SignIn();
    
    
    private JPanel putPanel(JPanel panel) {
        panel.setSize(new Dimension(0, 500));
        panel.setPreferredSize(new Dimension(0, 500));
        panel.setMaximumSize(new Dimension(880, 500));
        panel.setMinimumSize(new Dimension(0, 0));
        panel.setLocation(890,10);
        panel.setBackground(new Color(0,0,0,0));
        panel.setVisible(false);
        return panel;
    }
    /*
    private JPanel showPanel(PanelSetter panel) {
        currentPanel = panel;
        if(panel == PanelSetter.SignIn) {
            SignInPanel.setVisible(true);
            ProfilePanel.setVisible(false);
            MessagesPanel.setVisible(false);
            HelpPanel.setVisible(false);
            SettingsPanel.setVisible(false);
            SearchPanel.setVisible(false);
            QuotePanel.setVisible(false);
            NotificationsPanel.setVisible(false);
            return SignInPanel;
        } else if(panel == PanelSetter.Messages) {
            SignInPanel.setVisible(false);
            ProfilePanel.setVisible(false);
            MessagesPanel.setVisible(true);
            HelpPanel.setVisible(false);
            SettingsPanel.setVisible(false);
            SearchPanel.setVisible(false);
            QuotePanel.setVisible(false);
            NotificationsPanel.setVisible(false);
            return MessagesPanel;
        } else if(panel == PanelSetter.Profile) {
            SignInPanel.setVisible(false);
            ProfilePanel.setVisible(true);
            MessagesPanel.setVisible(false);
            HelpPanel.setVisible(false);
            SettingsPanel.setVisible(false);
            SearchPanel.setVisible(false);
            QuotePanel.setVisible(false);
            NotificationsPanel.setVisible(false);
            return ProfilePanel;
        } else if(panel == PanelSetter.Help) {
            SignInPanel.setVisible(false);
            ProfilePanel.setVisible(false);
            MessagesPanel.setVisible(false);
            HelpPanel.setVisible(true);
            SettingsPanel.setVisible(false);
            SearchPanel.setVisible(false);
            QuotePanel.setVisible(false);
            NotificationsPanel.setVisible(false);
            return HelpPanel;
        } else if(panel == PanelSetter.Settings) {
            SignInPanel.setVisible(false);
            ProfilePanel.setVisible(false);
            MessagesPanel.setVisible(false);
            HelpPanel.setVisible(false);
            SettingsPanel.setVisible(true);
            SearchPanel.setVisible(false);
            QuotePanel.setVisible(false);
            NotificationsPanel.setVisible(false);
            return SettingsPanel;
        } else if(panel == PanelSetter.Search) {
            SignInPanel.setVisible(false);
            ProfilePanel.setVisible(false);
            MessagesPanel.setVisible(false);
            HelpPanel.setVisible(false);
            SettingsPanel.setVisible(false);
            SearchPanel.setVisible(true);
            QuotePanel.setVisible(false);
            NotificationsPanel.setVisible(false);
            return SearchPanel;
        } else if(panel == PanelSetter.Quote) {
            SignInPanel.setVisible(false);
            ProfilePanel.setVisible(false);
            MessagesPanel.setVisible(false);
            HelpPanel.setVisible(false);
            SettingsPanel.setVisible(false);
            SearchPanel.setVisible(false);
            QuotePanel.setVisible(true);
            NotificationsPanel.setVisible(false);
            return QuotePanel;
        } else if(panel == PanelSetter.Notifications) {
            SignInPanel.setVisible(false);
            ProfilePanel.setVisible(false);
            MessagesPanel.setVisible(false);
            HelpPanel.setVisible(false);
            SettingsPanel.setVisible(false);
            SearchPanel.setVisible(false);
            QuotePanel.setVisible(false);
            NotificationsPanel.setVisible(true);
            return NotificationsPanel;
        }
        return null;
    }
    */
    public static enum PanelSetter {
        Notifications,Messages,Profile,Help,Settings,
        Search,Quote,SignIn
       /* ,ManageProfile,ChangePassword,ViewProfile,Manage,
        Search,NotificationList,
        ChangePicture,ViewDailyQuote,SetDailyQuote*/
    }

    
    private JPopupMenu settingsPopup() {
        final JPopupMenu settingsPopupMenu = new JPopupMenu();
        
        settingsPopupMenu.setLightWeightPopupEnabled(true);
        settingsPopupMenu.setBorder(new LineBorder(new Color(52,73,94), 5));
        
        ActionListener settingsPopupActionListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                System.out.println("Selected: " + actionEvent.getActionCommand());
                if(actionEvent.getActionCommand().contains("Sign In")){
                    show(SignInPanel);
                } else if (actionEvent.getActionCommand().contains("Sign Out")){
                   hideForm();
            // List<String> list = MySQL.MySQLMethods.getResultRow("SELECT `QuoteInEnglish`,`QuoteInSinhala` FROM employeedata.quote  ORDER BY `QuoteIndex` DESC LIMIT 1;",new String []{"`QuoteInEnglish`","`QuoteInSinhala`"});
             //Front.EnglishUsername = list.get(0);
            // Front.SinhalaUsername = list.get(1);
             UserHandler.mainInterface.Guest(true);
         
             UserHandler.mainInterface.showFormIcons(false);
                }
            }
        };
        
        signInMenuItem = new JMenuItem("Sign In",StretchImage.colorImage("SignIn.png", true, 40,40,new Color(52,73,94)));
        signInMenuItem.setSize(150,50);
        signInMenuItem.setPreferredSize(new Dimension(200, 50));
        signInMenuItem.setMinimumSize(new Dimension(200, 50));
        signInMenuItem.setMaximumSize(new Dimension(200, 50));
        signInMenuItem.addActionListener(settingsPopupActionListener);

        signOutMenuItem = new JMenuItem("Sign Out",StretchImage.colorImage("SignOut.png", true, 40,40,new Color(52,73,94)));
        signOutMenuItem.setSize(150,50);
        signOutMenuItem.setPreferredSize(new Dimension(200, 50));
        signOutMenuItem.setMinimumSize(new Dimension(200, 50));
        signOutMenuItem.setMaximumSize(new Dimension(200, 50));
        signOutMenuItem.addActionListener(settingsPopupActionListener);
        
        changePasswordMenuItem = new JMenuItem("Change Password",StretchImage.colorImage("ChangePassword.png", true, 40,40,new Color(52,73,94)));
        changePasswordMenuItem.setSize(150,50);
        changePasswordMenuItem.setPreferredSize(new Dimension(200, 50));
        changePasswordMenuItem.setMinimumSize(new Dimension(200, 50));
        changePasswordMenuItem.setMaximumSize(new Dimension(200, 50));
        changePasswordMenuItem.addActionListener(settingsPopupActionListener);

        settingsMenuItem = new JMenuItem("Settings",StretchImage.colorImage("Settings.png", true, 40,40,new Color(52,73,94)));
        settingsMenuItem.setSize(150,50);
        settingsMenuItem.setPreferredSize(new Dimension(200, 50));
        settingsMenuItem.setMinimumSize(new Dimension(200, 50));
        settingsMenuItem.setMaximumSize(new Dimension(200, 50));
        settingsMenuItem.addActionListener(settingsPopupActionListener);
        /*
        JMenuItem changeLanguageMenuItem = new JMenuItem("Change Language",StretchImage.colorImage("Language.png", true, 40,40,new Color(52,73,94)));
        changeLanguageMenuItem.setSize(150,50);
        changeLanguageMenuItem.setPreferredSize(new Dimension(200, 50));
        changeLanguageMenuItem.setMinimumSize(new Dimension(200, 50));
        changeLanguageMenuItem.setMaximumSize(new Dimension(200, 50));
        changeLanguageMenuItem.addActionListener(settingsPopupActionListener);
*/
        helpMenuItem = new JMenuItem("Help",StretchImage.colorImage("Help.png", true, 40,40,new Color(52,73,94)));
        helpMenuItem.setSize(150,50);
        helpMenuItem.setPreferredSize(new Dimension(200, 50));
        helpMenuItem.setMinimumSize(new Dimension(200, 50));
        helpMenuItem.setMaximumSize(new Dimension(200, 50));
        helpMenuItem.addActionListener(settingsPopupActionListener);

            //  help
            //--writing language
            //  use sinhala
            //  use english
            //--icon layout
            //  default
            //  tight
            //  preffered
        
        settingsPopupMenu.add(signOutMenuItem);
        settingsPopupMenu.add(signInMenuItem);
        settingsPopupMenu.add(changePasswordMenuItem);
        settingsPopupMenu.add(settingsMenuItem);
       // settingsPopupMenu.add(changeLanguageMenuItem);
        settingsPopupMenu.add(helpMenuItem);
        settingsPopupMenu.pack();
        settingsPopupMenu.repaint();
        return settingsPopupMenu;
    }
    
    private JPopupMenu profilePopup() {
        final JPopupMenu profilePopupMenu = new JPopupMenu();
        profilePopupMenu.setLightWeightPopupEnabled(true);
        profilePopupMenu.setBorder(new LineBorder(new Color(52,73,94), 5));
        
        ActionListener profilePopupActionListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                System.out.println("Selected: " + actionEvent.getActionCommand());
            }
        };

        viewProfileMenuItem = new JMenuItem("<html>View Profile<br>Profile</html>",StretchImage.colorImage("ViewProfile.png", true, 40,40,new Color(52,73,94)));
        viewProfileMenuItem.setSize(150,50);
        viewProfileMenuItem.setPreferredSize(new Dimension(200, 50));
        viewProfileMenuItem.setMinimumSize(new Dimension(200, 50));
        viewProfileMenuItem.setMaximumSize(new Dimension(200, 50));
        viewProfileMenuItem.addActionListener(profilePopupActionListener);
        
        manageProfileMenuItem = new JMenuItem("<html>Manage Profile<br>Profile</html>",StretchImage.colorImage("ManageProfile.png", true, 40,40,new Color(52,73,94)));
        manageProfileMenuItem.setSize(150,50);
        manageProfileMenuItem.setPreferredSize(new Dimension(200, 50));
        manageProfileMenuItem.setMinimumSize(new Dimension(200, 50));
        manageProfileMenuItem.setMaximumSize(new Dimension(200, 50));
        manageProfileMenuItem.addActionListener(profilePopupActionListener);

        profilePopupMenu.add(viewProfileMenuItem);
        profilePopupMenu.add(manageProfileMenuItem);
        profilePopupMenu.pack();
        profilePopupMenu.repaint();
        return profilePopupMenu;
    }

    private JPopupMenu searchPopup() {
        final JPopupMenu searchPopupMenu = new JPopupMenu();
        searchPopupMenu.setLightWeightPopupEnabled(true);
        searchPopupMenu.setBorder(new LineBorder(new Color(52,73,94), 5));
        
        ActionListener searchPopupActionListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                System.out.println("Selected: " + actionEvent.getActionCommand());
            }
        };

        exactMenuItem = new JMenuItem("<html>Exact<br>Exact</html>",StretchImage.colorImage("Exact.png", true, 40,40,new Color(52,73,94)));
        exactMenuItem.setSize(150,50);
        exactMenuItem.setPreferredSize(new Dimension(200, 50));
        exactMenuItem.setMinimumSize(new Dimension(200, 50));
        exactMenuItem.setMaximumSize(new Dimension(200, 50));
        exactMenuItem.addActionListener(searchPopupActionListener);
        
        regularMenuItem = new JMenuItem("<html>Regular<br>Regular</html>",StretchImage.colorImage("Regular.png", true, 40,40,new Color(52,73,94)));
        regularMenuItem.setSize(150,50);
        regularMenuItem.setPreferredSize(new Dimension(200, 50));
        regularMenuItem.setMinimumSize(new Dimension(200, 50));
        regularMenuItem.setMaximumSize(new Dimension(200, 50));
        regularMenuItem.addActionListener(searchPopupActionListener);

        searchPopupMenu.add(exactMenuItem);
        searchPopupMenu.add(regularMenuItem);
        searchPopupMenu.pack();
        searchPopupMenu.repaint();
        return searchPopupMenu;
    }
    
        private JPopupMenu messagePopup() {
        final JPopupMenu messagePopupMenu = new JPopupMenu();
        messagePopupMenu.setLightWeightPopupEnabled(true);
        messagePopupMenu.setBorder(new LineBorder(new Color(52,73,94), 5));
        
        ActionListener profilePopupActionListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                System.out.println("Selected: " + actionEvent.getActionCommand());
            }
        };

        noticeMenuItem = new JMenuItem("<html>Notices<br>Notices</html>",StretchImage.colorImage("Message.png", true, 40,40,new Color(52,73,94)));
        noticeMenuItem.setSize(150,50);
        noticeMenuItem.setPreferredSize(new Dimension(200, 50));
        noticeMenuItem.setMinimumSize(new Dimension(200, 50));
        noticeMenuItem.setMaximumSize(new Dimension(200, 50));
        noticeMenuItem.addActionListener(profilePopupActionListener);
        
        noticeListMenuItem = new JMenuItem("<html>Notices List<br>Notices List</html>",StretchImage.colorImage("MessageList.png", true, 40,40,new Color(52,73,94)));
        noticeListMenuItem.setSize(150,50);
        noticeListMenuItem.setPreferredSize(new Dimension(200, 50));
        noticeListMenuItem.setMinimumSize(new Dimension(200, 50));
        noticeListMenuItem.setMaximumSize(new Dimension(200, 50));
        noticeListMenuItem.addActionListener(profilePopupActionListener);

        messagePopupMenu.add(noticeMenuItem);
        messagePopupMenu.add(noticeListMenuItem);
        messagePopupMenu.pack();
        messagePopupMenu.repaint();
        return messagePopupMenu;
    }
    
    private JPopupMenu imagePopup() {
        final JPopupMenu imagePopupMenu = new JPopupMenu();
        imagePopupMenu.setLightWeightPopupEnabled(true);
        imagePopupMenu.setBorder(new LineBorder(new Color(52,73,94), 5));
        
        ActionListener imagePopupActionListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                //System.out.println("Selected: " + actionEvent.getActionCommand());
                show(ProfilePanel);
            }
        };

        imageMenuItem = new JMenuItem("<html>Change Image<br>Profile</html>",StretchImage.colorImage("Image.png", true, 40,40,new Color(52,73,94)));
        imageMenuItem.setSize(150,50);
        imageMenuItem.setPreferredSize(new Dimension(200, 50));
        imageMenuItem.setMinimumSize(new Dimension(200, 50));
        imageMenuItem.setMaximumSize(new Dimension(200, 50));
        imageMenuItem.addActionListener(imagePopupActionListener);

        imagePopupMenu.add(imageMenuItem);
        imagePopupMenu.pack();
        imagePopupMenu.repaint();
        return imagePopupMenu;
    }
    
    private JMenuItem imageMenuItem;
    private JMenuItem noticeMenuItem;
    private JMenuItem noticeListMenuItem;
    private JMenuItem signInMenuItem;
    private JMenuItem signOutMenuItem;
    private JMenuItem changePasswordMenuItem;
    private JMenuItem settingsMenuItem;
    private JMenuItem helpMenuItem;
    private JMenuItem exactMenuItem;
    private JMenuItem regularMenuItem;
    private JMenuItem viewProfileMenuItem;
    private JMenuItem manageProfileMenuItem;
            

    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        form = new javax.swing.JPanel();
        Backup = new javax.swing.JPanel();
        formSwiral = new javax.swing.JLabel();
        formWallpaper = new javax.swing.JLabel();
        settingsButton = new javax.swing.JButton();
        profileButton = new javax.swing.JButton();
        notificationsButton = new javax.swing.JButton();
        helpButton = new javax.swing.JButton();
        messagesButton = new javax.swing.JButton();
        closeButton = new javax.swing.JButton();
        profilePanel = new javax.swing.JPanel();
        settings = new javax.swing.JButton();
        userImage = new javax.swing.JLabel();
        username = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        Notify = new javax.swing.JLabel();
        languagePanel = new javax.swing.JPanel();
        searchPanel = new javax.swing.JPanel();
        search = new javax.swing.JButton();
        backspace = new javax.swing.JButton();
        searchText = new javax.swing.JTextField();
        Queue = new javax.swing.JPanel();
        QueueIcon = new javax.swing.JLabel();
        QueueText = new javax.swing.JLabel();
        Employee = new javax.swing.JPanel();
        EmployeeIcon = new javax.swing.JLabel();
        EmployeeText = new javax.swing.JLabel();
        Book = new javax.swing.JPanel();
        BookIcon = new javax.swing.JLabel();
        BookText = new javax.swing.JLabel();
        DVD = new javax.swing.JPanel();
        DVDIcon = new javax.swing.JLabel();
        DVDText = new javax.swing.JLabel();
        Reference = new javax.swing.JPanel();
        ReferenceIcon = new javax.swing.JLabel();
        ReferenceText = new javax.swing.JLabel();
        Message = new javax.swing.JPanel();
        MessageIcon = new javax.swing.JLabel();
        MessageText = new javax.swing.JLabel();
        Patron = new javax.swing.JPanel();
        PatronIcon = new javax.swing.JLabel();
        PatronText = new javax.swing.JLabel();
        Setting = new javax.swing.JPanel();
        SettingIcon = new javax.swing.JLabel();
        SettingText = new javax.swing.JLabel();
        Acqusition = new javax.swing.JPanel();
        AcqusitionIcon = new javax.swing.JLabel();
        AcqusitionText = new javax.swing.JLabel();
        Report = new javax.swing.JPanel();
        ReportIcon = new javax.swing.JLabel();
        ReportText = new javax.swing.JLabel();
        Circulation = new javax.swing.JPanel();
        CirculationIcon = new javax.swing.JLabel();
        CirculationText = new javax.swing.JLabel();
        Catalogue = new javax.swing.JPanel();
        CatalogueIcon = new javax.swing.JLabel();
        CatalogueText = new javax.swing.JLabel();
        Archive = new javax.swing.JPanel();
        ArchiveIcon = new javax.swing.JLabel();
        ArchiveText = new javax.swing.JLabel();
        Web = new javax.swing.JPanel();
        WebIcon = new javax.swing.JLabel();
        WebText = new javax.swing.JLabel();
        EBook = new javax.swing.JPanel();
        EBookIcon = new javax.swing.JLabel();
        EBookText = new javax.swing.JLabel();
        showQuote = new javax.swing.JLabel();
        QuoteOfTheDay = new javax.swing.JLabel();
        icon1 = new javax.swing.JLabel();
        icon = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        swiral = new javax.swing.JLabel();
        wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Integrated Library Management System - Gampaha Public Library");
        setMinimumSize(new java.awt.Dimension(1000, 700));
        setResizable(false);
        getContentPane().setLayout(null);

        form.setBackground(new java.awt.Color(52, 73, 94));
        form.setLayout(null);

        Backup.setLayout(null);

        formSwiral.setOpaque(true);
        Backup.add(formSwiral);
        formSwiral.setBounds(0, 0, 880, 500);

        formWallpaper.setOpaque(true);
        Backup.add(formWallpaper);
        formWallpaper.setBounds(0, 0, 880, 500);

        form.add(Backup);
        Backup.setBounds(10, 10, 880, 500);

        settingsButton.setBackground(new java.awt.Color(52, 73, 94));
        settingsButton.setText("jButton1");
        settingsButton.setBorderPainted(false);
        settingsButton.setContentAreaFilled(false);
        settingsButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        settingsButton.setName(""); // NOI18N
        settingsButton.setOpaque(true);
        settingsButton.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        settingsButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        settingsButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                settingsButtonMouseClicked(evt);
            }
        });
        settingsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                settingsButtonActionPerformed(evt);
            }
        });
        form.add(settingsButton);
        settingsButton.setBounds(890, 90, 110, 80);

        profileButton.setBackground(new java.awt.Color(52, 73, 94));
        profileButton.setText("jButton1");
        profileButton.setBorderPainted(false);
        profileButton.setContentAreaFilled(false);
        profileButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        profileButton.setName(""); // NOI18N
        profileButton.setOpaque(true);
        profileButton.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        profileButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        profileButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                profileButtonMouseClicked(evt);
            }
        });
        profileButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                profileButtonActionPerformed(evt);
            }
        });
        form.add(profileButton);
        profileButton.setBounds(890, 170, 110, 80);

        notificationsButton.setBackground(new java.awt.Color(52, 73, 94));
        notificationsButton.setText("jButton1");
        notificationsButton.setBorderPainted(false);
        notificationsButton.setContentAreaFilled(false);
        notificationsButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        notificationsButton.setName(""); // NOI18N
        notificationsButton.setOpaque(true);
        notificationsButton.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        notificationsButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        notificationsButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                notificationsButtonMouseClicked(evt);
            }
        });
        notificationsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                notificationsButtonActionPerformed(evt);
            }
        });
        form.add(notificationsButton);
        notificationsButton.setBounds(890, 330, 110, 100);

        helpButton.setBackground(new java.awt.Color(52, 73, 94));
        helpButton.setText("jButton1");
        helpButton.setBorderPainted(false);
        helpButton.setContentAreaFilled(false);
        helpButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        helpButton.setName(""); // NOI18N
        helpButton.setOpaque(true);
        helpButton.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        helpButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        helpButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                helpButtonMouseClicked(evt);
            }
        });
        helpButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                helpButtonActionPerformed(evt);
            }
        });
        form.add(helpButton);
        helpButton.setBounds(890, 250, 110, 80);

        messagesButton.setBackground(new java.awt.Color(52, 73, 94));
        messagesButton.setText("jButton1");
        messagesButton.setBorderPainted(false);
        messagesButton.setContentAreaFilled(false);
        messagesButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        messagesButton.setName(""); // NOI18N
        messagesButton.setOpaque(true);
        messagesButton.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        messagesButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        messagesButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                messagesButtonMouseClicked(evt);
            }
        });
        messagesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                messagesButtonActionPerformed(evt);
            }
        });
        form.add(messagesButton);
        messagesButton.setBounds(880, 420, 110, 80);

        closeButton.setBackground(new java.awt.Color(52, 73, 94));
        closeButton.setText("jButton1");
        closeButton.setBorderPainted(false);
        closeButton.setContentAreaFilled(false);
        closeButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        closeButton.setName(""); // NOI18N
        closeButton.setOpaque(true);
        closeButton.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        closeButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        closeButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                closeButtonMouseClicked(evt);
            }
        });
        closeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeButtonActionPerformed(evt);
            }
        });
        form.add(closeButton);
        closeButton.setBounds(890, 10, 110, 80);

        getContentPane().add(form);
        form.setBounds(-90, 180, 1000, 480);

        profilePanel.setBackground(new java.awt.Color(52, 73, 94));
        profilePanel.setToolTipText("");
        profilePanel.setLayout(null);

        settings.setBackground(new java.awt.Color(52, 73, 94));
        settings.setContentAreaFilled(false);
        settings.setOpaque(true);
        settings.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                settingsMouseClicked(evt);
            }
        });
        settings.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                settingsActionPerformed(evt);
            }
        });
        profilePanel.add(settings);
        settings.setBounds(320, 10, 30, 60);

        userImage.setBackground(new java.awt.Color(236, 240, 241));
        userImage.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        userImage.setToolTipText("");
        userImage.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        userImage.setOpaque(true);
        userImage.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                userImageMouseClicked(evt);
            }
        });
        profilePanel.add(userImage);
        userImage.setBounds(10, 10, 60, 60);

        username.setBackground(new java.awt.Color(44, 62, 80));
        username.setFont(new java.awt.Font("Iskoola Pota", 0, 36)); // NOI18N
        username.setForeground(new java.awt.Color(255, 255, 255));
        username.setText("Guest");
        username.setOpaque(true);
        username.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                usernameMouseClicked(evt);
            }
        });
        profilePanel.add(username);
        username.setBounds(90, 10, 200, 60);

        jLabel9.setBackground(new java.awt.Color(44, 62, 80));
        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setOpaque(true);
        profilePanel.add(jLabel9);
        jLabel9.setBounds(80, 10, 10, 60);

        Notify.setBackground(new java.awt.Color(52, 73, 94));
        Notify.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Notify.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        profilePanel.add(Notify);
        Notify.setBounds(340, 10, 40, 60);

        getContentPane().add(profilePanel);
        profilePanel.setBounds(460, 10, 390, 80);

        languagePanel.setBackground(new java.awt.Color(52, 73, 94));
        languagePanel.setToolTipText("");
        languagePanel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        languagePanel.setLayout(null);

        changeLanguage.setBackground(new java.awt.Color(236, 240, 241));
        changeLanguage.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        changeLanguage.setForeground(new java.awt.Color(52, 73, 94));
        changeLanguage.setSelected(true);
        changeLanguage.setText("Change Language");
        changeLanguage.setToolTipText("");
        changeLanguage.setContentAreaFilled(false);
        changeLanguage.setDoubleBuffered(true);
        changeLanguage.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        changeLanguage.setOpaque(true);
        languagePanel.add(changeLanguage);
        changeLanguage.setBounds(10, 10, 140, 60);

        getContentPane().add(languagePanel);
        languagePanel.setBounds(840, 10, 160, 80);

        searchPanel.setBackground(new java.awt.Color(52, 73, 94));
        searchPanel.setToolTipText("");
        searchPanel.setLayout(null);

        search.setToolTipText("");
        search.setContentAreaFilled(false);
        search.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchMouseClicked(evt);
            }
        });
        searchPanel.add(search);
        search.setBounds(300, 10, 33, 60);

        backspace.setToolTipText("Erase last letter left to the cursor");
        backspace.setContentAreaFilled(false);
        backspace.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                backspaceMouseClicked(evt);
            }
        });
        searchPanel.add(backspace);
        backspace.setBounds(250, 10, 40, 60);

        searchText.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        searchText.setForeground(new java.awt.Color(52, 73, 94));
        searchText.setText("Search");
        searchText.setToolTipText("Type here to search");
        searchText.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchTextMouseClicked(evt);
            }
        });
        searchPanel.add(searchText);
        searchText.setBounds(10, 10, 280, 60);

        getContentPane().add(searchPanel);
        searchPanel.setBounds(110, 10, 340, 80);

        Queue.setLayout(null);

        QueueIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        QueueIcon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Queue.add(QueueIcon);
        QueueIcon.setBounds(0, 0, 160, 70);

        QueueText.setBackground(new java.awt.Color(51, 51, 51));
        QueueText.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        QueueText.setForeground(new java.awt.Color(236, 240, 241));
        QueueText.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        QueueText.setText("  Employees");
        QueueText.setToolTipText("");
        QueueText.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        QueueText.setPreferredSize(new java.awt.Dimension(46, 40));
        Queue.add(QueueText);
        QueueText.setBounds(0, 120, 160, 40);

        getContentPane().add(Queue);
        Queue.setBounds(360, 120, 160, 160);

        Employee.setLayout(null);

        EmployeeIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        EmployeeIcon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Employee.add(EmployeeIcon);
        EmployeeIcon.setBounds(0, 0, 160, 70);

        EmployeeText.setBackground(new java.awt.Color(51, 51, 51));
        EmployeeText.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        EmployeeText.setForeground(new java.awt.Color(236, 240, 241));
        EmployeeText.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        EmployeeText.setText("  Employees");
        EmployeeText.setToolTipText("");
        EmployeeText.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        EmployeeText.setPreferredSize(new java.awt.Dimension(46, 40));
        Employee.add(EmployeeText);
        EmployeeText.setBounds(0, 120, 160, 40);

        getContentPane().add(Employee);
        Employee.setBounds(760, 300, 160, 160);

        Book.setLayout(null);

        BookIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        BookIcon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Book.add(BookIcon);
        BookIcon.setBounds(0, 0, 160, 70);

        BookText.setBackground(new java.awt.Color(51, 51, 51));
        BookText.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BookText.setForeground(new java.awt.Color(236, 240, 241));
        BookText.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        BookText.setText("  Employees");
        BookText.setToolTipText("");
        BookText.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        BookText.setPreferredSize(new java.awt.Dimension(46, 40));
        Book.add(BookText);
        BookText.setBounds(0, 120, 160, 40);

        getContentPane().add(Book);
        Book.setBounds(10, 120, 160, 160);

        DVD.setLayout(null);

        DVDIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        DVDIcon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        DVD.add(DVDIcon);
        DVDIcon.setBounds(0, 0, 160, 70);

        DVDText.setBackground(new java.awt.Color(51, 51, 51));
        DVDText.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        DVDText.setForeground(new java.awt.Color(236, 240, 241));
        DVDText.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        DVDText.setText("  Employees");
        DVDText.setToolTipText("");
        DVDText.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        DVDText.setPreferredSize(new java.awt.Dimension(46, 40));
        DVD.add(DVDText);
        DVDText.setBounds(0, 120, 160, 40);

        getContentPane().add(DVD);
        DVD.setBounds(20, 480, 160, 160);

        Reference.setLayout(null);

        ReferenceIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ReferenceIcon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Reference.add(ReferenceIcon);
        ReferenceIcon.setBounds(0, 0, 160, 70);

        ReferenceText.setBackground(new java.awt.Color(51, 51, 51));
        ReferenceText.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ReferenceText.setForeground(new java.awt.Color(236, 240, 241));
        ReferenceText.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        ReferenceText.setText("  Employees");
        ReferenceText.setToolTipText("");
        ReferenceText.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        ReferenceText.setPreferredSize(new java.awt.Dimension(46, 40));
        Reference.add(ReferenceText);
        ReferenceText.setBounds(0, 120, 160, 40);

        getContentPane().add(Reference);
        Reference.setBounds(200, 300, 160, 160);

        Message.setLayout(null);

        MessageIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MessageIcon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Message.add(MessageIcon);
        MessageIcon.setBounds(0, 0, 160, 70);

        MessageText.setBackground(new java.awt.Color(51, 51, 51));
        MessageText.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        MessageText.setForeground(new java.awt.Color(236, 240, 241));
        MessageText.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        MessageText.setText("  Employees");
        MessageText.setToolTipText("");
        MessageText.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        MessageText.setPreferredSize(new java.awt.Dimension(46, 40));
        Message.add(MessageText);
        MessageText.setBounds(0, 120, 160, 40);

        getContentPane().add(Message);
        Message.setBounds(200, 480, 160, 160);

        Patron.setLayout(null);

        PatronIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        PatronIcon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Patron.add(PatronIcon);
        PatronIcon.setBounds(0, 0, 160, 70);

        PatronText.setBackground(new java.awt.Color(51, 51, 51));
        PatronText.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        PatronText.setForeground(new java.awt.Color(236, 240, 241));
        PatronText.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        PatronText.setText("  Employees");
        PatronText.setToolTipText("");
        PatronText.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        PatronText.setPreferredSize(new java.awt.Dimension(46, 40));
        Patron.add(PatronText);
        PatronText.setBounds(0, 120, 160, 40);

        getContentPane().add(Patron);
        Patron.setBounds(380, 300, 160, 160);

        Setting.setLayout(null);

        SettingIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SettingIcon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Setting.add(SettingIcon);
        SettingIcon.setBounds(0, 0, 160, 70);

        SettingText.setBackground(new java.awt.Color(51, 51, 51));
        SettingText.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        SettingText.setForeground(new java.awt.Color(236, 240, 241));
        SettingText.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        SettingText.setText("  Employees");
        SettingText.setToolTipText("");
        SettingText.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        SettingText.setPreferredSize(new java.awt.Dimension(46, 40));
        Setting.add(SettingText);
        SettingText.setBounds(0, 120, 160, 40);

        getContentPane().add(Setting);
        Setting.setBounds(380, 480, 160, 160);

        Acqusition.setLayout(null);

        AcqusitionIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        AcqusitionIcon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Acqusition.add(AcqusitionIcon);
        AcqusitionIcon.setBounds(0, 0, 160, 70);

        AcqusitionText.setBackground(new java.awt.Color(51, 51, 51));
        AcqusitionText.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        AcqusitionText.setForeground(new java.awt.Color(236, 240, 241));
        AcqusitionText.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        AcqusitionText.setText("  Employees");
        AcqusitionText.setToolTipText("");
        AcqusitionText.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        AcqusitionText.setPreferredSize(new java.awt.Dimension(46, 40));
        Acqusition.add(AcqusitionText);
        AcqusitionText.setBounds(0, 120, 160, 40);

        getContentPane().add(Acqusition);
        Acqusition.setBounds(540, 120, 160, 160);

        Report.setLayout(null);

        ReportIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ReportIcon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Report.add(ReportIcon);
        ReportIcon.setBounds(0, 0, 160, 70);

        ReportText.setBackground(new java.awt.Color(51, 51, 51));
        ReportText.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ReportText.setForeground(new java.awt.Color(236, 240, 241));
        ReportText.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        ReportText.setText("  Employees");
        ReportText.setToolTipText("");
        ReportText.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        ReportText.setPreferredSize(new java.awt.Dimension(46, 40));
        Report.add(ReportText);
        ReportText.setBounds(0, 120, 160, 40);

        getContentPane().add(Report);
        Report.setBounds(560, 300, 160, 160);

        Circulation.setLayout(null);

        CirculationIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CirculationIcon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Circulation.add(CirculationIcon);
        CirculationIcon.setBounds(0, 0, 160, 70);

        CirculationText.setBackground(new java.awt.Color(51, 51, 51));
        CirculationText.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        CirculationText.setForeground(new java.awt.Color(236, 240, 241));
        CirculationText.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        CirculationText.setText("  Employees");
        CirculationText.setToolTipText("");
        CirculationText.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        CirculationText.setPreferredSize(new java.awt.Dimension(46, 40));
        Circulation.add(CirculationText);
        CirculationText.setBounds(0, 120, 160, 40);

        getContentPane().add(Circulation);
        Circulation.setBounds(560, 480, 160, 160);

        Catalogue.setLayout(null);

        CatalogueIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CatalogueIcon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Catalogue.add(CatalogueIcon);
        CatalogueIcon.setBounds(0, 0, 160, 70);

        CatalogueText.setBackground(new java.awt.Color(51, 51, 51));
        CatalogueText.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        CatalogueText.setForeground(new java.awt.Color(236, 240, 241));
        CatalogueText.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        CatalogueText.setText("  Employees");
        CatalogueText.setToolTipText("");
        CatalogueText.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        CatalogueText.setPreferredSize(new java.awt.Dimension(46, 40));
        Catalogue.add(CatalogueText);
        CatalogueText.setBounds(0, 120, 160, 40);

        getContentPane().add(Catalogue);
        Catalogue.setBounds(750, 120, 160, 160);

        Archive.setLayout(null);

        ArchiveIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ArchiveIcon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Archive.add(ArchiveIcon);
        ArchiveIcon.setBounds(0, 0, 160, 70);

        ArchiveText.setBackground(new java.awt.Color(51, 51, 51));
        ArchiveText.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ArchiveText.setForeground(new java.awt.Color(236, 240, 241));
        ArchiveText.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        ArchiveText.setText("  Employees");
        ArchiveText.setToolTipText("");
        ArchiveText.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        ArchiveText.setPreferredSize(new java.awt.Dimension(46, 40));
        Archive.add(ArchiveText);
        ArchiveText.setBounds(0, 120, 160, 40);

        getContentPane().add(Archive);
        Archive.setBounds(190, 120, 160, 160);

        Web.setLayout(null);

        WebIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WebIcon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Web.add(WebIcon);
        WebIcon.setBounds(0, 0, 160, 70);

        WebText.setBackground(new java.awt.Color(51, 51, 51));
        WebText.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        WebText.setForeground(new java.awt.Color(236, 240, 241));
        WebText.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        WebText.setText("  Employees");
        WebText.setToolTipText("");
        WebText.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        WebText.setPreferredSize(new java.awt.Dimension(46, 40));
        Web.add(WebText);
        WebText.setBounds(0, 120, 160, 40);

        getContentPane().add(Web);
        Web.setBounds(750, 480, 160, 160);

        EBook.setLayout(null);

        EBookIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        EBookIcon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        EBook.add(EBookIcon);
        EBookIcon.setBounds(0, 0, 160, 70);

        EBookText.setBackground(new java.awt.Color(51, 51, 51));
        EBookText.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        EBookText.setForeground(new java.awt.Color(236, 240, 241));
        EBookText.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        EBookText.setText("  Employees");
        EBookText.setToolTipText("");
        EBookText.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        EBookText.setPreferredSize(new java.awt.Dimension(46, 40));
        EBook.add(EBookText);
        EBookText.setBounds(0, 120, 160, 40);

        getContentPane().add(EBook);
        EBook.setBounds(10, 300, 160, 160);

        showQuote.setBackground(new java.awt.Color(255, 51, 51));
        showQuote.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        showQuote.setForeground(new java.awt.Color(255, 255, 255));
        showQuote.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        showQuote.setText("\"If information is the currency of democracy, then libraries are its banks.\"");
        showQuote.setToolTipText("Public Library, Gampaha");
        showQuote.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        showQuote.setMaximumSize(new java.awt.Dimension(450, 200));
        showQuote.setMinimumSize(new java.awt.Dimension(450, 200));
        showQuote.setPreferredSize(new java.awt.Dimension(450, 200));
        getContentPane().add(showQuote);
        showQuote.setBounds(390, 144, 450, 200);

        QuoteOfTheDay.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        QuoteOfTheDay.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(QuoteOfTheDay);
        QuoteOfTheDay.setBounds(214, 100, 770, 540);

        icon1.setBackground(new java.awt.Color(102, 0, 102));
        icon1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/logo.png"))); // NOI18N
        icon1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                icon1MouseClicked(evt);
            }
        });
        getContentPane().add(icon1);
        icon1.setBounds(10, 0, 40, 50);

        icon.setBackground(new java.awt.Color(102, 0, 102));
        icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icon.png"))); // NOI18N
        icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iconMouseClicked(evt);
            }
        });
        getContentPane().add(icon);
        icon.setBounds(10, 10, 80, 80);

        jLabel13.setBackground(new java.awt.Color(52, 73, 94));
        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(52, 73, 94));
        jLabel13.setText("Public Library, Gampaha.");
        getContentPane().add(jLabel13);
        jLabel13.setBounds(850, 640, 160, 30);

        swiral.setBackground(new java.awt.Color(204, 204, 0));
        swiral.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        swiral.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        getContentPane().add(swiral);
        swiral.setBounds(0, 0, 1000, 700);

        wallpaper.setBackground(new java.awt.Color(51, 204, 0));
        wallpaper.setOpaque(true);
        getContentPane().add(wallpaper);
        wallpaper.setBounds(0, 0, 1000, 700);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void iconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iconMouseClicked
        // TODO add your handling code here:
        settings.grabFocus();
    }//GEN-LAST:event_iconMouseClicked

    private void icon1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_icon1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_icon1MouseClicked

    private void backspaceMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backspaceMouseClicked
        // TODO add your handling code here:

      //  int count = evt.getClickCount();
      //  if(evt.getButton()==1 && count == 1){
            int i =searchText.getCaretPosition();
            String s = searchText.getText();
            final StringBuilder x = new StringBuilder(s);
            if(i<=0 || i>s.length()){
                i = s.length();
            }
            if(i>0) {
                x.deleteCharAt(i-1);
                searchText.setText(x.toString());
                searchText.grabFocus();
                searchText.setCaretPosition(i-1);
                backspace.setFocusPainted(true);
            }
      //  }
    }//GEN-LAST:event_backspaceMouseClicked
    private boolean clear = true;
    private void searchTextMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchTextMouseClicked
        // TODO add your handling code here:
        int count = evt.getClickCount();
            if(evt.getButton()==1 && count == 1){
                if(clear) {
                searchText.setText("");
                clear =false;
            }
        }
    }//GEN-LAST:event_searchTextMouseClicked
    private Executor Executor;// = Executors.newSingleThreadExecutor();
    private void show(final JPanel panel) {
        Executor = Executors.newSingleThreadExecutor();
        Runnable begin = new Runnable() {
            @Override
            public void run() {
                closeButton.setEnabled(false);
                notificationsButton.setEnabled(false);
                messagesButton.setEnabled(false);
                profileButton.setEnabled(false);
                helpButton.setEnabled(false);
                settingsButton.setEnabled(false);
                settings.setEnabled(false);
                closeButton.setBackground(UserHandler.concrete);
                notificationsButton.setBackground(UserHandler.concrete);
                messagesButton.setBackground(UserHandler.concrete);
                profileButton.setBackground(UserHandler.concrete);
                helpButton.setBackground(UserHandler.concrete);
                settingsButton.setBackground(UserHandler.concrete);
            }
        };
        
        Runnable end = new Runnable() {
                    @Override
                    public void run() {
                            closeButton.setEnabled(true);
                            closeButton.setBackground(UserHandler.wetAsphalt);
                        if(!userIsAGuest) {
                            notificationsButton.setEnabled(true);
                            messagesButton.setEnabled(true);
                            profileButton.setEnabled(true);
                            helpButton.setEnabled(true);
                            settingsButton.setEnabled(true);
                            settings.setEnabled(true);
                            notificationsButton.setBackground(UserHandler.wetAsphalt);
                            messagesButton.setBackground(UserHandler.wetAsphalt);
                            profileButton.setBackground(UserHandler.wetAsphalt);
                            helpButton.setBackground(UserHandler.wetAsphalt);
                            settingsButton.setBackground(UserHandler.wetAsphalt);
                        }
                    }
        };
        
        Runnable wait = new Runnable() {
                    @Override
                    public void run() {
                        try {
                           Thread.sleep(2000);
                        } catch (InterruptedException ex) {}
                    }
        };
        
        if(formVisible){
            if (currentPanel != panel) {
                final Rectangle panelFrom = new Rectangle(890,10, 0, 500);
                final Rectangle panelTo = new Rectangle(10, 10, 880, 500);
                settings.setEnabled(false);
                Runnable first = new Runnable() {
                    @Override
                    public void run() {
                        Animate animateCurrent = new Animate(currentPanel, panelTo, panelFrom);
                        animateCurrent.start();
                    }
                };

                Runnable third = new Runnable() {
                    @Override
                    public void run() {
                        panel.setVisible(true);
                        Animate animate = new Animate(panel, panelFrom, panelTo);
                        animate.start();
                        currentPanel = panel;
                    }
                };
                Executor.execute(begin);
                Executor.execute(first);
                Executor.execute(wait);
                Executor.execute(third);
                Executor.execute(wait);
                Executor.execute(end);
                settings.setEnabled(true);
                formVisible =true;
            }

            } else {
                SignInPanel.setVisible(false);
                ProfilePanel.setVisible(false);
                MessagesPanel.setVisible(false);
                HelpPanel.setVisible(false);
                SettingsPanel.setVisible(false);
                SearchPanel.setVisible(false);
                QuotePanel.setVisible(false);
                NotificationsPanel.setVisible(false);
                form.setBounds(new Rectangle(1000,120, 0, 520));
                panel.setBounds(890, 10, 0, 500);
                form.setVisible(true);
                panel.setVisible(true);
                final Rectangle formFrom = new Rectangle(1000,120, 0, 520);
                final Rectangle formTo = new Rectangle(0, 120, 1000, 520);
                final Rectangle panelFrom = new Rectangle(890,10, 0, 500);
                final Rectangle panelTo = new Rectangle(10, 10, 880, 500);
                settings.setEnabled(false);
                Runnable first = new Runnable() {
                    @Override
                    public void run() {

                        Animate animateForm = new Animate(form, formFrom, formTo);
                        animateForm.start();
                        Animate animatePanel = new Animate(panel, panelFrom, panelTo);
                        animatePanel.start();
                    }
                };
                Executor.execute(begin);
                Executor.execute(first);
                Executor.execute(wait);
                Executor.execute(end);
                settings.setEnabled(true);
                formVisible =true;
                currentPanel = panel;
        }


        
    }
    
    private JPanel currentPanel = null;
    
    private void hideForm() {
        formVisible =false;
        settings.setEnabled(false);
        Runnable first = new Runnable() {
            @Override
            public void run() {
                Rectangle from = new Rectangle(0, 120, 1000, 520);
                Rectangle to = new Rectangle(1000,120, 0, 520);
                Animate animate = new Animate(form,from, to);
                animate.start();   
            }
        };
        Executor.execute(first);
        settings.setEnabled(true);
    }

    private void settingsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_settingsMouseClicked
        // TODO add your handling code here:
   //     int count = evt.getClickCount();
    //    if(evt.getButton()==1 && count == 1){
           
          /*  if(!signInForm){
                //this.repaint();
                showPanel(PanelSet.SignIn);
                form.setBounds(new Rectangle(1000,120, 0, 520));
                form.setVisible(true);
                Rectangle from = new Rectangle(1000,120, 0, 520);
                Rectangle to = new Rectangle(0, 120, 1000, 520);
                Animate animate = new Animate(form, from, to);
                animate.start();
                signInForm =true;
            } else {
                Rectangle from = new Rectangle(0, 120, 1000, 520);
                Rectangle to = new Rectangle(1000,120, 0, 520);
                Animate animate = new Animate(form, from, to);
                animate.start();
               // form.setVisible(false);
                signInForm =false;
            }
        } else if(evt.getButton()==3 && count == 1){
            //popup right click
            //  signin
            //  signout
            //  profile
            //  manage main
            //  help
            //--writing language
            //  use sinhala
            //  use english
            //--icon layout
            //  default
            //  tight
            //  preffered
            */
    //    }
    }//GEN-LAST:event_settingsMouseClicked

    private void usernameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usernameMouseClicked
        // TODO add your handling code here:
        int count = evt.getClickCount();
        if(evt.getButton()==1 && count == 1){
            //view profile
        }
    }//GEN-LAST:event_usernameMouseClicked

    private void userImageMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_userImageMouseClicked
        // TODO add your handling code here:
        int count = evt.getClickCount();
        if(evt.getButton()==1 && count == 1){
            //view popup
            //    - capture image
            //    - change image            
        }
    }//GEN-LAST:event_userImageMouseClicked

    private void searchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchMouseClicked
        // TODO add your handling code here:
        //SELECT * FROM TABLE_NAME WHERE FIELD=BINARY('VALUE TO BE COMPARED');

        /*
        SwingUtilities.updateComponentTreeUI(frame);

        If it still doesn't work then after completing the above step try

        frame.invalidate();
        frame.validate();
        frame.repaint();
        
        */
        int count = evt.getClickCount();
        if(evt.getButton()==1 && count == 1){
            //view popup
            //    - capture image
            //    - change image            
        }
    }//GEN-LAST:event_searchMouseClicked

    private void settingsButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_settingsButtonMouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_settingsButtonMouseClicked

    private void settingsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_settingsButtonActionPerformed
        // TODO add your handling code here:
                show(SettingsPanel);
        settingsButton.grabFocus();
    }//GEN-LAST:event_settingsButtonActionPerformed

    private void profileButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_profileButtonMouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_profileButtonMouseClicked

    private void profileButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_profileButtonActionPerformed
        // TODO add your handling code here:
                show(ProfilePanel);
        profileButton.grabFocus();
    }//GEN-LAST:event_profileButtonActionPerformed

    private void notificationsButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_notificationsButtonMouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_notificationsButtonMouseClicked

    private void notificationsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_notificationsButtonActionPerformed
        // TODO add your handling code here:
                show(NotificationsPanel);
        notificationsButton.grabFocus();
    }//GEN-LAST:event_notificationsButtonActionPerformed

    private void helpButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_helpButtonMouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_helpButtonMouseClicked

    private void helpButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_helpButtonActionPerformed
        // TODO add your handling code here:
                show(HelpPanel);
        helpButton.grabFocus();
    }//GEN-LAST:event_helpButtonActionPerformed

    private void messagesButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_messagesButtonMouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_messagesButtonMouseClicked

    private void messagesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_messagesButtonActionPerformed
        // TODO add your handling code here:
                show(MessagesPanel);
        messagesButton.grabFocus();
    }//GEN-LAST:event_messagesButtonActionPerformed

    private void closeButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeButtonMouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_closeButtonMouseClicked

    private void closeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeButtonActionPerformed
        // TODO add your handling code here:
        hideForm();
        /*
        Employee.setVisible(true);
        Book.setVisible(true);
        EBook.setVisible(true);
        DVD.setVisible(true);
        Message.setVisible(true);
        //Reference.setVisible(true);
        //Archive.setVisible(true);
        Patron.setVisible(true);
        Setting.setVisible(true);
        Web.setVisible(true);
        //Report.setVisible(true);
        Circulation.setVisible(true);
        Catalogue.setVisible(true);
        Queue.setVisible(true);
        Acqusition.setVisible(true);
        */
    }//GEN-LAST:event_closeButtonActionPerformed

    private void settingsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_settingsActionPerformed
        // TODO add your handling code here:
        show(SignInPanel);
        /*
        Employee.setVisible(false);
        Book.setVisible(false);
        EBook.setVisible(false);
        DVD.setVisible(false);
        Message.setVisible(false);
        //Reference.setVisible(false);
        //Archive.setVisible(false);
        Patron.setVisible(false);
        Setting.setVisible(false);
        Web.setVisible(false);
        //Report.setVisible(false);
        Circulation.setVisible(false);
        Catalogue.setVisible(false);
        Queue.setVisible(false);
        Acqusition.setVisible(false);
        */
    }//GEN-LAST:event_settingsActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Front.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Front.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Front.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Front.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Front().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Acqusition;
    private javax.swing.JLabel AcqusitionIcon;
    private javax.swing.JLabel AcqusitionText;
    private javax.swing.JPanel Archive;
    private javax.swing.JLabel ArchiveIcon;
    private javax.swing.JLabel ArchiveText;
    private javax.swing.JPanel Backup;
    private javax.swing.JPanel Book;
    private javax.swing.JLabel BookIcon;
    private javax.swing.JLabel BookText;
    private javax.swing.JPanel Catalogue;
    private javax.swing.JLabel CatalogueIcon;
    private javax.swing.JLabel CatalogueText;
    private javax.swing.JPanel Circulation;
    private javax.swing.JLabel CirculationIcon;
    private javax.swing.JLabel CirculationText;
    private javax.swing.JPanel DVD;
    private javax.swing.JLabel DVDIcon;
    private javax.swing.JLabel DVDText;
    private javax.swing.JPanel EBook;
    private javax.swing.JLabel EBookIcon;
    private javax.swing.JLabel EBookText;
    private javax.swing.JPanel Employee;
    private javax.swing.JLabel EmployeeIcon;
    private javax.swing.JLabel EmployeeText;
    private javax.swing.JPanel Message;
    private javax.swing.JLabel MessageIcon;
    private javax.swing.JLabel MessageText;
    private javax.swing.JLabel Notify;
    private javax.swing.JPanel Patron;
    private javax.swing.JLabel PatronIcon;
    private javax.swing.JLabel PatronText;
    private javax.swing.JPanel Queue;
    private javax.swing.JLabel QueueIcon;
    private javax.swing.JLabel QueueText;
    private javax.swing.JLabel QuoteOfTheDay;
    private javax.swing.JPanel Reference;
    private javax.swing.JLabel ReferenceIcon;
    private javax.swing.JLabel ReferenceText;
    private javax.swing.JPanel Report;
    private javax.swing.JLabel ReportIcon;
    private javax.swing.JLabel ReportText;
    private javax.swing.JPanel Setting;
    private javax.swing.JLabel SettingIcon;
    private javax.swing.JLabel SettingText;
    private javax.swing.JPanel Web;
    private javax.swing.JLabel WebIcon;
    private javax.swing.JLabel WebText;
    private javax.swing.JButton backspace;
    public static final javax.swing.JToggleButton changeLanguage = new javax.swing.JToggleButton();
    private javax.swing.JButton closeButton;
    private javax.swing.JPanel form;
    private javax.swing.JLabel formSwiral;
    private javax.swing.JLabel formWallpaper;
    private javax.swing.JButton helpButton;
    private javax.swing.JLabel icon;
    private javax.swing.JLabel icon1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel languagePanel;
    private javax.swing.JButton messagesButton;
    private javax.swing.JButton notificationsButton;
    private javax.swing.JButton profileButton;
    private javax.swing.JPanel profilePanel;
    private javax.swing.JButton search;
    private javax.swing.JPanel searchPanel;
    private javax.swing.JTextField searchText;
    private javax.swing.JButton settings;
    private javax.swing.JButton settingsButton;
    private javax.swing.JLabel showQuote;
    private javax.swing.JLabel swiral;
    private javax.swing.JLabel userImage;
    private javax.swing.JLabel username;
    private javax.swing.JLabel wallpaper;
    // End of variables declaration//GEN-END:variables
}
