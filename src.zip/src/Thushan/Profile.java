/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Thushan;

import MySQL.MySQLMethods;
import org.bytedeco.javacpp.opencv_core;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.LuminanceSource;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.NotFoundException;
import com.google.zxing.Result;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.border.LineBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.bytedeco.javacv.FrameGrabber;
import org.bytedeco.javacv.OpenCVFrameGrabber;


/**
 *
 * @author Design
 */
public class Profile extends javax.swing.JPanel {

    /**
     * Creates new form SignIn
     */
    private List<String> data = null;
    private String index = null;
    public Profile() {
        initComponents();
  
        try{
             data = SignIn.answer;
  
             System.out.println(data.get(13)+" | "+data.get(14));
        }catch (Exception e){}
        
                try{
        index = MySQLMethods.getResultCell("SELECT `employee`.`EmployeeIndex` FROM `library`.`employee` where EmployeeId = "+data.get(0)+" ORDER BY EmployeeId DESC LIMIT 1;");    
        }catch(Exception e){}
        
        tabPane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI(){  
            @Override
            protected void paintContentBorder(Graphics g,int tabPlacement,int selectedIndex){
                getTopLevelAncestor().revalidate();
                getTopLevelAncestor().repaint();
            }  
 
        });
        tabPane.setBackground(new Color(52,73,94,50));
        
        
            tabPane.addChangeListener(new ChangeListener() {
        @Override
        public void stateChanged(ChangeEvent changeEvent) {
                int index = tabPane.getSelectedIndex();
              //System.out.println("Tab changed to: " + tabPane.getTitleAt(index));
                if(index == 0){
                            try{
             data = SignIn.answer;
  
                 EmployeeId = data.get(0);
   FullnameInEnglish = data.get(1);
   FullnameInSinhala = data.get(2);
  sex_male = data.get(3);
   sex_female = data.get(4);
    DateOfBirth = data.get(5);
    Password = data.get(6);
     NIC = data.get(7);
    MaritalStatus = data.get(8);
    Spouse = data.get(9);
   Salutation = data.get(10);
   PersonalMobilePhone = data.get(11);
  MailAccount = data.get(12);
UserNameEnglish = data.get(13);
    UserNameSinhala = data.get(14);
   Personaladdress = data.get(15);
    City = data.get(16);
   Hometown = data.get(17);
    ZipCode = data.get(18);
                 reset();
        }catch (Exception e){}
                            
                            
                }
            }
        });
    }
    public void reset(){
                   try{
             data = SignIn.answer;
        }catch (Exception e){}
                               try{
        index = MySQLMethods.getResultCell("SELECT `employee`.`EmployeeIndex` FROM `library`.`employee` where EmployeeId = "+data.get(0)+" ORDER BY EmployeeId DESC LIMIT 1;");    
        System.out.println("----------"+index);
                               }catch(Exception e){}
                               
    jTextField11.setText(UserNameEnglish +" | "+UserNameSinhala);
    jTextField15.setText(UserNameEnglish);
    jTextField16.setText(UserNameSinhala);
    jTextField30.setText(DateOfBirth);
    jTextField18.setText(NIC);
    jTextField23.setText(PersonalMobilePhone);
    jTextField22.setText(Hometown);
    jTextField21.setText(MailAccount);
    jTextField20.setText(ZipCode);
    jTextField24.setText(City);
    jTextField25.setText(Hometown);
    
    }
    public String EmployeeId;
    public String FullnameInEnglish;
    public String FullnameInSinhala;
    public String sex_male;
    public String sex_female;
    public String DateOfBirth;
    public String Password;
    public String NIC;
    public String MaritalStatus;
    public String Spouse;
    public String Salutation;
    public String PersonalMobilePhone;
    public String MailAccount;
    public String UserNameEnglish;
    public String UserNameSinhala;
    public String Personaladdress;
    public String City;
    public String Hometown;
    public String ZipCode;

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        tabPane = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        jTextField11 = new javax.swing.JTextField();
        jTextField15 = new javax.swing.JTextField();
        jTextField16 = new javax.swing.JTextField();
        jTextField18 = new javax.swing.JTextField();
        jTextField20 = new javax.swing.JTextField();
        jTextField21 = new javax.swing.JTextField();
        jTextField22 = new javax.swing.JTextField();
        jTextField23 = new javax.swing.JTextField();
        jTextField24 = new javax.swing.JTextField();
        jTextField25 = new javax.swing.JTextField();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jTextField30 = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jPasswordField6 = new javax.swing.JPasswordField();
        jPasswordField5 = new javax.swing.JPasswordField();
        jPasswordField4 = new javax.swing.JPasswordField();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();

        setMaximumSize(new java.awt.Dimension(935, 500));
        setMinimumSize(new java.awt.Dimension(935, 500));
        setPreferredSize(new java.awt.Dimension(935, 500));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Sakkal Majalla", 1, 36)); // NOI18N
        jLabel3.setText("PROFILE");
        add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 260, -1));

        tabPane.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        tabPane.setToolTipText("");
        tabPane.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        tabPane.setFont(new java.awt.Font("Sakkal Majalla", 0, 24)); // NOI18N
        tabPane.setMinimumSize(new java.awt.Dimension(967, 676));
        tabPane.setPreferredSize(new java.awt.Dimension(1015, 675));

        jPanel3.setBackground(new java.awt.Color(0, 231, 166));
        jPanel3.setFont(new java.awt.Font("Sakkal Majalla", 0, 24)); // NOI18N
        jPanel3.setOpaque(false);
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextField11.setEditable(false);
        jTextField11.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jTextField11.setText(" ");
        jPanel3.add(jTextField11, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 10, 510, 35));

        jTextField15.setEditable(false);
        jTextField15.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jTextField15.setText(" ");
        jPanel3.add(jTextField15, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 50, 510, 35));

        jTextField16.setEditable(false);
        jTextField16.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jPanel3.add(jTextField16, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 90, 510, 35));

        jTextField18.setEditable(false);
        jTextField18.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jPanel3.add(jTextField18, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 180, 180, 35));

        jTextField20.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jPanel3.add(jTextField20, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 220, 180, 35));

        jTextField21.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jPanel3.add(jTextField21, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 180, 180, 35));

        jTextField22.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jPanel3.add(jTextField22, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 140, 180, 35));

        jTextField23.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jPanel3.add(jTextField23, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 260, 180, 35));

        jTextField24.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jPanel3.add(jTextField24, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 220, 180, 35));

        jTextField25.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jTextField25.setToolTipText("");
        jPanel3.add(jTextField25, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 260, 180, 35));

        jLabel36.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel36.setText("Hometown");
        jPanel3.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 270, -1, -1));

        jLabel37.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel37.setText("City");
        jPanel3.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 230, -1, -1));

        jLabel39.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel39.setText("Zip Code");
        jPanel3.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 220, -1, -1));

        jLabel25.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel25.setText("Email Address ");
        jPanel3.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 190, -1, -1));

        jLabel40.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel40.setText("Home No.");
        jPanel3.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 150, -1, -1));

        jLabel41.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel41.setText("Mobile No.");
        jPanel3.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 270, -1, -1));

        jLabel44.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel44.setText("NIC");
        jPanel3.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 190, -1, -1));

        jLabel15.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel15.setText("Date Of Birth");
        jPanel3.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, -1, -1));

        jLabel46.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel46.setText("Full Name In Sinhala");
        jPanel3.add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, -1));

        jLabel47.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel47.setText("Full Name In English");
        jPanel3.add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, -1, -1));

        jLabel48.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel48.setText("User Name");
        jPanel3.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, -1, -1));

        jButton11.setBackground(new java.awt.Color(0, 0, 0));
        jButton11.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        jButton11.setForeground(new java.awt.Color(255, 255, 255));
        jButton11.setText("SAVE");
        jButton11.setContentAreaFilled(false);
        jButton11.setOpaque(true);
        jPanel3.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 90, 133, 35));

        jButton12.setBackground(new java.awt.Color(0, 0, 0));
        jButton12.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        jButton12.setForeground(new java.awt.Color(255, 255, 255));
        jButton12.setText("REFRESH");
        jButton12.setContentAreaFilled(false);
        jButton12.setOpaque(true);
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 50, 133, 35));

        jTextField30.setEditable(false);
        jTextField30.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jPanel3.add(jTextField30, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 140, 180, 35));

        tabPane.addTab("<html><body width='150'>Change</body></html>", jPanel3);

        jPanel6.setBackground(new java.awt.Color(0, 231, 166));
        jPanel6.setFont(new java.awt.Font("Sakkal Majalla", 0, 24)); // NOI18N
        jPanel6.setOpaque(false);
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel29.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel29.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jPanel6.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 180, 50, 50));

        jLabel30.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel30.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jPanel6.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 110, 50, 50));

        jLabel31.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel31.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jPanel6.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 250, 50, 50));

        jButton4.setBackground(new java.awt.Color(0, 0, 0));
        jButton4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("CLEAR");
        jButton4.setContentAreaFilled(false);
        jButton4.setOpaque(true);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel6.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 230, 120, 35));

        jButton5.setBackground(new java.awt.Color(0, 0, 0));
        jButton5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("CHANGE PASSWORD");
        jButton5.setContentAreaFilled(false);
        jButton5.setOpaque(true);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel6.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 230, 170, 35));

        jPasswordField6.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jPasswordField6.setEchoChar('\u2022');
        jPasswordField6.setFocusAccelerator('\u2022');
        jPasswordField6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasswordField6ActionPerformed(evt);
            }
        });
        jPanel6.add(jPasswordField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 160, 239, 50));

        jPasswordField5.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jPasswordField5.setEchoChar('\u2022');
        jPasswordField5.setFocusAccelerator('\u2022');
        jPasswordField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasswordField5ActionPerformed(evt);
            }
        });
        jPasswordField5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jPasswordField5KeyTyped(evt);
            }
        });
        jPanel6.add(jPasswordField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 90, 239, 50));

        jPasswordField4.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jPasswordField4.setEchoChar('\u2022');
        jPasswordField4.setFocusAccelerator('\u2022');
        jPanel6.add(jPasswordField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 20, 239, 50));

        jLabel26.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel26.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel26.setText("Old Password");
        jPanel6.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 200, 50));

        jLabel27.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel27.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel27.setText("New Password");
        jPanel6.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 200, 50));

        jLabel28.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel28.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel28.setText("Confirm New Password");
        jPanel6.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 200, 50));

        tabPane.addTab("<html><body width='150'>Change Password</body></html>", jPanel6);

        add(tabPane, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 860, 440));
    }// </editor-fold>//GEN-END:initComponents

    private void jPasswordField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasswordField6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jPasswordField6ActionPerformed
private  File imageFile=null;    private static final String USERNAME_PATTERN = "^[a-z0-9_-]{3,15}$";
    private static final String PASSWORD_PATTERN = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";
    boolean passwordIsValid = false;
    boolean userNameIsValid = false;
    Pattern pattern;
    Matcher matcher;
    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        // jPasswordField4 jPasswordField5 jPasswordField6
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(new String (jPasswordField5.getPassword()));
        passwordIsValid = matcher.matches();
        if(passwordIsValid) {
           
         String[] columns1c = new String[]{"EmployeeId" ,"FullnameInEnglish" ,"FullnameInSinhala","sex_male","sex_female","DateOfBirth","Password","NIC", "MaritalStatus","Spouse","Salutation","PersonalMobilePhone","MailAccount","UserNameEnglish","UserNameSinhala","Personaladdress","City","Hometown","ZipCode"} ;       
        
                try{
             data = SignIn.answer;
        }catch (Exception e){}
                               try{
        index = MySQLMethods.getResultCell("SELECT `employee`.`EmployeeIndex` FROM `library`.`employee` where EmployeeId = "+data.get(0)+" ORDER BY EmployeeId DESC LIMIT 1;");    
        System.out.println("----------"+index);
                               }catch(Exception e){}
                
        if(new String (jPasswordField4.getPassword()).equals(data.get(6))){
            if(new String (jPasswordField5.getPassword()).equals(new String (jPasswordField6.getPassword()))){
                
                MySQL.MySQLMethods.curd(MySQL.MySQLMethods.update("library", "employee", "EmployeeIndex", index, "Password", new String (jPasswordField5.getPassword())));
             JOptionPane.showConfirmDialog(this,"Password Successfully changed", "Password Changed", JOptionPane.PLAIN_MESSAGE);
            } else {
            JOptionPane.showConfirmDialog(this,"Confirm Password to ensure safty", "Password Confirmation Error", JOptionPane.PLAIN_MESSAGE);
            }
        } else {
          JOptionPane.showConfirmDialog(this,"Please fill all the fields with correct information", "Current Password Incorrect", JOptionPane.PLAIN_MESSAGE);
        }
            
        } else {
            JOptionPane.showConfirmDialog(this,"Invalid Password", "Password Change Error", JOptionPane.PLAIN_MESSAGE);
        } 
        
        
        
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        jPasswordField4.setText(""); 
        jPasswordField5.setText(""); 
        jPasswordField6.setText(""); 
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jPasswordField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasswordField5ActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_jPasswordField5ActionPerformed

    private void jPasswordField5KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jPasswordField5KeyTyped
        // TODO add your handling code here:
                        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(new String(jPasswordField5.getPassword()));
        passwordIsValid = matcher.matches();
        if(passwordIsValid) {
            jPasswordField5.setBorder(null);
            
        } else {
            jPasswordField5.setBorder(new LineBorder(Color.decode("#c0392b")));
        } 
    }//GEN-LAST:event_jPasswordField5KeyTyped

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        // TODO add your handling code here:
        reset();
    }//GEN-LAST:event_jButton12ActionPerformed
    class CamThread extends Thread {
        private boolean end = false;
        private boolean cancel = false;
        private boolean barcode = false;
        private OpenCVFrameGrabber grabber;
        final private JLabel showLabel;
        final private int camera;
        final private int colorType;
        final private int width;
        final private int height;
        
        private opencv_core.IplImage grabbedImage; 
        
        public CamThread(JLabel showLabel,int camera,int colorType){
            this.showLabel = showLabel;
            this.camera = (camera<0 && camera>1)?0:camera;
            this.colorType = (colorType<0 && colorType>1)?1:colorType;
            this.width = (this.showLabel.getWidth()<320)?this.showLabel.getWidth():320;
            this.height = (this.showLabel.getHeight()<240)?this.showLabel.getHeight():240;
        }

        @Override
        public void run() {
                Tn :  while (true) {
                    try {  
                       grabber = new OpenCVFrameGrabber(this.camera);//camera 0
                       grabber.setImageMode(FrameGrabber.ImageMode.COLOR);
                       grabber.setImageWidth(this.width);
                       grabber.setImageHeight(this.showLabel.getHeight());
                       grabber.setFrameRate(grabber.getFrameRate());
                       grabber.start();   

                       while ((grabbedImage = grabber.grab()) != null) {  
                           
                            BufferedImage buf = new BufferedImage(320,240, this.colorType); // last arg (1) is the same as TYPE_INT_RGB
                            buf.getGraphics().drawImage(grabbedImage.getBufferedImage(),0,0,null);
                          
                           
                            ImageIcon icon = new ImageIcon(buf);
                            showLabel.setIcon(icon);

                            if(barcode){
                                LuminanceSource source = new BufferedImageLuminanceSource(grabbedImage.getBufferedImage());
                                BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));    
                                Result result;

                               try {
                                    result = new MultiFormatReader().decode(bitmap);
                                   // System.out.println("read -"+result.getText());
                                    //temp.add(result.getText());
                                    /*
                                    
                                    String cell 
                                    
                                    
                                    
                                    
                                    */
         
                                    
                                    
                                } catch (NotFoundException e) {}
          
                            }
                            
                           if(end){
                               if(cancel){
                                   showLabel.setIcon(tempStoreImage);
                               }
                               break;
                           }
                       }    
                       grabber.stop();  
                   } catch (FrameGrabber.Exception e) {
                   } finally {
                       try {
                           grabber.stop(); 
                       } catch (FrameGrabber.Exception e) {}
                   }
                    break;
                }
        }

        public synchronized void capture() {
            end = true;
            cancel = false;
            barcode = false;
            notify();   
        }
        
        public synchronized void cancel() {
            end = true;
            cancel = true;
            barcode = false;
            notify();   
        }
        
        public synchronized void readBarcode() {
            end = false;
            cancel = false;
            barcode = true;
            notify();   
        }
    }
        private static ExecutorService updateUIExecutor;
    private static ExecutorService readFromDatabaseExecutor;
               private static ExecutorService executor;
    private CamThread camThread;
    private Icon tempStoreImage;  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPasswordField jPasswordField4;
    private javax.swing.JPasswordField jPasswordField5;
    private javax.swing.JPasswordField jPasswordField6;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField16;
    private javax.swing.JTextField jTextField18;
    private javax.swing.JTextField jTextField20;
    private javax.swing.JTextField jTextField21;
    private javax.swing.JTextField jTextField22;
    private javax.swing.JTextField jTextField23;
    private javax.swing.JTextField jTextField24;
    private javax.swing.JTextField jTextField25;
    private javax.swing.JTextField jTextField30;
    private javax.swing.JTabbedPane tabPane;
    // End of variables declaration//GEN-END:variables
}
