/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Thushan;

import java.awt.Component;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import javax.swing.JComponent;

/**
 *
 * @author Design
 */
public class ResizeHandler implements MouseWheelListener {

    @Override
    public void mouseWheelMoved(MouseWheelEvent e) {
        JComponent child/*comp*/ = (JComponent) e.getComponent();
      //  Component child = comp.findComponentAt(e.getPoint());
        
        if (e.getScrollType() == MouseWheelEvent.WHEEL_UNIT_SCROLL) {
            int amount = e.getWheelRotation() * 5;
            if((child.getSize().width + amount<=child.getMaximumSize().width) && (child.getSize().height + amount<=child.getMaximumSize().height)) {
                if((child.getSize().width + amount>=child.getMinimumSize().width) && (child.getSize().height + amount>=child.getMinimumSize().height)) {  
                    if (!e.isControlDown() && !e.isAltDown()) {
                        child.setBounds(child.getX(), child.getY(), child.getWidth()+ amount, child.getHeight()+ amount);
                    }
                }
                if((child.getSize().width + amount>=child.getMinimumSize().width)) {  
                    if (e.isControlDown()) {
                        child.setBounds(child.getX(), child.getY(), child.getWidth()+ amount, child.getHeight());
                    }
                }
                if((child.getSize().height + amount>=child.getMinimumSize().height)) {  
                    if (e.isAltDown()) {
                        child.setBounds(child.getX(), child.getY(), child.getWidth(), child.getHeight()+ amount);
                    }
                }
            }
        }
    }
}
