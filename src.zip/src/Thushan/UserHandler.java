/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Thushan;

import java.awt.Color;

/**
 *
 * @author Design
 */
public class UserHandler {
    //green
    public static Color turquoise = Color.decode("#1abc9c");
    public static Color emerald = Color.decode("#2ecc71");
    public static Color greenSea = Color.decode("#16a085");
    public static Color nephritis = Color.decode("#27ae60");
    //white
    public static Color clouds = Color.decode("#ecf0f1");
    public static Color concrete = Color.decode("#95a5a6");
    public static Color silver = Color.decode("#bdc3c7");
    public static Color asbestos = Color.decode("#7f8c8d");
    //orange
    public static Color orange = Color.decode("#f39c12");
    public static Color sunFlower = Color.decode("#f1c40f");
    public static Color carrot = Color.decode("#e67e22");
    public static Color pumpkin = Color.decode("#d35400");
    //blue
    public static Color peterRiver = Color.decode("#3498db");
    public static Color belizeHole = Color.decode("#2980b9");
    //purple
    public static Color amethyst = Color.decode("#9b59b6");
    public static Color wisteria = Color.decode("#8e44ad");
    //red
    public static Color alizarin = Color.decode("#e74c3c");
    public static Color pomegranate = Color.decode("#c0392b");
    //gray
    public static Color wetAsphalt = Color.decode("#34495e");
    public static Color midNightBlue = Color.decode("#2c3e50");
    
    public static final Thushan.Front mainInterface = new Thushan.Front();
    //public static final Thushan.Splash mainInterface = new Thushan.Splash();
    
    public static String setToolTip(String englishToolTip, String sinhalaToolTip){
        String html = "<html><p>" +
        "<font color=\"#27ae60\" size=\"2\" face=\"Segoe UI\">" + englishToolTip + 
        "<br>"+
        "<font color=\"#3498db\" size=\"3\" face=\"Iskoola pota\">" + sinhalaToolTip +
        "</font></p></html>";
        return html;
    }
}