/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Thushan;

import java.awt.Color;
import javax.swing.ImageIcon;

/**
 *
 * @author Design
 */

public class Employee {

    private int EmployeeId;

    private String MailAccount;
    private String PhoneNumber;
    private String UserName;

    private String Password;
    private String KeyForMail;
    private String KeyForSMS;

    private int SuccessedCount;
    private int FailedCount;
    private int AttaemptsFailedCount;

    private boolean AccessState; //admin
    private boolean AccountState; //user

    private String BlockedReason;
    private String BlockedFrom;
    private String Blockedtill;
 
    private String DateCreated;
    private String LastAccessed;

    //**************************************
    private boolean Gender;
     
    private String FullnameInEnglish;
    private String FullnameInSinhala;
    private String FullnameInOther;
    
    private String DateOfBirth;
    private String MaritalStatus; //Single|Married|Divorced|Separated|In a relationship|Engaged|Widowed|In an open relationship|It`s complicated
    private String Spouse;
    private String Salutation;
    private String NIC;
    
    private String PersonalMobilePhone;
    private String PersonalHomePhone;
    private String Personalemail;
    private String Personaladdress;
    private String City;
    private String Hometown;
    private String ZipCode;
    
    private boolean IsAvailable;
    private boolean ProfileIsPrivate;
    
    //**************************************
    
    private String OfficeEMail;
    private String OfficePhone;
    private String OfficeFax;
    
    private String EmergencyContactPhone;
    private String EmergencyContactName;
    private String EmergencyContactAddress;
    
    private Color BackgroundColor;
    private ImageIcon BackgroundImage;
    private Color BackgroundBorderColor;

    private boolean UILanguageIsEnglish;
    
   // 15 bounds no color
    // count message types
    private int[] BooksBounds;
    private int[] AcquisitionsBounds;
    private int[] EmployeesBounds;
    
    private int[] QueuesBounds;
    private int[] EBooksBounds;
    private int[] SettingsBounds;
    
    private int[] PatronsBounds;
    private int[] CataloguesBound;
    private int[] DVDsBounds;
    
    private int[] MessagesBounds;
    private int[] WebBounds;
    private int[] CriculationsBounds;
    
    private int[] BooksColor;
    private int[] AcquisitionsColor;
    private int[] EmployeesColor;
    
    private int[] QueuesColor;
    private int[] EBooksColor;
    private int[] SettingsColor;
    
    private int[] PatronsColor;
    private int[] CataloguesColor;
    private int[] DVDsColor;
    
    private int[] MessagesColor;
    private int[] WebColor;
    private int[] CriculationsColor;

    
/*
  `titleNoteId` varchar(10),
  `userRating` varchar(20),

*/
}
