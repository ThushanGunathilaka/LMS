/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Thushan;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Design
 */

public class WordTranslate {
    public static List<String> translate(String key) {
        java.sql.Connection connection = null;
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:src/Thushan/en-si.db");
        } catch (SQLException e1) {
        } catch (ClassNotFoundException e2) {}
        
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        List<String> resultSetList = new ArrayList<String>();

        key = key.trim().toLowerCase();
        
        int rowCount=0;
        try {
            if(connection != null)  {
                String query = "select value from dict where key = '"+key+"';";
                preparedStatement = connection.prepareStatement(query);
                resultSet = preparedStatement.executeQuery();


                while (resultSet.next()) {
                    for(int i=0;i<resultSet.getString("value").split("\\|").length;i++){
                        resultSetList.add(i,resultSet.getString("value").split("\\|")[i]);
                    }
                }
                //resultSetList.add("<<It`s All the results we have>>");
            }
        } catch (SQLException e) {}
        finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {}
        }
        return resultSetList;
    }
}
