/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Thushan;



import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;


/**
 *
 * @author Design
 */
public class StretchImage {
    private static ImageIcon imageIcon=null;
    
    public StretchImage(final String imageName,boolean strech,int width,int height) {
        BufferedImage img;
        try {
            img = javax.imageio.ImageIO.read(new File("src/Images/"+imageName));

            if(img.getHeight()>height || img.getWidth()>width) {
                imageIcon = new ImageIcon(img.getScaledInstance(width, height,java.awt.Image.SCALE_SMOOTH));
            } else {
                if(strech){
                    imageIcon = new ImageIcon(img.getScaledInstance(width, height,java.awt.Image.SCALE_SMOOTH));
                }else {
                    imageIcon = new ImageIcon(img);
                }
            }
        } catch (IOException ex) {}
    }
    
    public ImageIcon getImageIcon() {
        return imageIcon;
    }

    public static ImageIcon colorImage(final String imageName,boolean strech,int width,int height,Color color) {
        BufferedImage image;
        int wid;
        int hit;
        WritableRaster raster;
        int red = color.getRed();
        int green = color.getGreen();
        int blue = color.getBlue();
        try {
            image = javax.imageio.ImageIO.read(new File("src/Images/"+imageName));
            wid = image.getWidth();
            hit = image.getHeight();
            raster = image.getRaster();

            for (int xx = 0; xx < wid; xx++) {
                for (int yy = 0; yy < hit; yy++) {
                    int[] pixels = raster.getPixel(xx, yy, (int[]) null);
                    pixels[0] = red;
                    pixels[1] = green;
                    pixels[2] = blue;
                    raster.setPixel(xx, yy, pixels);
                }
            }

     
            if(image.getHeight()>height || image.getWidth()>width) {
                    imageIcon = new ImageIcon(image.getScaledInstance(width, height,java.awt.Image.SCALE_SMOOTH));
            } else {
                if(strech){
                    imageIcon = new ImageIcon(image.getScaledInstance(width, height,java.awt.Image.SCALE_SMOOTH));
                }else {
                    imageIcon = new ImageIcon(image);
                }
            }
        } catch (IOException ex) {}
        return imageIcon;
    }
    
}
