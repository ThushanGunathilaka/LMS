/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package DVDManagement;

/**
 *
 * @author Theja
 */
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.*;
import java.io.*;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;

import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.design.*;
import net.sf.jasperreports.view.*;

public class iReport extends JFrame
{

public iReport(String fileName)
{
this(fileName,null);
}

public iReport(String fileName,HashMap parameter)
{
super("DVD Report");
try
{

/* load the required JDBC driver and create the connection
here JDBC-ODBC Bridge Driver is used*/
Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "root", "root");
        
//Way 1
/*JasperDesign jasperDesign = JasperManager.loadXmlDesign(fileName);
JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
JasperPrint print = JasperFillManager.fillReport(jasperReport, parameter, con);*/

//Way 2
/*JasperReport jasperReport = JasperCompileManager.compileReport(fileName);
JasperPrint print = JasperFillManager.fillReport(jasperReport, parameter, con);*/

/*Way 3 (Here the parameter file should be in .jasper extension i.e., the compiled report)*/
JasperPrint print = JasperFillManager.fillReport(fileName, parameter, con);

JRViewer viewer=new JRViewer(print);

Container c=getContentPane();
c.add(viewer);
}
catch(ClassNotFoundException cnfe)
{
cnfe.printStackTrace();
}
catch(SQLException sqle)
{
sqle.printStackTrace();
}
catch(JRException jre)
{
jre.printStackTrace();
}

setBounds(10,10,1300,500);
setDefaultCloseOperation(DISPOSE_ON_CLOSE);


}

public static void main(String args[])
{
/* A sample calling */
HashMap param=new HashMap();
//param.put("reportParameterName",valueForTheParameter);
iReport viewer=new iReport("C:\\Users\\HP Laptop\\Desktop\\Aliya Aliya\\Aliya\\Removable Disk\\2020\\Launcher\\src\\DVDManagement\\report2.para.jasper",param);
viewer.setVisible(true);


iReport view=new iReport("C:\\Users\\HP Laptop\\Desktop\\Aliya Aliya\\Aliya\\Removable Disk\\2020\\Launcher\\src\\DVDManagement\\itemname.jasper",param);
viewer.setVisible(true);
}
}


