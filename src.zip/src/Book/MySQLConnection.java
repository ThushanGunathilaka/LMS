/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Book;

import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Dilu
 */
public class MySQLConnection {
    private static final Properties properties = new Properties("Book/database.properties");   
    public static String url;
    public static String user;
    public static String password;

    public MySQLConnection(){
        try{
            url=properties.getProperty("url").replace("\\","");
            user=properties.getProperty("user").replace("\\","");
            password=properties.getProperty("password").replace("\\","");
        } catch (Exception e){}
    }

    public static java.sql.Connection getConnection(){
        MySQLConnection mySQLConnection = new MySQLConnection();
        java.sql.Connection connection = null;  
	try {
            Class.forName("com.mysql.jdbc.Driver");
	} catch (ClassNotFoundException e) {}
	try {
            connection = DriverManager.getConnection(url,user,password);
	} catch (SQLException e) {}
        return connection;
    }
}
