/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Book;

//import java.util.ArrayList;
import java.awt.Color;
import java.awt.Component;
import java.awt.Toolkit;
import java.io.File;
import java.io.InputStream;
import java.text.ParseException;
//import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.text.TabSet;

/**
 *
 * @author Dilu
 */
public class EditBookDetails extends javax.swing.JFrame {

     
    private static String key = Books.bookIdParser;
    private static String table = Books.table;
    private static String primaryKeyCol = Books.primaryKeyCol; 

 
    public EditBookDetails() {
        initComponents();
       
        /*
    `book`.`dateOfEntry`,
    `book`.`referenceOnly`,
    `book`.`bookTitle`,
    `book`.`image`,
    `book`.`callNo`,
    `book`.`ISBN`,
    `book`.`edition`,
    `book`.`version`,
    `book`.`language`,
    `book`.`category`,
    `book`.`colorCode`,
    `book`.`authorInitials`,
    `book`.`placeOfPublisher`,
    `book`.`publisherName`,
    `book`.`dateOfPublication`,
    `book`.`dateAcquired`,
    `book`.`invoiceNo`,
    `book`.`pages`,
    `book`.`price`,
    `book`.`summary`,
    `book`.`loanPeriod`,
    `book`.`noOfCopies`,
    `book`.`bookHeight`,
    `book`.`bookWidth`};*/
        
        
    key = Books.bookIdParser;
    table = Books.table;
    primaryKeyCol = Books.getFromPK; 

   String[]  coulmns =new String[] {"`book`.`bookWidth`","`book`.`bookHeight`","`book`.`referenceOnly`","`book`.`bookTitle`","`book`.`callNo`","`book`.`ISBN`","`book`.`edition`","`book`.`version`","`book`.`language`","`book`.`category`","`book`.`colorCode`","`book`.`authorInitials`","`book`.`placeOfPublisher`","`book`.`publisherName`","`book`.`dateOfPublication`","`book`.`dateAcquired`","`book`.`invoiceNo`","`book`.`pages`","`book`.`price`","`book`.`summary`","`book`.`loanPeriod`","`book`.`noOfCopies`","`book`.`section`","`book`.`dateOfEntry`"};///*****************array starts from 0
       List<String> data = MySQLMethods.getResultRow("SELECT "+"`book`.`bookWidth`,`book`.`bookHeight`,`book`.`referenceOnly`,`book`.`bookTitle`,`book`.`callNo`,`book`.`ISBN`,`book`.`edition`,`book`.`version`,`book`.`language`,`book`.`category`,`book`.`colorCode`,`book`.`authorInitials`,`book`.`placeOfPublisher`,`book`.`publisherName`,`book`.`dateOfPublication`,`book`.`dateAcquired`,`book`.`invoiceNo`,`book`.`pages`,`book`.`price`,`book`.`summary`,`book`.`loanPeriod`,`book`.`noOfCopies`,`book`.`section`,`book`.`dateOfEntry`"
      +" FROM `library`."+table+" WHERE "+primaryKeyCol+" = "+key+";",coulmns);
/* 
    List<String> data = MySQLMethods.getResultRow("SELECT * FROM `library`."+table+" WHERE "+primaryKeyCol+" = "+key+";",coulmns);
*/

         
         
    jTextField2.setText(key);
    jTextField51.setText(data.get(0));
    jTextField51.setEditable(false);
    
    jTextField50.setText(data.get(1));
    jTextField50.setEditable(false);
    
    jTextField54.setText(data.get(2));
    jTextField54.setEditable(false);
    
    jTextField20.setText(data.get(3));
    jTextField20.setEditable(false);
    
    jTextField41.setText(data.get(4));
    jTextField41.setEditable(false);
    
    jTextField38.setText(data.get(5));
    jTextField38.setEditable(false);
    
    jTextField40.setText(data.get(6));
    jTextField40.setEditable(false);
    
    jTextField44.setText(data.get(7));
    jTextField44.setEditable(false);
    
    jTextField39.setText(data.get(8));
    jTextField39.setEditable(false);
    
    jTextField53.setText(data.get(9));
    jTextField53.setEditable(false);
    
    jTextField52.setText(data.get(10));
    jTextField52.setEditable(false);
    
    jTextField19.setText(data.get(11));
    jTextField19.setEditable(false);
    
    jTextField55.setText(data.get(12));
    jTextField55.setEditable(false);
    
    jTextField48.setText(data.get(13));
    jTextField48.setEditable(false);
    
    jTextField47.setText(data.get(14));
    jTextField47.setEditable(false);
    
    jTextField45.setText(data.get(15));
    jTextField45.setEditable(false);
    
    jTextField46.setText(data.get(16));
    jTextField46.setEditable(false);
    
    jTextField34.setText(data.get(17));
    jTextField34.setEditable(false);
    
    jTextField49.setText(data.get(18));
    jTextField49.setEditable(false);
    
    jTextArea2.setText(data.get(19));
    jTextArea2.setEditable(false);
    
    jTextField42.setText(data.get(20));
    jTextField42.setEditable(false);
    
    jTextField43.setText(data.get(21));
    jTextField43.setEditable(false);
    
    jTextField56.setText(data.get(22));
    jTextField56.setEditable(false);
    
     jTextField3.setText(data.get(23));
    jTextField3.setEditable(false);
    
           String query = "select `image` from `library`.`book` where bookID = "+jTextField2.getText()+";";
        byte[] image =MySQLMethods.viewimage(query);
         ImageIcon ik = new ImageIcon(image);
         jLabel12.setIcon(ik);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        x = new javax.swing.JTabbedPane();
        editBookPane = new javax.swing.JPanel();
        jTextField2 = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jTextField19 = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        jTextField34 = new javax.swing.JTextField();
        jTextField38 = new javax.swing.JTextField();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jTextField39 = new javax.swing.JTextField();
        jTextField40 = new javax.swing.JTextField();
        jTextField41 = new javax.swing.JTextField();
        jLabel45 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jTextField42 = new javax.swing.JTextField();
        jLabel57 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jTextField43 = new javax.swing.JTextField();
        jTextField44 = new javax.swing.JTextField();
        jTextField45 = new javax.swing.JTextField();
        jTextField46 = new javax.swing.JTextField();
        jLabel59 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jLabel36 = new javax.swing.JLabel();
        jTextField47 = new javax.swing.JTextField();
        jTextField48 = new javax.swing.JTextField();
        jTextField49 = new javax.swing.JTextField();
        jLabel62 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel65 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        jTextField50 = new javax.swing.JTextField();
        jTextField51 = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        EditButton = new javax.swing.JButton();
        jLabel67 = new javax.swing.JLabel();
        save = new javax.swing.JButton();
        jTextField52 = new javax.swing.JTextField();
        jTextField53 = new javax.swing.JTextField();
        jTextField20 = new javax.swing.JTextField();
        jTextField54 = new javax.swing.JTextField();
        jTextField55 = new javax.swing.JTextField();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jTextField56 = new javax.swing.JTextField();
        clear = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setAlwaysOnTop(true);
        setBackground(new java.awt.Color(51, 255, 0));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Iskoola Pota", 1, 36)); // NOI18N
        jLabel3.setText("MANAGE BOOK DETAILS");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 10, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/background/logoooo.png"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, 80, 70));

        x.setFont(new java.awt.Font("Iskoola Pota", 1, 18)); // NOI18N
        x.setMinimumSize(new java.awt.Dimension(967, 676));
        x.setPreferredSize(new java.awt.Dimension(1015, 675));

        editBookPane.setBackground(new java.awt.Color(0, 231, 166));
        editBookPane.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextField2.setEditable(false);
        jTextField2.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        editBookPane.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(134, 5, 200, 35));

        jLabel20.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel20.setText("Book ID");
        editBookPane.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 13, -1, -1));

        jLabel9.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel9.setText("Date Of Entry");
        editBookPane.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 54, -1, -1));

        jTextField3.setEditable(false);
        jTextField3.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });
        editBookPane.add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(134, 46, 200, 35));

        jLabel10.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel10.setText("Book Title");
        editBookPane.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 95, -1, -1));

        jTextField19.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextField19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField19ActionPerformed(evt);
            }
        });
        editBookPane.add(jTextField19, new org.netbeans.lib.awtextra.AbsoluteConstraints(134, 133, 200, 35));

        jLabel31.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel31.setText("Author Initials");
        editBookPane.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 141, -1, -1));

        jTextField34.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextField34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField34ActionPerformed(evt);
            }
        });
        jTextField34.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextField34KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextField34KeyTyped(evt);
            }
        });
        editBookPane.add(jTextField34, new org.netbeans.lib.awtextra.AbsoluteConstraints(134, 174, 200, 35));

        jTextField38.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextField38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField38ActionPerformed(evt);
            }
        });
        jTextField38.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextField38KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextField38KeyTyped(evt);
            }
        });
        editBookPane.add(jTextField38, new org.netbeans.lib.awtextra.AbsoluteConstraints(134, 215, 200, 35));

        jLabel32.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel32.setText("ISBN");
        editBookPane.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 223, -1, -1));

        jLabel33.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel33.setText("No.Of Pages");
        editBookPane.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 182, -1, -1));

        jLabel34.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel34.setText("Language");
        editBookPane.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 269, -1, -1));

        jTextField39.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextField39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField39ActionPerformed(evt);
            }
        });
        editBookPane.add(jTextField39, new org.netbeans.lib.awtextra.AbsoluteConstraints(134, 261, 200, 35));

        jTextField40.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextField40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField40ActionPerformed(evt);
            }
        });
        editBookPane.add(jTextField40, new org.netbeans.lib.awtextra.AbsoluteConstraints(134, 302, 200, 35));

        jTextField41.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextField41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField41ActionPerformed(evt);
            }
        });
        editBookPane.add(jTextField41, new org.netbeans.lib.awtextra.AbsoluteConstraints(134, 345, 200, 35));

        jLabel45.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel45.setText("Call No.");
        editBookPane.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 353, -1, -1));

        jLabel35.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel35.setText("Edition");
        editBookPane.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, -1, -1));

        jTextField42.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextField42.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField42ActionPerformed(evt);
            }
        });
        editBookPane.add(jTextField42, new org.netbeans.lib.awtextra.AbsoluteConstraints(134, 386, 200, 35));

        jLabel57.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel57.setText("Loan Period");
        editBookPane.add(jLabel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 394, -1, -1));

        jLabel55.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel55.setText("No.Of Copies");
        editBookPane.add(jLabel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 440, -1, -1));

        jTextField43.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextField43.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField43ActionPerformed(evt);
            }
        });
        jTextField43.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextField43KeyTyped(evt);
            }
        });
        editBookPane.add(jTextField43, new org.netbeans.lib.awtextra.AbsoluteConstraints(134, 432, 200, 35));

        jTextField44.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextField44.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField44ActionPerformed(evt);
            }
        });
        editBookPane.add(jTextField44, new org.netbeans.lib.awtextra.AbsoluteConstraints(134, 473, 200, 35));

        jTextField45.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextField45.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField45ActionPerformed(evt);
            }
        });
        editBookPane.add(jTextField45, new org.netbeans.lib.awtextra.AbsoluteConstraints(134, 516, 200, 35));

        jTextField46.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextField46.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField46ActionPerformed(evt);
            }
        });
        editBookPane.add(jTextField46, new org.netbeans.lib.awtextra.AbsoluteConstraints(134, 558, 200, 35));

        jLabel59.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel59.setText("Invoice No.");
        editBookPane.add(jLabel59, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 566, -1, -1));

        jLabel60.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel60.setText("Date Acquired");
        editBookPane.add(jLabel60, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 524, -1, -1));

        jLabel61.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel61.setText("Version");
        editBookPane.add(jLabel61, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 481, -1, -1));

        jLabel11.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel11.setText("Book Summary");
        editBookPane.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 105, -1, -1));

        jTextArea2.setColumns(20);
        jTextArea2.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextArea2.setRows(5);
        jScrollPane3.setViewportView(jTextArea2);

        editBookPane.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 133, 313, 117));

        jLabel36.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel36.setText("Reference Only");
        editBookPane.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 13, -1, -1));

        jTextField47.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextField47.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField47ActionPerformed(evt);
            }
        });
        editBookPane.add(jTextField47, new org.netbeans.lib.awtextra.AbsoluteConstraints(507, 300, 176, 35));

        jTextField48.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextField48.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField48ActionPerformed(evt);
            }
        });
        editBookPane.add(jTextField48, new org.netbeans.lib.awtextra.AbsoluteConstraints(507, 345, 176, 35));

        jTextField49.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextField49.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField49ActionPerformed(evt);
            }
        });
        jTextField49.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextField49KeyTyped(evt);
            }
        });
        editBookPane.add(jTextField49, new org.netbeans.lib.awtextra.AbsoluteConstraints(507, 386, 176, 35));

        jLabel62.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel62.setText("Color Code");
        editBookPane.add(jLabel62, new org.netbeans.lib.awtextra.AbsoluteConstraints(365, 481, -1, -1));

        jLabel63.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel63.setText("Category");
        editBookPane.add(jLabel63, new org.netbeans.lib.awtextra.AbsoluteConstraints(365, 440, -1, -1));

        jLabel64.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel64.setText("Price (Rs.)");
        editBookPane.add(jLabel64, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 394, -1, -1));

        jLabel37.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel37.setText("Publisher Name");
        editBookPane.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 353, -1, -1));

        jLabel38.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel38.setText("Date Of Publication");
        editBookPane.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 310, -1, -1));

        jLabel65.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel65.setText("Book Height(cm)");
        editBookPane.add(jLabel65, new org.netbeans.lib.awtextra.AbsoluteConstraints(365, 524, -1, -1));

        jLabel66.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel66.setText("Book Width(cm)");
        editBookPane.add(jLabel66, new org.netbeans.lib.awtextra.AbsoluteConstraints(365, 566, -1, -1));

        jTextField50.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextField50.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField50ActionPerformed(evt);
            }
        });
        jTextField50.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextField50KeyTyped(evt);
            }
        });
        editBookPane.add(jTextField50, new org.netbeans.lib.awtextra.AbsoluteConstraints(507, 517, 176, 35));

        jTextField51.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextField51.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField51ActionPerformed(evt);
            }
        });
        jTextField51.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextField51KeyTyped(evt);
            }
        });
        editBookPane.add(jTextField51, new org.netbeans.lib.awtextra.AbsoluteConstraints(507, 558, 176, 35));

        jPanel5.setBackground(new java.awt.Color(0, 231, 166));
        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Book Cover", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Iskoola Pota", 1, 14))); // NOI18N

        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagesss/BookCollection.png"))); // NOI18N
        jLabel12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel12MouseClicked(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/32x32/add.png"))); // NOI18N
        jLabel16.setText("SET");
        jLabel16.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel16.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jLabel16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel16MouseClicked(evt);
            }
        });

        jLabel17.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/32x32/minus.png"))); // NOI18N
        jLabel17.setText("REMOVE");
        jLabel17.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel17.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 130, Short.MAX_VALUE)
                        .addComponent(jLabel17)))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 315, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel16)
                    .addComponent(jLabel17))
                .addGap(16, 16, 16))
        );

        editBookPane.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(693, 5, -1, -1));

        EditButton.setBackground(new java.awt.Color(0, 0, 0));
        EditButton.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        EditButton.setForeground(new java.awt.Color(255, 255, 255));
        EditButton.setText("EDIT");
        EditButton.setContentAreaFilled(false);
        EditButton.setOpaque(true);
        EditButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditButtonActionPerformed(evt);
            }
        });
        editBookPane.add(EditButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(821, 432, 134, 35));

        jLabel67.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        jLabel67.setText("OPERATION:");
        editBookPane.add(jLabel67, new org.netbeans.lib.awtextra.AbsoluteConstraints(708, 484, -1, -1));

        save.setBackground(new java.awt.Color(0, 0, 0));
        save.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        save.setForeground(new java.awt.Color(255, 255, 255));
        save.setText("SAVE ");
        save.setToolTipText("Save Changes");
        save.setContentAreaFilled(false);
        save.setOpaque(true);
        save.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                saveMouseClicked(evt);
            }
        });
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });
        editBookPane.add(save, new org.netbeans.lib.awtextra.AbsoluteConstraints(821, 475, 134, 35));

        jTextField52.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextField52.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField52ActionPerformed(evt);
            }
        });
        jTextField52.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextField52KeyTyped(evt);
            }
        });
        editBookPane.add(jTextField52, new org.netbeans.lib.awtextra.AbsoluteConstraints(507, 473, 176, 35));

        jTextField53.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextField53.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField53ActionPerformed(evt);
            }
        });
        jTextField53.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextField53KeyTyped(evt);
            }
        });
        editBookPane.add(jTextField53, new org.netbeans.lib.awtextra.AbsoluteConstraints(507, 432, 176, 35));

        jTextField20.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextField20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField20ActionPerformed(evt);
            }
        });
        editBookPane.add(jTextField20, new org.netbeans.lib.awtextra.AbsoluteConstraints(134, 87, 200, 35));

        jTextField54.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextField54.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField54ActionPerformed(evt);
            }
        });
        editBookPane.add(jTextField54, new org.netbeans.lib.awtextra.AbsoluteConstraints(507, 5, 176, 35));

        jTextField55.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextField55.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField55ActionPerformed(evt);
            }
        });
        editBookPane.add(jTextField55, new org.netbeans.lib.awtextra.AbsoluteConstraints(507, 261, 176, 35));

        jLabel39.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel39.setText("Place Of Publisher");
        editBookPane.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 269, -1, -1));

        jLabel40.setFont(new java.awt.Font("Iskoola Pota", 0, 14)); // NOI18N
        jLabel40.setText("Section");
        editBookPane.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 68, -1, -1));

        jTextField56.setFont(new java.awt.Font("Iskoola Pota", 0, 12)); // NOI18N
        jTextField56.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField56ActionPerformed(evt);
            }
        });
        editBookPane.add(jTextField56, new org.netbeans.lib.awtextra.AbsoluteConstraints(507, 60, 174, 35));

        clear.setBackground(new java.awt.Color(0, 0, 0));
        clear.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        clear.setForeground(new java.awt.Color(255, 255, 255));
        clear.setText("CLEAR");
        clear.setContentAreaFilled(false);
        clear.setOpaque(true);
        clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearActionPerformed(evt);
            }
        });
        editBookPane.add(clear, new org.netbeans.lib.awtextra.AbsoluteConstraints(821, 516, 134, 35));

        jButton1.setBackground(new java.awt.Color(0, 0, 0));
        jButton1.setFont(new java.awt.Font("Iskoola Pota", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("EXIT");
        jButton1.setContentAreaFilled(false);
        jButton1.setOpaque(true);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        editBookPane.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(821, 557, 134, 35));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/background/4Swiral.png"))); // NOI18N
        editBookPane.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 960, 630));

        x.addTab("Edit Book Details", editBookPane);

        getContentPane().add(x, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 963, 660));

        jLabel1.setBackground(new java.awt.Color(22, 160, 133));
        jLabel1.setOpaque(true);
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1030, 750));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jTextField19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField19ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField19ActionPerformed

    private void jTextField34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField34ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField34ActionPerformed

    private void jTextField38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField38ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField38ActionPerformed

    private void jTextField39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField39ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField39ActionPerformed

    private void jTextField40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField40ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField40ActionPerformed

    private void jTextField41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField41ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField41ActionPerformed

    private void jTextField42ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField42ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField42ActionPerformed

    private void jTextField43ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField43ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField43ActionPerformed

    private void jTextField44ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField44ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField44ActionPerformed

    private void jTextField45ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField45ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField45ActionPerformed

    private void jTextField46ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField46ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField46ActionPerformed

    private void jTextField47ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField47ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField47ActionPerformed

    private void jTextField48ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField48ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField48ActionPerformed

    private void jTextField49ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField49ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField49ActionPerformed

    private void jTextField50ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField50ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField50ActionPerformed

    private void jTextField51ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField51ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField51ActionPerformed

    //private static File imageFile=null;
    private void jTextField34KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField34KeyPressed
        // TODO add your handling code here:
         
    }//GEN-LAST:event_jTextField34KeyPressed

    private void jTextField38KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField38KeyPressed
        // TODO add your handling code here:
       
    }//GEN-LAST:event_jTextField38KeyPressed

    private void jTextField34KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField34KeyTyped
        // TODO add your handling code here:
        char c = evt.getKeyChar();
        if(!Character.isDigit(c)) {
            evt.consume();
            Toolkit.getDefaultToolkit().beep();
        }
    }//GEN-LAST:event_jTextField34KeyTyped

    private void jTextField38KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField38KeyTyped
        // TODO add your handling code here:
         char c = evt.getKeyChar();
        if(!Character.isDigit(c) && c!='-') {
            evt.consume();
            Toolkit.getDefaultToolkit().beep();
        }
    }//GEN-LAST:event_jTextField38KeyTyped

    private void jTextField43KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField43KeyTyped
        // TODO add your handling code here:
        char c = evt.getKeyChar();
        if(!Character.isDigit(c)) {
            evt.consume();
            Toolkit.getDefaultToolkit().beep();
        }
    }//GEN-LAST:event_jTextField43KeyTyped

    private void jTextField49KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField49KeyTyped
        // TODO add your handling code here:
         char c = evt.getKeyChar();
        if(!Character.isDigit(c) && c!='.') {
            evt.consume();
            Toolkit.getDefaultToolkit().beep();
        }
    }//GEN-LAST:event_jTextField49KeyTyped

    private void jTextField50KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField50KeyTyped
        // TODO add your handling code here:
         char c = evt.getKeyChar();
        if(!Character.isDigit(c) && c!='.') {
            evt.consume();
            Toolkit.getDefaultToolkit().beep();
        }
    }//GEN-LAST:event_jTextField50KeyTyped

    private void jTextField51KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField51KeyTyped
        // TODO add your handling code here:
         char c = evt.getKeyChar();
        if(!Character.isDigit(c) && c!='.') {
            evt.consume();
            Toolkit.getDefaultToolkit().beep();
        }
    }//GEN-LAST:event_jTextField51KeyTyped

    private void saveMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_saveMouseClicked
        // TODO add your handling code here:
      
//book cover jLabel12
    }//GEN-LAST:event_saveMouseClicked

    private void jTextField52ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField52ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField52ActionPerformed

    private void jTextField52KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField52KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField52KeyTyped

    private void jTextField53ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField53ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField53ActionPerformed

    private void jTextField53KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField53KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField53KeyTyped

    private void EditButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditButtonActionPerformed
        // TODO add your handling code here:
    jTextField51.setEditable(true);
    jTextField50.setEditable(true);
    jTextField54.setEditable(true);
    jTextField20.setEditable(true);
    jTextField41.setEditable(true);
    jTextField38.setEditable(true);
    jTextField40.setEditable(true);  
    jTextField44.setEditable(true); 
    jTextField39.setEditable(true);  
    jTextField53.setEditable(true);  
    jTextField52.setEditable(true); 
   // jTextField19.setEditable(true); 
    jTextField55.setEditable(true);
    jTextField48.setEditable(true); 
    jTextField47.setEditable(true);  
    jTextField45.setEditable(true);   
    jTextField46.setEditable(true);  
    jTextField34.setEditable(true);  
    jTextField49.setEditable(true);   
    jTextArea2.setEditable(true); 
    jTextField42.setEditable(true); 
    jTextField43.setEditable(true);
    jTextField56.setEditable(true);
        
    }//GEN-LAST:event_EditButtonActionPerformed

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
        // TODO add your handling code here:
        //System.out.println("aliya aliya aliya aliya ");
        //validate
        //IMAGE ?
        
        String width =jTextField51.getText();
        MySQLMethods.curd(MySQLMethods.update("library", table,primaryKeyCol,key, "`book`.`bookWidth`",width));//#int#
        
        String height= jTextField50.getText();
        MySQLMethods.curd(MySQLMethods.update("library", table,primaryKeyCol,key, "`book`.`bookHeight`",height));
    
        String referenceOnly=jTextField54.getText();
        MySQLMethods.curd(MySQLMethods.update("library", table,primaryKeyCol,key, "`book`.`referenceOnly`",referenceOnly));

        String title=jTextField20.getText();
        MySQLMethods.curd(MySQLMethods.update("library", table,primaryKeyCol,key, "`book`.`bookTitle`",title));

        String callNo=jTextField41.getText();
        MySQLMethods.curd(MySQLMethods.update("library", table,primaryKeyCol,key, "`book`.`callNo`",callNo));

        String isbn=jTextField38.getText();
        MySQLMethods.curd(MySQLMethods.update("library", table,primaryKeyCol,key, "`book`.`ISBN`",isbn));

        String edition=jTextField40.getText();
        MySQLMethods.curd(MySQLMethods.update("library", table,primaryKeyCol,key, "`book`.`edition`",edition));

        String version=jTextField44.getText();
        MySQLMethods.curd(MySQLMethods.update("library", table,primaryKeyCol,key, "`book`.`version`",version));

        String language=jTextField39.getText();
        MySQLMethods.curd(MySQLMethods.update("library", table,primaryKeyCol,key, "`book`.`language`",language));

        String category=jTextField53.getText();
        MySQLMethods.curd(MySQLMethods.update("library", table,primaryKeyCol,key, "`book`.`category`",category));

        String colorCode=jTextField52.getText();
        MySQLMethods.curd(MySQLMethods.update("library", table,primaryKeyCol,key, "`book`.`colorCode`",colorCode));

    //    String authorInitials=jTextField19.getText();
    //    MySQLMethods.curd(MySQLMethods.update("library", table,primaryKeyCol,key, "`book`.`authorInitials`",authorInitials));
        
        String placeOfPublisher=jTextField55.getText();
        MySQLMethods.curd(MySQLMethods.update("library", table,primaryKeyCol,key, "`book`.`placeOfPublisher`",placeOfPublisher));

        String publisherName=jTextField48.getText();
        MySQLMethods.curd(MySQLMethods.update("library", table,primaryKeyCol,key, "`book`.`publisherName`",publisherName));

        String publicationDate=jTextField47.getText();
        MySQLMethods.curd(MySQLMethods.update("library", table,primaryKeyCol,key, "`book`.`dateOfPublication`",publicationDate));

        String dateAcquired=jTextField45.getText();
        MySQLMethods.curd(MySQLMethods.update("library", table,primaryKeyCol,key, "`book`.`dateAcquired`",dateAcquired));

        String invoiceNo=jTextField46.getText();
        MySQLMethods.curd(MySQLMethods.update("library", table,primaryKeyCol,key, "`book`.`invoiceNo`",invoiceNo));

        String noOfPages=jTextField34.getText();
        MySQLMethods.curd(MySQLMethods.update("library", table,primaryKeyCol,key, "`book`.`pages`",noOfPages));

        String price=jTextField49.getText();
        MySQLMethods.curd(MySQLMethods.update("library", table,primaryKeyCol,key, "`book`.`price`",price));

        String summary=jTextArea2.getText();
        MySQLMethods.curd(MySQLMethods.update("library", table,primaryKeyCol,key, "`book`.`summary`",summary));
        
        String loanPeriod=jTextField42.getText();
        MySQLMethods.curd(MySQLMethods.update("library", table,primaryKeyCol,key, "`book`.`loanPeriod`",loanPeriod));
        
        String noOfCopies=jTextField43.getText();
        MySQLMethods.curd(MySQLMethods.update("library", table,primaryKeyCol,key, "`book`.`noOfCopies`",noOfCopies));
        
        String section=jTextField56.getText();
        MySQLMethods.curd(MySQLMethods.update("library", table,primaryKeyCol,key, "`book`.`section`",section));
        
      
        
        
        
        
         jLabel67.setText("EDIT-SUCCESS");
         
          jTextField51.setEditable(false);
    jTextField50.setEditable(false);
    jTextField54.setEditable(false);
    jTextField20.setEditable(false);
    jTextField41.setEditable(false);
    jTextField38.setEditable(false);
    jTextField40.setEditable(false);  
    jTextField44.setEditable(false); 
    jTextField39.setEditable(false);  
    jTextField53.setEditable(false);  
    jTextField52.setEditable(false); 
    jTextField19.setEditable(false); 
    jTextField55.setEditable(false);
    jTextField48.setEditable(false); 
    jTextField47.setEditable(false);  
    jTextField45.setEditable(false);   
    jTextField46.setEditable(false);  
    jTextField34.setEditable(false);  
    jTextField49.setEditable(false);   
    jTextArea2.setEditable(false); 
    jTextField42.setEditable(false); 
    jTextField43.setEditable(false);
    jTextField56.setEditable(false);
    
        
    }//GEN-LAST:event_saveActionPerformed

    private void jTextField20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField20ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField20ActionPerformed

    private void jTextField54ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField54ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField54ActionPerformed

    private void jTextField55ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField55ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField55ActionPerformed

    private void jTextField56ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField56ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField56ActionPerformed

    private void clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearActionPerformed
        // TODO add your handling code here:
        jLabel67.setText("OPERATION");
        jTextField20.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField19.setText("");
        jTextField34.setText("");
        jTextField38.setText("");
        jTextField39.setText("");
        jTextField40.setText("");
        jTextField41.setText("");
        jTextField42.setText("");
        jTextField43.setText("");
        jTextField44.setText("");
        jTextField45.setText("");
        jTextField46.setText("");
        jTextField55.setText("");
        jTextArea2.setText("");
        jTextField47.setText("");
        jTextField54.setText("");
        jTextField48.setText("");
        jTextField49.setText("");
        jTextField50.setText("");
        jTextField51.setText("");
        jTextField53.setText("");
        jTextField52.setText("");
        jTextField56.setText("");
        jLabel12.setIcon(new ImageIcon("src/imagesss/BookCollection.png"));
       
    jTextField51.setEditable(false);
    jTextField50.setEditable(false);
    jTextField54.setEditable(false);
    jTextField20.setEditable(false);
    jTextField41.setEditable(false);
    jTextField38.setEditable(false);
    jTextField40.setEditable(false);  
    jTextField44.setEditable(false); 
    jTextField39.setEditable(false);  
    jTextField53.setEditable(false);  
    jTextField52.setEditable(false); 
    jTextField19.setEditable(false); 
    jTextField55.setEditable(false);
    jTextField48.setEditable(false); 
    jTextField47.setEditable(false);  
    jTextField45.setEditable(false);   
    jTextField46.setEditable(false);  
    jTextField34.setEditable(false);  
    jTextField49.setEditable(false);   
    jTextArea2.setEditable(false); 
    jTextField42.setEditable(false); 
    jTextField43.setEditable(false);
    jTextField56.setEditable(false);
    }//GEN-LAST:event_clearActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed
 private static File imageFile=null;
    private void jLabel16MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel16MouseClicked
        // TODO add your handling code here:
              this.setAlwaysOnTop(false);
            JFileChooser fileopen = new JFileChooser();
    FileFilter filter = new FileNameExtensionFilter("*.png Files", "*.png");
    fileopen.addChoosableFileFilter(filter);
    int ret = fileopen.showDialog(null, "Open file");

    
        switch (ret) {
    case JFileChooser.APPROVE_OPTION:

        imageFile=fileopen.getSelectedFile();
        jLabel12.setIcon(new ImageIcon(imageFile.getPath()));
        
          try{
        MySQLMethods.insertImage("library","book","image","bookID",jTextField2.getText() ,imageFile);
       // String query = "select `image` from `library`.`book` where bookID = "+jTextField2.getText()+";";
        //byte[] image =MySQLMethods.viewimage(query);
        // ImageIcon ik = new ImageIcon(image);
         
        // jLabel12.setIcon(ik);
        }catch(Exception e){}
        
        
      break;
    case JFileChooser.CANCEL_OPTION:
      this.setAlwaysOnTop(true);
      break;
    case JFileChooser.ERROR_OPTION:
      this.setAlwaysOnTop(true);
      break;
    }
    }//GEN-LAST:event_jLabel16MouseClicked

    private void jLabel12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel12MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel12MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EditBookDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EditBookDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EditBookDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EditBookDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EditBookDetails().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton EditButton;
    private javax.swing.JButton clear;
    private javax.swing.JPanel editBookPane;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextField jTextField19;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField20;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField34;
    private javax.swing.JTextField jTextField38;
    private javax.swing.JTextField jTextField39;
    private javax.swing.JTextField jTextField40;
    private javax.swing.JTextField jTextField41;
    private javax.swing.JTextField jTextField42;
    private javax.swing.JTextField jTextField43;
    private javax.swing.JTextField jTextField44;
    private javax.swing.JTextField jTextField45;
    private javax.swing.JTextField jTextField46;
    private javax.swing.JTextField jTextField47;
    private javax.swing.JTextField jTextField48;
    private javax.swing.JTextField jTextField49;
    private javax.swing.JTextField jTextField50;
    private javax.swing.JTextField jTextField51;
    private javax.swing.JTextField jTextField52;
    private javax.swing.JTextField jTextField53;
    private javax.swing.JTextField jTextField54;
    private javax.swing.JTextField jTextField55;
    private javax.swing.JTextField jTextField56;
    private javax.swing.JButton save;
    public static javax.swing.JTabbedPane x;
    // End of variables declaration//GEN-END:variables
}
