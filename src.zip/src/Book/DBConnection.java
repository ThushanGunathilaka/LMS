/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Book;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author dilusha
 */
//default strings,#int# for int values
public class DBConnection {  
    public static String url;
    public static String user;
    public static String password;

    public DBConnection(){
        try {
            url = "jdbc:mysql://localhost:3306/?allowMultiQueries=true";
            user = "root";
            password = "root";
        } catch(Exception e) {}
    }


    public java.sql.Connection getConnection(){
        java.sql.Connection connection = null;  
	try {
            Class.forName("com.mysql.jdbc.Driver");
	} catch (ClassNotFoundException e) {}
	try {
            connection = DriverManager.getConnection(url,user,password);
	} catch (SQLException e) {}
        return connection;
    }
    
    public String[] getMetaSet(String query) {
        java.sql.Connection connection = getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String[] answer = null;

        try {
            preparedStatement = connection.prepareStatement(query);
            resultSet = preparedStatement.executeQuery();
            
            ResultSetMetaData meta = resultSet.getMetaData();
            answer=new String[meta.getColumnCount()];
            for(int i = 1;i<meta.getColumnCount()+1;i++){
                answer[i-1] = meta.getColumnName(i);
            }
        } catch (SQLException e) {}
        finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {}
        }
        return answer;
    }

    public boolean curd(List<String> queryList) {
        java.sql.Connection connection = getConnection();
        PreparedStatement preparedStatement = null;       
        boolean success = true;
        try {
            for(String query : queryList){
                preparedStatement = connection.prepareStatement(query + ";");
                System.out.println(query);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {}
        finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {}
        }
       return success;
    }  

    public List<List<String>> getResultSet(String query) {
        java.sql.Connection connection = getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        List<String> resultList = new ArrayList<>();
        List<List<String>> resultSetList = new ArrayList<>();
        
        int coulmnCount;
        int rowCount=0;
        try {
            preparedStatement = connection.prepareStatement(query);
            resultSet = preparedStatement.executeQuery();

            ResultSetMetaData meta = resultSet.getMetaData();
            coulmnCount=meta.getColumnCount();

            while (resultSet.next()) {
                for(int i=0;i<coulmnCount;i++){
                    resultList.add(i,resultSet.getString(i+1));
                }
                resultSetList.add(rowCount, resultList);
                resultList =new ArrayList<>();
                rowCount++;
            }
        } catch (SQLException e) {}
        finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {}
        }
        return resultSetList;
    }
    
    public String insert(String database,String table,String[] columns,String[] values){
        String columnSet = "";
        String valueSet = "";
        
        for(String column : columns) {
            columnSet += column + ",";
        }
        columnSet = columnSet.substring(0,columnSet.length()-1);
        
        for(String value : values) {
            if(value.contains("#int#")) {
                value = value.replace("#int#","");
                valueSet += value + ",";
            } else {
                valueSet += "\"" + value + "\",";     
            }
        }
        valueSet = valueSet.substring(0,valueSet.length()-1);

        return ("insert into `" + database + "`.`" + table + "`(" + columnSet+ ") values("+valueSet+");");
    
    };
    
    public String update(String database,String table,String primaryKeyAsString,String column,String value){
        String answer;
        
        if(value.contains("#int#")) {
            value = value.replace("#int#","");
            answer = "update `"+database+"`.`"+table+"` set "+column+"="+value+" where empId="+primaryKeyAsString+";";
        } else {
            answer = "update `"+database+"`.`"+table+"` set "+column+"=\""+value+"\" where empId="+primaryKeyAsString+";";    
        }
            
        return answer;
    };
    
    public String delete(String database,String table,String column,String primaryKeyAsString){
        String answer = "";
        if(!database.equals("") && !table.equals("") && !primaryKeyAsString.equals("") && !column.equals("")) {
            answer = "delete from `"+database+"`.`"+table+"` where "+column+" ="+primaryKeyAsString+"";
        } else if (!database.equals("") && !table.equals("") && primaryKeyAsString.equals("") && column.equals("")) {
            answer = "DROP TABLE IF EXISTS `"+database+"`.`"+table+"`;";
        } else if (!database.equals("") && table.equals("") && primaryKeyAsString.equals("") && column.equals("")) {
            answer = "DROP DATABASE IF EXISTS `"+database+"`;";
        }
        return answer;
    };
    
    public static List<String> translate(String key) {
        java.sql.Connection connection = null;
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:en-si.db");
        } catch (SQLException | ClassNotFoundException ex) {}
        
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        List<String> resultSetList = new ArrayList<>();

        int rowCount=0;
        try {
            if(connection != null)  {
                String query = "select value from dict where key = '"+key+"';";
                preparedStatement = connection.prepareStatement(query);
                resultSet = preparedStatement.executeQuery();


                while (resultSet.next()) {
                    for(int i=0;i<resultSet.getString("value").split("\\|").length;i++){
                        resultSetList.add(i,resultSet.getString("value").split("\\|")[i]);
                    }
                }
            }
        } catch (SQLException e) {}
        finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {}
        }
        return resultSetList;
    }
    /*
    public static void main(String [] args) {
            List<String> l =Connection.translate("halo");


                System.out.println("********************************");
             
            for(String u :l){
                
                System.out.println(u);
            }
            System.out.println("********************************");

            try{
            String s= l.get(2);
           System.out.println(s);
           
            }catch(Exception e){}
    }
    */
}