package Book;

import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLDecoder;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.reloading.FileChangedReloadingStrategy;
 
public class Properties {
    private PropertiesConfiguration configuration;
    private final String filePath;
    
    public Properties(String fileName){
        this.filePath = setPath(fileName);
        loadProperties(this.filePath);
    }

    private synchronized String setPath(String fileName) {
        String path=null;
        try {
            URL url = this.getClass().getProtectionDomain().getCodeSource().getLocation();
            path = URLDecoder.decode(url.getFile(),"UTF-8")+fileName;
        } catch (UnsupportedEncodingException e) {}
        return path;
    }
    
    private synchronized void loadProperties(String filePath) {
        try {
            configuration = new PropertiesConfiguration(filePath);
            configuration.setIncludesAllowed(true);
            configuration.setReloadingStrategy(new FileChangedReloadingStrategy());
        } catch(ConfigurationException e) {}
    }
        
    public synchronized String getProperty(final String key) {
        return (String)configuration.getProperty(key);
    }
    
    public synchronized void addProperty(String key,String value) {
        try{
            configuration = new PropertiesConfiguration(filePath);
            configuration.addProperty(key,value);
            configuration.save();
        }catch(ConfigurationException e){}
    }

    public synchronized void clearProperty(String key) {
        try{
            configuration = new PropertiesConfiguration(filePath);
            configuration.clearProperty(key);
            configuration.save();
        }catch(ConfigurationException e){}
    }
}