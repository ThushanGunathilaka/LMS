/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Book;

import static Book.MySQLConnection.getConnection;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Blob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Design
 */
public class MySQLMethods {
    public static boolean curd(List<String> queryList) {
        java.sql.Connection connection = MySQLConnection.getConnection();
        PreparedStatement preparedStatement = null;       
        boolean success = true;
        try {
            for(String query : queryList){
                preparedStatement = connection.prepareStatement(query + ";");
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {}
        finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {}
        }
       return success;
    }
    
    public static boolean curd(String query) {
        java.sql.Connection connection = MySQLConnection.getConnection();
        PreparedStatement preparedStatement = null;       
        boolean success = true;
        try {
                preparedStatement = connection.prepareStatement(query+ ";");
                preparedStatement.executeUpdate();
        } catch (SQLException e) {}
        finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {}
        }
       return success;
    }
    
    public static List<List<String>> getResultTable(String query) {
        java.sql.Connection connection = MySQLConnection.getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        List<String> resultList = new ArrayList<String>();
        List<List<String>> resultSetList = new ArrayList<List<String>>();
        
        int coulmnCount;
        int rowCount=0;
        try {
            preparedStatement = connection.prepareStatement(query);
            resultSet = preparedStatement.executeQuery();

            ResultSetMetaData meta = resultSet.getMetaData();
            coulmnCount=meta.getColumnCount();
            
           // for(int i=0;i<coulmnCount;i++){
           //     resultList.add(i,meta.getColumnName(i+1));
           // }
          //  resultSetList.add(rowCount, resultList);
          //  resultList =new ArrayList<String>();
          //  rowCount++;
            
            while (resultSet.next()) {
                for(int i=0;i<coulmnCount;i++){
                    resultList.add(i,resultSet.getString(i+1));
                }
                resultSetList.add(rowCount, resultList);
                resultList =new ArrayList<String>();
                rowCount++;
            }
        } catch (SQLException e) {}
        finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {}
        }
        return resultSetList;
    }
    
    public static List<String> getResultRow(String query,String [] columns) {
        java.sql.Connection connection = MySQLConnection.getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        List<String> resultList = new ArrayList<String>();
        int coulmnCount = columns.length; 

        try {
            System.out.println(query);
            preparedStatement = connection.prepareStatement(query);
            resultSet = preparedStatement.executeQuery();
            
            while (resultSet.next()) {
                if(coulmnCount>0){
                    for(int i=0;i<coulmnCount;i++) {
                        resultList.add(i,resultSet.getString(i+1));
                        System.out.println(resultSet.getString(i+1));
                    }
                }
            }
        } catch (SQLException e) {}
        finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {}
        }
        return resultList;
    }
    
        public static List<String> getResultColumn(String query) {
        java.sql.Connection connection = MySQLConnection.getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        int rowCount = 0;
        List<String> resultList = new ArrayList<String>();

        try {
            preparedStatement = connection.prepareStatement(query);
            resultSet = preparedStatement.executeQuery();
            
            while (resultSet.next()) {
                    resultList.add(rowCount,resultSet.getString(1));
                    rowCount++;
            }
        } catch (SQLException e) {}
        finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {}
        }
        return resultList;
    }
    
    public static String getResultCell(String query) {
        java.sql.Connection connection = MySQLConnection.getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String result = "";
        
        try {
            System.out.println(query);
            preparedStatement = connection.prepareStatement(query);
            resultSet = preparedStatement.executeQuery();
            
            while (resultSet.next()) {
                    result = resultSet.getString(1);
            }
        } catch (SQLException e) {}
        finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {}
        }
        return result;
    }
    
    public static String delete(String database,String table,String column,String primaryKeyAsString){
        String answer = "";
        if(!database.equals("") && !table.equals("") && !primaryKeyAsString.equals("") && !column.equals("")) {
            answer = "delete from `"+database+"`.`"+table+"` where "+column+" ="+primaryKeyAsString+"";
        } else if (!database.equals("") && !table.equals("") && primaryKeyAsString.equals("") && column.equals("")) {
            answer = "DROP TABLE IF EXISTS `"+database+"`.`"+table+"`;";
        } else if (!database.equals("") && table.equals("") && primaryKeyAsString.equals("") && column.equals("")) {
            answer = "DROP DATABASE IF EXISTS `"+database+"`;";
        }
        System.out.println(answer);
        return answer;
    };
    
    public static String insert(String database,String table,String[] columns,String[] values){
        String columnSet = "";
        String valueSet = "";
        
        for(String column : columns) {
            columnSet += column + ",";
        }
        columnSet = columnSet.substring(0,columnSet.length()-1);
        
        for(String value : values) {
            if(value.contains("#int#")) {
                value = value.replace("#int#","");
                valueSet += value + ",";
            } else {
                valueSet += "\"" + value + "\",";     
            }
        }
        valueSet = valueSet.substring(0,valueSet.length()-1);
        return ("insert into `" + database + "`.`" + table + "`(" + columnSet+ ") values("+valueSet+");");
    };
    
    public static String update(String database,String table,String primaryKeyColumn,String primaryKey,String column,String value){
        String answer;
        
        if(value.contains("#int#")) {
            value = value.replace("#int#","");
            answer = "update `"+database+"`."+table+" set "+column+"="+value+" where "+primaryKeyColumn+"="+primaryKey;
        } else {
            answer = "update `"+database+"`."+table+" set "+column+"=\""+value+"\" where "+primaryKeyColumn+"="+primaryKey;    
        }
            System.out.println(answer);
        return answer;
    };
    
    public static boolean insertImage(String database,String table,String column,String primaryField, String primaryKey,File image){
        boolean status =false;
        
        java.sql.Connection connection = getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        int answer = 0;

        try {
            connection.setAutoCommit(false);

            
          
      FileInputStream fis=null;
            try {
                fis = new FileInputStream(image);
            } catch (FileNotFoundException ex) {};
      preparedStatement = connection.prepareStatement("update `" + database + "`.`" + table + "` set `" + column+ "` =? where "+primaryField+" = "+primaryKey+";");
      System.out.println("update `" + database + "`.`" + table + "` set `" + column+ "` =? where "+primaryField+" = "+primaryKey+";");
      preparedStatement.setBinaryStream(1, fis, (int) image.length());
      preparedStatement.executeUpdate();
      connection.commit();
      System.out.println("dsfs");
        } catch (SQLException e) {}
        finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {}
        }
        
        return status;
    } 
    
    public static byte[] viewimage(String query) {



        java.sql.Connection connection = getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            preparedStatement = connection.prepareStatement(query);
            resultSet = preparedStatement.executeQuery();
            
            while (resultSet.next()) {
                Blob blob = resultSet.getBlob("image");
                return blob.getBytes(1, (int) blob.length());
            }
        } catch (SQLException e) {}
        finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {}
        }
        return null;
    }
    
    
}


        //List<List<String>> data = MySQLMethods.getResultTable("SELECT * FROM `translations`.`translator`;");
        //String row="";
        //int y = data.size()-1;
        //int x = data.get(0).size()-1;
        //for(int i=1;i<=y;i++) {
       //     for(int j=0;j<=x;j++) {
        //        row += data.get(i).get(j)+"     |       ";
         //       translator.put(data.get(i).get(2), new Text(data.get(i).get(3),data.get(i).get(4)));
               // System.out.println(data.get(i).get(2)+"     |       "+data.get(i).get(3)+"      |       "+data.get(i).get(4));
        //    }
        //    System.out.println(row+"\n");
        //    row="";
        //}